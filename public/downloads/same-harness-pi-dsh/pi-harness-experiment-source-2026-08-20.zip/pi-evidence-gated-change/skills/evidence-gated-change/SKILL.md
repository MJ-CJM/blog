---
name: evidence-gated-change
description: Runs a bounded TodoService requestId change through parallel discovery, hash-bound human approval, isolated implementation, semantic review, and deterministic test receipts. Use when demonstrating Skill/Agent-driven workflow behavior in an agent harness.
---

# Evidence-Gated Change

This Skill defines the portable method; the host harness adapter owns orchestration, lifecycle, and durable state.

## Required stages

1. Capture an immutable fixture baseline and the shared-contract hash.
2. Run the Code Scout and Test Scout concurrently with read-only tools.
3. Have the Planner produce a schema-valid plan.
4. Pause at `awaiting_approval`; bind approval to the exact plan, baseline, shared-contract, and runtime-adapter hashes.
5. After approval, let the Implementer edit only the isolated worktree.
6. Run the Reviewer and fixed verifier concurrently.
7. Complete only when both semantic review and deterministic receipts pass; otherwise permit at most one Repair attempt.

## Non-negotiable gates

- Approval is bound to a canonical SHA-256 over `planHash`, `baselineHash`, `contractHash`, and `runtimeHash`.
- No write may occur before approval.
- Only the three files named in `contract/CHANGE_REQUEST.md` may change.
- A real project-test exit code, the external oracle, and the compile-time API probe must all pass.
- Reviewer prose cannot override a failed command receipt.
- At most one repair is permitted.
- Every side effect has an intent and settled event in `events.jsonl`.

See `contract/CHANGE_REQUEST.md` and `contract/schemas/` for the portable contract.
