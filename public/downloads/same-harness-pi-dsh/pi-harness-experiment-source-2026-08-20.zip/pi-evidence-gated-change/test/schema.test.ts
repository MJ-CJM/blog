import assert from "node:assert/strict";
import { dirname, resolve } from "node:path";
import test from "node:test";
import { fileURLToPath } from "node:url";
import { SchemaValidator } from "../src/schema-validator.ts";
import { VERIFIER_PROCESS_LIMITS } from "../src/verifier.ts";

const projectRoot = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const schema = new SchemaValidator(projectRoot);
const validPlan = {
	summary: "bounded plan",
	files: ["README.md", "src/TodoService.ts", "test/TodoService.test.ts"],
	steps: ["implement"],
	tests: ["verify"],
	risks: [],
};

test("canonical schemas enforce additionalProperties, uniqueness, and minimum items", () => {
	assert.deepEqual(schema.validate("plan", structuredClone(validPlan)), validPlan);
	assert.throws(() => schema.validate("plan", { ...validPlan, extra: true }), /additional properties/);
	assert.throws(
		() => schema.validate("plan", { ...validPlan, files: ["README.md", "README.md", "src/TodoService.ts"] }),
		/duplicate|unique/,
	);
	assert.throws(() => schema.validate("plan", { ...validPlan, steps: [] }), /fewer than 1 items/);
	assert.throws(
		() => schema.validate("implementation", { summary: "done", filesChanged: ["README.md"], claimedTestsPassed: true }),
		/additional properties/,
	);
});

test("verifier timeouts use non-cooperative SIGKILL termination", () => {
	assert.deepEqual(VERIFIER_PROCESS_LIMITS, { timeoutMs: 30_000, killSignal: "SIGKILL" });
});
