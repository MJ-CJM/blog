import assert from "node:assert/strict";
import { dirname, resolve } from "node:path";
import test from "node:test";
import { fileURLToPath } from "node:url";
import { PiSubprocessAgentRunner } from "../src/pi-runner.ts";
import type { AgentTask } from "../src/types.ts";

const PROJECT_ROOT = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const STUB = resolve(PROJECT_ROOT, "test", "fixtures", "pi-child-stub.mjs");
const TASK: AgentTask = {
	role: "planner",
	prompt: "@must-not-be-treated-as-an-attachment",
	cwd: PROJECT_ROOT,
	tools: ["read"],
	timeoutMs: 2_000,
};

function runner(mode: string, forceKillAfterMs?: number): PiSubprocessAgentRunner {
	return new PiSubprocessAgentRunner({
		projectRoot: PROJECT_ROOT,
		piCommand: { command: process.execPath, args: [STUB, mode] },
		...(forceKillAfterMs === undefined ? {} : { forceKillAfterMs }),
	});
}

test("Pi runner uses official one-shot args and parses the terminal JSON event", async () => {
	const result = await runner("success").run(TASK, new AbortController().signal);
	assert.equal(result.exitCode, 0);
	assert.equal(result.stopReason, "stop");
	const output = JSON.parse(result.output) as { argv: string[] };
	assert.deepEqual(output.argv.slice(0, 4), ["--mode", "json", "-p", "--no-session"]);
	assert.equal(output.argv.at(-1), `Task: ${TASK.prompt}`);
});

test("Pi runner distinguishes invalid JSON, missing terminal, nonzero, and non-stop completion", async () => {
	const invalid = await runner("invalid-json").run(TASK, new AbortController().signal);
	assert.equal(invalid.exitCode, 1);
	assert.match(invalid.stderr, /Invalid Pi JSON event/);

	const missing = await runner("missing-terminal").run(TASK, new AbortController().signal);
	assert.equal(missing.exitCode, 1);
	assert.match(missing.stderr, /Missing terminal assistant message/);

	const nonzero = await runner("nonzero").run(TASK, new AbortController().signal);
	assert.equal(nonzero.exitCode, 7);
	assert.match(nonzero.stderr, /Missing terminal assistant message/);

	const length = await runner("length").run(TASK, new AbortController().signal);
	assert.equal(length.exitCode, 0);
	assert.equal(length.stopReason, "length");
});

test("Pi runner escalates an ignored SIGTERM to SIGKILL", async () => {
	const started = Date.now();
	const result = await runner("hang", 50).run({ ...TASK, timeoutMs: 250 }, new AbortController().signal);
	assert.equal(result.exitCode, 1);
	assert.match(result.stderr, /timed out/);
	assert.match(result.stderr, /SIGKILL/);
	assert.ok(Date.now() - started < 2_000);
});

test("Pi runner cannot accept a cooperative success after its deadline", async () => {
	const result = await runner("cooperative-timeout", 500).run(
		{ ...TASK, timeoutMs: 250 },
		new AbortController().signal,
	);
	assert.equal(result.stopReason, "stop");
	assert.equal(result.exitCode, 1);
	assert.match(result.stderr, /timed out/);
});
