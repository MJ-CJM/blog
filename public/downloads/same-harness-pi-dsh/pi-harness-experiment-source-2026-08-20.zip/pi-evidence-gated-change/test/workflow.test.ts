import assert from "node:assert/strict";
import { access, cp, mkdtemp, readFile, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { dirname, join, resolve } from "node:path";
import test from "node:test";
import { fileURLToPath } from "node:url";
import { appendEvent, readJson, writeJsonAtomic } from "../src/artifacts.ts";
import type { AgentRole, AgentRunResult, AgentRunner, AgentTask, ApprovalArtifact, WorkflowState } from "../src/types.ts";
import { EvidenceGatedWorkflow } from "../src/workflow.ts";

const SOURCE_ROOT = resolve(dirname(fileURLToPath(import.meta.url)), "..");

const GOOD_SOURCE = `export interface Task {
\tid: number;
\ttitle: string;
\tcompleted: boolean;
}

export interface CreateTaskInput {
\ttitle: string;
\trequestId: string;
\tcompleted?: boolean;
}

export class TodoService {
\tprivate readonly tasks: Task[] = [];
\tprivate readonly requests = new Map<string, Task>();
\tprivate nextId = 1;

\tcreateTask(input: CreateTaskInput): Task {
\t\tif (!input.title.trim()) throw new Error("title is required");
\t\tif (!input.requestId.trim()) throw new Error("requestId is required");
\t\tconst existing = this.requests.get(input.requestId);
\t\tif (existing) return { ...existing };
\t\tconst task: Task = { id: this.nextId++, title: input.title, completed: input.completed ?? false };
\t\tthis.tasks.push(task);
\t\tthis.requests.set(input.requestId, task);
\t\treturn { ...task };
\t}

\tlistTasks(): Task[] {
\t\treturn this.tasks.map((task) => ({ ...task }));
\t}
}
`;

const GOOD_TEST = `import assert from "node:assert/strict";
import test from "node:test";
import { TodoService } from "../src/TodoService.ts";

test("createTask is idempotent for requestId", () => {
\tconst service = new TodoService();
\tconst first = service.createTask({ title: "draft", requestId: "req-1" });
\tconst duplicate = service.createTask({ title: "draft", requestId: "req-1" });
\tassert.deepEqual(duplicate, first);
\tassert.equal(service.listTasks().length, 1);
});

test("different requestId creates a new task and empty requestId fails", () => {
\tconst service = new TodoService();
\tservice.createTask({ title: "one", requestId: "req-1" });
\tservice.createTask({ title: "two", requestId: "req-2" });
\tassert.equal(service.listTasks().length, 2);
\tassert.throws(() => service.createTask({ title: "bad", requestId: " " }), /requestId/);
});
`;

const GOOD_README = `# TodoService fixture

Call \`createTask({ title, completed?, requestId })\` with a non-empty requestId. Repeating a requestId returns the original task without adding a duplicate.
`;

const BAD_SOURCE = `export interface Task { id: number; title: string; completed: boolean }
export interface CreateTaskInput { title: string; requestId: string; completed?: boolean }
export class TodoService {
\tprivate readonly tasks: Task[] = [];
\tcreateTask(input: CreateTaskInput): Task {
\t\tif (!input.requestId.trim()) throw new Error("requestId is required");
\t\tconst task = { id: this.tasks.length + 1, title: input.title, completed: input.completed ?? false };
\t\tthis.tasks.push(task);
\t\treturn { ...task };
\t}
\tlistTasks(): Task[] { return this.tasks.map((task) => ({ ...task })); }
}
`;

const BAD_TEST = `import assert from "node:assert/strict";
import test from "node:test";
import { TodoService } from "../src/TodoService.ts";
test("accepts requestId", () => {
\tconst service = new TodoService();
\tassert.equal(service.createTask({ title: "x", requestId: "r" }).title, "x");
});
`;

const DISCOVERY = JSON.stringify({
	summary: "TodoService, tests, and README require a bounded idempotency change.",
	files: [
		{ path: "src/TodoService.ts", reason: "implementation" },
		{ path: "test/TodoService.test.ts", reason: "coverage" },
		{ path: "README.md", reason: "documentation" },
	],
	risks: ["duplicate requests must not increment ids"],
});

const PLAN = JSON.stringify({
	summary: "Index tasks by requestId and cover the fixed contract.",
	files: ["README.md", "src/TodoService.ts", "test/TodoService.test.ts"],
	steps: ["validate requestId", "reuse existing task", "add tests and docs"],
	tests: ["same requestId", "different requestId", "empty requestId"],
	risks: ["defensive copies"],
});

const REVIEW_PASS = JSON.stringify({ verdict: "pass", summary: "The patch matches the contract.", findings: [] });

type FakeMode = "good" | "bad" | "escape" | "invalid-discovery" | "invalid-and-hanging-discovery" | "hang-discovery";

class FakeAgentRunner implements AgentRunner {
	readonly calls: AgentRole[] = [];
	private readonly mode: FakeMode;

	constructor(mode: FakeMode) {
		this.mode = mode;
	}

	async run(task: AgentTask, signal: AbortSignal): Promise<AgentRunResult> {
		this.calls.push(task.role);
		if (
			(this.mode === "hang-discovery" && (task.role === "code-scout" || task.role === "test-scout")) ||
			(this.mode === "invalid-and-hanging-discovery" && task.role === "test-scout")
		) {
			await new Promise<void>((resolvePromise) => {
				if (signal.aborted) resolvePromise();
				else signal.addEventListener("abort", () => resolvePromise(), { once: true });
			});
			return { role: task.role, exitCode: 1, output: "", stderr: "aborted", stopReason: "aborted" };
		}
		if ((this.mode === "invalid-discovery" || this.mode === "invalid-and-hanging-discovery") && task.role === "code-scout") {
			return { role: task.role, exitCode: 0, output: "not-json", stderr: "", stopReason: "stop" };
		}
		if (task.role === "code-scout" || task.role === "test-scout") return this.result(task.role, DISCOVERY);
		if (task.role === "planner") return this.result(task.role, PLAN);
		if (task.role === "implementer") {
			if (this.mode === "escape") await writeSandboxProbe(task.cwd);
			else await writeImplementation(task.cwd, this.mode === "bad");
			return this.result(
				task.role,
				JSON.stringify({
					summary: this.mode === "bad" ? "claims idempotency without implementing it" : "implemented idempotency",
					filesChanged: ["README.md", "src/TodoService.ts", "test/TodoService.test.ts"],
				}),
			);
		}
		if (task.role === "repair") {
			if (this.mode === "good") await writeImplementation(task.cwd, false);
			return this.result(
				task.role,
				JSON.stringify({
					summary: "single repair attempt",
					filesChanged: ["README.md", "src/TodoService.ts", "test/TodoService.test.ts"],
				}),
			);
		}
		return this.result(task.role, REVIEW_PASS);
	}

	private result(role: AgentRole, output: string): AgentRunResult {
		return { role, exitCode: 0, output, stderr: "", stopReason: "stop" };
	}
}

async function writeSandboxProbe(worktree: string): Promise<void> {
	const escapeTarget = join(worktree, "..", "escaped-by-agent.txt");
	const sandboxTest = `${GOOD_TEST}
import { writeFileSync } from "node:fs";
import { execFileSync } from "node:child_process";

test("agent-modified tests cannot escape verifier permissions", async () => {
\tassert.throws(() => writeFileSync(${JSON.stringify(escapeTarget)}, "escape"));
\tassert.throws(() => execFileSync(process.execPath, ["-e", "process.exit(0)"]));
\tawait assert.rejects(
\t\tfetch("http://example.com/"),
\t\t(error) => error?.cause?.code === "ERR_ACCESS_DENIED",
\t);
});
`;
	await Promise.all([
		writeFile(join(worktree, "src", "TodoService.ts"), GOOD_SOURCE),
		writeFile(join(worktree, "test", "TodoService.test.ts"), sandboxTest),
		writeFile(join(worktree, "README.md"), GOOD_README),
	]);
}

async function writeImplementation(worktree: string, bad: boolean): Promise<void> {
	await Promise.all([
		writeFile(join(worktree, "src", "TodoService.ts"), bad ? BAD_SOURCE : GOOD_SOURCE),
		writeFile(join(worktree, "test", "TodoService.test.ts"), bad ? BAD_TEST : GOOD_TEST),
		writeFile(join(worktree, "README.md"), bad ? "# TodoService\n\nrequestId is accepted.\n" : GOOD_README),
	]);
}

async function makeProject(t: test.TestContext): Promise<string> {
	const root = await mkdtemp(join(tmpdir(), "pi-egc-test-"));
	t.after(async () => {
		assert.ok(root.startsWith(tmpdir()));
		await rm(root, { recursive: true, force: true });
	});
	for (const directory of ["contract", "agents", "skills", "fixtures", "scripts", "src"]) {
		await cp(join(SOURCE_ROOT, directory), join(root, directory), { recursive: true });
	}
	await Promise.all([
		cp(join(SOURCE_ROOT, "package.json"), join(root, "package.json")),
		cp(join(SOURCE_ROOT, "package-lock.json"), join(root, "package-lock.json")),
	]);
	return root;
}

async function assertArtifacts(root: string, state: WorkflowState): Promise<void> {
	for (const name of [
		"events.jsonl",
		"baseline.json",
		"discovery-code.json",
		"discovery-tests.json",
		"plan.json",
		"approval.json",
		"patch.diff",
		"review.json",
		"verification.json",
		"report.md",
	]) {
		await access(join(root, "runs", state.runId, name));
	}
}

test("workflow completes only after exact hash approval and deterministic receipts", async (t) => {
	const root = await makeProject(t);
	const snapshots: WorkflowState[] = [];
	const runner = new FakeAgentRunner("good");
	const workflow = new EvidenceGatedWorkflow({ projectRoot: root, runner, onSnapshot: (state) => snapshots.push(state) });
	const planned = await workflow.start();
	assert.equal(planned.phase, "awaiting_approval");
	assert.ok(planned.planHash);
	assert.ok(planned.approvalHash);
	assert.deepEqual(runner.calls.slice(0, 2).sort(), ["code-scout", "test-scout"]);
	await assert.rejects(() => workflow.approve(planned.runId, "wrong-hash"), /hash mismatch/);

	const completed = await workflow.approve(planned.runId, planned.approvalHash ?? "");
	const completedVerification = await readJson<unknown>(join(root, "runs", completed.runId, "verification.json"));
	assert.equal(completed.phase, "completed", JSON.stringify(completedVerification));
	assert.equal(completed.repairCount, 0);
	await assertArtifacts(root, completed);
	const verification = await readJson<{ passed: boolean; commands: Array<{ exitCode: number }> }>(
		join(root, "runs", completed.runId, "verification.json"),
	);
	assert.equal(verification.passed, true);
	assert.deepEqual(verification.commands.map((command) => command.exitCode), [0, 0, 0]);
	assert.ok(snapshots.some((state) => state.phase === "awaiting_approval"));

	const events = (await readFile(join(root, "runs", completed.runId, "events.jsonl"), "utf8"))
		.trim()
		.split("\n")
		.map((line) => JSON.parse(line) as { sequence: number; kind: string; operationId?: string });
	assert.deepEqual(events.map((event) => event.sequence), events.map((_event, index) => index + 1));
	const intents = events.filter((event) => event.kind === "intent").map((event) => event.operationId).sort();
	const settled = events.filter((event) => event.kind === "settled").map((event) => event.operationId).sort();
	assert.deepEqual(settled, intents);
});

test("invalid scout JSON blocks before any approved write", async (t) => {
	const root = await makeProject(t);
	const workflow = new EvidenceGatedWorkflow({ projectRoot: root, runner: new FakeAgentRunner("invalid-discovery") });
	const state = await workflow.start();
	assert.equal(state.phase, "blocked");
	const runRoot = join(root, "runs", state.runId);
	assert.equal(
		await readFile(join(runRoot, "baseline", "src", "TodoService.ts"), "utf8"),
		await readFile(join(runRoot, "worktree", "src", "TodoService.ts"), "utf8"),
	);
	await assert.rejects(() => access(join(runRoot, "implementation.json")));
});

test("invalid scout output aborts and drains a hanging discovery sibling", async (t) => {
	const root = await makeProject(t);
	const runner = new FakeAgentRunner("invalid-and-hanging-discovery");
	const started = Date.now();
	const state = await new EvidenceGatedWorkflow({ projectRoot: root, runner }).start();
	assert.equal(state.phase, "blocked");
	assert.match(state.lastError ?? "", /JSON|discovery schema/i);
	assert.ok(Date.now() - started < 2_000);
	assert.deepEqual(runner.calls.slice(0, 2).sort(), ["code-scout", "test-scout"]);
	assert.equal(state.pendingOperation, undefined);
});

test("approval rejects adapter drift after planning", async (t) => {
	const root = await makeProject(t);
	const workflow = new EvidenceGatedWorkflow({ projectRoot: root, runner: new FakeAgentRunner("good") });
	const planned = await workflow.start();
	const reducerPath = join(root, "src", "reducer.ts");
	await writeFile(reducerPath, `${await readFile(reducerPath, "utf8")}\n// drift after approval prompt\n`);
	await assert.rejects(
		() => workflow.approve(planned.runId, planned.approvalHash ?? ""),
		/adapter or verifier changed|Runtime adapter hash drift/,
	);
	const state = await workflow.status(planned.runId);
	assert.equal(state.phase, "awaiting_approval");
});

test("reviewer success cannot override a failed oracle and only one repair is attempted", async (t) => {
	const root = await makeProject(t);
	const runner = new FakeAgentRunner("bad");
	const workflow = new EvidenceGatedWorkflow({ projectRoot: root, runner });
	const planned = await workflow.start();
	const state = await workflow.approve(planned.runId, planned.approvalHash ?? "");
	assert.equal(state.phase, "blocked");
	assert.equal(state.repairCount, 1);
	assert.equal(runner.calls.filter((role) => role === "repair").length, 1);
	const verification = await readJson<{ passed: boolean; commands: Array<{ exitCode: number }> }>(
		join(root, "runs", state.runId, "verification.json"),
	);
	assert.equal(verification.passed, false);
	assert.ok(verification.commands.some((command) => command.exitCode !== 0));
});

test("permission-confined verifier denies filesystem, child-process, and network escape", async (t) => {
	const root = await makeProject(t);
	const workflow = new EvidenceGatedWorkflow({ projectRoot: root, runner: new FakeAgentRunner("escape") });
	const planned = await workflow.start();
	const state = await workflow.approve(planned.runId, planned.approvalHash ?? "");
	const escapeVerification = await readJson<unknown>(join(root, "runs", state.runId, "verification.json"));
	assert.equal(state.phase, "completed", JSON.stringify(escapeVerification));
	await assert.rejects(() => access(join(root, "runs", state.runId, "escaped-by-agent.txt")));
	const verification = await readJson<{ passed: boolean; commands: Array<{ exitCode: number; args: string[] }> }>(
		join(root, "runs", state.runId, "verification.json"),
	);
	assert.equal(verification.passed, true);
	assert.equal(verification.commands.length, 3);
	assert.ok(verification.commands.every((command) => command.exitCode === 0));
	assert.ok(verification.commands[0]?.args.includes("--permission"));
});

test("cancel aborts both discovery children and converges to a terminal state", async (t) => {
	const root = await makeProject(t);
	let ready: ((runId: string) => void) | undefined;
	const discoveryReady = new Promise<string>((resolvePromise) => {
		ready = resolvePromise;
	});
	const runner = new FakeAgentRunner("hang-discovery");
	const workflow = new EvidenceGatedWorkflow({
		projectRoot: root,
		runner,
		onSnapshot(state) {
			if (state.phase === "discovering" && state.pendingOperation?.name === "parallel-discovery") ready?.(state.runId);
		},
	});
	const startPromise = workflow.start();
	const runId = await discoveryReady;
	while (runner.calls.filter((role) => role === "code-scout" || role === "test-scout").length < 2) {
		await new Promise<void>((resolvePromise) => setImmediate(resolvePromise));
	}
	const cancelPromise = workflow.cancel(runId);
	const [startedState, cancelledState] = await Promise.all([startPromise, cancelPromise]);
	assert.equal(startedState.phase, "cancelled");
	assert.equal(cancelledState.phase, "cancelled");
	assert.equal(runner.calls.filter((role) => role === "code-scout" || role === "test-scout").length, 2);
});

test("event log reconciles a durable settlement with stale state without duplicating settlement", async (t) => {
	const root = await makeProject(t);
	const runner = new FakeAgentRunner("good");
	const firstWorkflow = new EvidenceGatedWorkflow({ projectRoot: root, runner });
	const planned = await firstWorkflow.start();
	const runRoot = join(root, "runs", planned.runId);
	await writeImplementation(join(runRoot, "worktree"), false);
	const approval: ApprovalArtifact = {
		runId: planned.runId,
		planHash: planned.planHash ?? "",
		baselineHash: planned.baselineHash ?? "",
		contractHash: planned.contractHash,
		runtimeHash: planned.runtimeHash,
		approvalHash: planned.approvalHash ?? "",
		decision: "approved",
		decidedAt: new Date().toISOString(),
	};
	await writeJsonAtomic(join(runRoot, "approval.json"), approval);
	const operationStartedAt = new Date().toISOString();
	const committed: WorkflowState = {
		...planned,
		phase: "implementing",
		updatedAt: new Date().toISOString(),
	};
	const interrupted: WorkflowState = {
		...planned,
		phase: "implementing",
		pendingOperation: {
			id: "crashed-operation",
			name: "implement-change",
			phase: "implementing",
			startedAt: operationStartedAt,
		},
	};
	const existingEvents = (await readFile(join(runRoot, "events.jsonl"), "utf8")).trim().split("\n");
	const existingLast = JSON.parse(existingEvents.at(-1) ?? "{}") as { sequence: number };
	await appendEvent(join(runRoot, "events.jsonl"), {
		schemaVersion: 1,
		sequence: existingLast.sequence + 1,
		timestamp: operationStartedAt,
		runId: planned.runId,
		kind: "intent",
		phase: "implementing",
		operationId: "crashed-operation",
		name: "implement-change",
	});
	await appendEvent(join(runRoot, "events.jsonl"), {
		schemaVersion: 1,
		sequence: existingLast.sequence + 2,
		timestamp: new Date().toISOString(),
		runId: planned.runId,
		kind: "settled",
		phase: "implementing",
		operationId: "crashed-operation",
		name: "implement-change",
		status: "ok",
		details: { committedState: committed },
	});
	await writeJsonAtomic(join(runRoot, "state.json"), interrupted);
	const previousEvents = (await readFile(join(runRoot, "events.jsonl"), "utf8")).trim().split("\n");
	const previousLast = JSON.parse(previousEvents.at(-1) ?? "{}") as { sequence: number };

	const resumedWorkflow = new EvidenceGatedWorkflow({ projectRoot: root, runner });
	const resumed = await resumedWorkflow.resume(planned.runId);
	const resumedVerification = await readJson<unknown>(join(runRoot, "verification.json"));
	assert.equal(resumed.phase, "completed", JSON.stringify(resumedVerification));
	const currentEvents = (await readFile(join(runRoot, "events.jsonl"), "utf8"))
		.trim()
		.split("\n")
		.map((line) => JSON.parse(line) as { sequence: number });
	assert.equal(currentEvents[previousEvents.length]?.sequence, previousLast.sequence + 1);
	const crashedSettlements = (await readFile(join(runRoot, "events.jsonl"), "utf8"))
		.trim()
		.split("\n")
		.map((line) => JSON.parse(line) as { kind: string; operationId?: string })
		.filter((event) => event.kind === "settled" && event.operationId === "crashed-operation");
	assert.equal(crashedSettlements.length, 1);
});
