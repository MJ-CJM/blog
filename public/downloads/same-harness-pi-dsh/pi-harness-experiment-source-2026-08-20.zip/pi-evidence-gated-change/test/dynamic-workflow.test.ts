import assert from "node:assert/strict";
import { mkdtemp, mkdir, readFile, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { dirname, join, resolve } from "node:path";
import test from "node:test";
import type { ExtensionAPI, ExtensionCommandContext } from "@earendil-works/pi-coding-agent";
import { isHardQuotaDiagnostic, sanitizeDynamicDiagnostic, sanitizeDynamicDiagnosticJson } from "../src/dynamic-diagnostics.ts";
import { DynamicWorkflowEngine } from "../src/dynamic-engine.ts";
import { loadDynamicConfig, parseDynamicWorkflowSource, resolveDynamicModels } from "../src/dynamic-parser.ts";
import {
	DYNAMIC_WORKFLOW_RESULT_ENTRY_TYPE,
	DYNAMIC_WORKFLOW_RESULT_PREVIEW_CHARS,
	createDynamicWorkflowResultEntry,
	formatDynamicWorkflowResultEntry,
	registerDynamicWorkflowResultRenderer,
	type DynamicWorkflowResultEntryData,
} from "../src/dynamic-result.ts";
import { PiDynamicAgentRunner } from "../src/dynamic-runner.ts";
import { displayStoredDynamicWorkflowResult, runDynamicWorkflowForeground } from "../src/dynamic-ui.ts";
import type { DynamicAgentProgressListener, DynamicAgentResult, DynamicAgentRunner, DynamicAgentTask, DynamicRunState } from "../src/dynamic-types.ts";

const CANONICAL_WORKFLOW = resolve("dynamic-workflow/shared/workflows/multi-model-review.js");
const SECRET_DIAGNOSTIC = [
	'api_key="quoted secret value with spaces"',
	"token=unquoted secret value with spaces; next=visible",
	"Bearer bearer-secret-value-123456",
	"ghp_abcdefghijklmnopqrstuvwxyz123456",
	"github_pat_11AAabcdefghijklmnopqrstuvwxyz123456",
	"AKIA1234567890ABCDEF",
	"sk-do-not-persist-123456",
].join("\n");

interface TestCleanup {
	after(callback: () => void | Promise<void>): void;
}

class FakeDynamicRunner implements DynamicAgentRunner {
	readonly tasks: DynamicAgentTask[] = [];
	active = 0;
	maxActive = 0;
	aborted = 0;
	readonly hang: boolean;
	failAll = false;
	failureStderr = "injected failure";
	successOutput: string | undefined;
	retryOnce = false;
	abortDelayMs = 0;
	readonly failLabels = new Set<string>();

	constructor(hang = false) {
		this.hang = hang;
	}

	async run(task: DynamicAgentTask, signal: AbortSignal, onProgress?: DynamicAgentProgressListener): Promise<DynamicAgentResult> {
		this.tasks.push(structuredClone(task));
		this.active++;
		this.maxActive = Math.max(this.maxActive, this.active);
		try {
			if (this.retryOnce) {
				onProgress?.({
					type: "retry",
					attempt: 1,
					maxAttempts: 3,
					delayMs: 2_000,
					diagnostic: "429: temporary rate limit",
					hardQuota: false,
				});
			}
			if (this.hang) {
				await new Promise<void>((resolvePromise) => {
					const abort = (): void => {
						this.aborted++;
						if (this.abortDelayMs > 0) setTimeout(resolvePromise, this.abortDelayMs);
						else resolvePromise();
					};
					if (signal.aborted) abort();
					else signal.addEventListener("abort", abort, { once: true });
				});
				return { exitCode: 1, output: "", stderr: "aborted", stopReason: "aborted" };
			}
			await new Promise((resolvePromise) => setTimeout(resolvePromise, 10));
			if (this.failAll || this.failLabels.has(task.label)) {
				return { exitCode: 1, output: "", stderr: this.failureStderr, stopReason: "error" };
			}
			return { exitCode: 0, output: this.successOutput ?? `${task.label}-output`, stderr: "", stopReason: "stop" };
		} finally {
			this.active--;
		}
	}
}

function config(maxAgents = 8, runTimeoutMs = 2_000): object {
	const agentTimeoutMs = Math.max(100, Math.min(1_000, runTimeoutMs));
	const agentIdleTimeoutMs = Math.max(100, Math.min(500, agentTimeoutMs));
	return {
		schemaVersion: 1,
		limits: {
			maxParallel: Math.min(3, maxAgents),
			maxAgents,
			maxItemsPerCall: 16,
			syncTimeoutMs: 50,
			agentIdleTimeoutMs,
			agentTimeoutMs,
			runTimeoutMs,
			maxSourceBytes: 65_536,
			maxResultBytes: 1_048_576,
		},
		profiles: {
			fast: { provider: "provider-fast", model: "model-fast", thinking: "low" },
			deep: { provider: "provider-deep", model: "model-deep", thinking: "high" },
			review: { provider: "provider-review", model: "model-review" },
		},
	};
}

function workflowSource(name: string, body: string): string {
	return `export const meta = ${JSON.stringify({ name, description: `${name} test workflow`, phases: [{ title: "test" }] })};\n${body}\n`;
}

async function makeProject(cleanup: TestCleanup, source: string, workflowName = "test", configuration = config()): Promise<string> {
	const root = await mkdtemp(join(tmpdir(), "pi-dynamic-workflow-"));
	cleanup.after(() => rm(root, { recursive: true, force: true }));
	const workflowPath = join(root, "dynamic-workflow", "shared", "workflows", `${workflowName}.js`);
	const configPath = join(root, "dynamic-workflow", "pi", "model-profiles.json");
	await mkdir(dirname(workflowPath), { recursive: true });
	await mkdir(dirname(configPath), { recursive: true });
	await writeFile(workflowPath, source, "utf8");
	await writeFile(configPath, `${JSON.stringify(configuration, null, 2)}\n`, "utf8");
	return root;
}

async function waitForTerminal(engine: DynamicWorkflowEngine, runId: string): Promise<DynamicRunState> {
	for (let attempt = 0; attempt < 200; attempt++) {
		const state = await engine.status(runId);
		if (["completed", "failed", "cancelled"].includes(state.status)) return state;
		await new Promise((resolvePromise) => setTimeout(resolvePromise, 10));
	}
	throw new Error(`Run ${runId} did not settle`);
}

interface FakeDynamicUiLog {
	notifications: Array<{ message: string; type?: string }>;
	statuses: Array<{ key: string; text: string | undefined }>;
	widgets: Array<{ key: string; content: string[] | undefined }>;
	workingMessages: Array<string | undefined>;
	terminalHandler?: (data: string) => { consume?: boolean; data?: string } | undefined;
	unsubscribed: number;
	resultEntries: DynamicWorkflowResultEntryData[];
}

function fakeCommandContext(mode: "tui" | "rpc" | "json" | "print", cwd: string): { ctx: ExtensionCommandContext; log: FakeDynamicUiLog } {
	const log: FakeDynamicUiLog = {
		notifications: [],
		statuses: [],
		widgets: [],
		workingMessages: [],
		unsubscribed: 0,
		resultEntries: [],
	};
	const ctx = {
		mode,
		cwd,
		ui: {
			notify(message: string, type?: string) {
				log.notifications.push({ message, ...(type ? { type } : {}) });
			},
			setStatus(key: string, text: string | undefined) {
				log.statuses.push({ key, text });
			},
			setWorkingMessage(message?: string) {
				log.workingMessages.push(message);
			},
			setWidget(key: string, content: string[] | undefined) {
				log.widgets.push({ key, content: content ? [...content] : undefined });
			},
			onTerminalInput(handler: (data: string) => { consume?: boolean; data?: string } | undefined) {
				log.terminalHandler = handler;
				return () => {
					log.unsubscribed++;
				};
			},
		},
	} as unknown as ExtensionCommandContext;
	return { ctx, log };
}

function captureResult(log: FakeDynamicUiLog): (entry: DynamicWorkflowResultEntryData) => void {
	return (entry) => log.resultEntries.push(structuredClone(entry));
}

test("saved workflow parser requires an exact first-line JSON meta literal", async (t) => {
	const canonical = await readFile(CANONICAL_WORKFLOW, "utf8");
	const parsed = parseDynamicWorkflowSource(canonical, CANONICAL_WORKFLOW, 65_536);
	assert.equal(parsed.meta.name, "multi-model-review");
	assert.deepEqual(parsed.meta.phases?.map((phase) => phase.title), ["independent-reviews", "challenge-reviews", "synthesis"]);
	assert.throws(
		() => parseDynamicWorkflowSource(`// comment\n${canonical}`, CANONICAL_WORKFLOW, 65_536),
		/First line must be exactly/,
	);
	assert.throws(
		() => parseDynamicWorkflowSource('export const meta = {"name":"multi-model-review","description":"x","extra":true};\nreturn null;', CANONICAL_WORKFLOW, 65_536),
		/meta.extra is not recognized/,
	);

	const project = await makeProject(t, workflowSource("test", "return null;"), "test", {
		...config(),
		profiles: { fast: {}, deep: {}, review: {} },
	});
	const loaded = await loadDynamicConfig(join(project, "dynamic-workflow", "pi", "model-profiles.json"));
	assert.throws(() => resolveDynamicModels(loaded, undefined), /no parent Pi model is active/);
	assert.equal(resolveDynamicModels(loaded, { provider: "parent", model: "model", thinking: "medium" }).fast?.model, "model");
});

test("dynamic timeout limits are required, bounded, and ordered idle <= hard <= run", async (t) => {
	const project = await makeProject(t, workflowSource("test", "return null;"));
	const configPath = join(project, "dynamic-workflow", "pi", "model-profiles.json");
	const valid = config(8, 2_000) as {
		limits: { agentIdleTimeoutMs: number; agentTimeoutMs: number };
		[key: string]: unknown;
	};
	valid.limits.agentIdleTimeoutMs = 400;
	valid.limits.agentTimeoutMs = 1_200;
	await writeFile(configPath, `${JSON.stringify(valid, null, 2)}\n`, "utf8");
	const loaded = await loadDynamicConfig(configPath);
	assert.equal(loaded.limits.agentIdleTimeoutMs, 400);
	assert.equal(loaded.limits.agentTimeoutMs, 1_200);

	const invalidCases: Array<{
		name: string;
		mutate(limits: Record<string, unknown>): void;
		expected: RegExp;
	}> = [
		{
			name: "missing idle timeout",
			mutate: (limits) => {
				delete limits.agentIdleTimeoutMs;
			},
			expected: /limits\.agentIdleTimeoutMs must be an integer between 100 and 3600000/,
		},
		{
			name: "missing hard timeout",
			mutate: (limits) => {
				delete limits.agentTimeoutMs;
			},
			expected: /limits\.agentTimeoutMs must be an integer between 100 and 3600000/,
		},
		{
			name: "idle below lower bound",
			mutate: (limits) => {
				limits.agentIdleTimeoutMs = 99;
			},
			expected: /limits\.agentIdleTimeoutMs must be an integer between 100 and 3600000/,
		},
		{
			name: "fractional hard timeout",
			mutate: (limits) => {
				limits.agentTimeoutMs = 1_200.5;
			},
			expected: /limits\.agentTimeoutMs must be an integer between 100 and 3600000/,
		},
		{
			name: "idle exceeds hard timeout",
			mutate: (limits) => {
				limits.agentIdleTimeoutMs = 1_300;
				limits.agentTimeoutMs = 1_200;
			},
			expected: /limits\.agentIdleTimeoutMs cannot exceed limits\.agentTimeoutMs/,
		},
		{
			name: "hard exceeds run timeout",
			mutate: (limits) => {
				limits.agentTimeoutMs = 2_001;
			},
			expected: /limits\.agentTimeoutMs cannot exceed limits\.runTimeoutMs/,
		},
	];
	for (const invalid of invalidCases) {
		const candidate = structuredClone(valid) as unknown as { limits: Record<string, unknown> };
		invalid.mutate(candidate.limits);
		await writeFile(configPath, `${JSON.stringify(candidate, null, 2)}\n`, "utf8");
		await assert.rejects(() => loadDynamicConfig(configPath), invalid.expected, invalid.name);
	}
});

test("multi-model review executes parallel and pipeline stages with exact profile routing and artifacts", async (t) => {
	const source = await readFile(CANONICAL_WORKFLOW, "utf8");
	const project = await makeProject(t, source, "multi-model-review");
	const runner = new FakeDynamicRunner();
	const engine = new DynamicWorkflowEngine({ projectRoot: project, runner });
	const started = await engine.start("multi-model-review", "Review this API", project, undefined);
	const state = await waitForTerminal(engine, started.runId);
	assert.equal(state.status, "completed");
	assert.equal(state.agentsStarted, 7);
	assert.equal(state.agentsCompleted, 7);
	assert.equal(runner.maxActive, 3);
	assert.equal(runner.tasks[0]?.provider, "provider-fast");
	assert.equal(runner.tasks[0]?.thinking, "low");
	assert.equal(runner.tasks[1]?.provider, "provider-deep");
	assert.equal(runner.tasks[2]?.provider, "provider-review");
	assert.equal(runner.tasks.at(-1)?.label, "final-synthesis");
	assert.ok(runner.tasks.every((task) => task.idleTimeoutMs === 500));
	assert.ok(runner.tasks.every((task) => task.timeoutMs === 1_000));
	assert.match(runner.tasks[3]?.prompt ?? "", /fast-review-output|deep-review-output|review-review-output/);
	const runRoot = join(project, "dynamic-workflow", "runs", state.runId);
	assert.equal(await readFile(join(runRoot, "workflow.js"), "utf8"), source);
	const result = JSON.parse(await readFile(join(runRoot, "result.json"), "utf8")) as { value: string };
	assert.equal(result.value, "final-synthesis-output");
	const events = (await readFile(join(runRoot, "events.jsonl"), "utf8")).trim().split("\n").map((line) => JSON.parse(line) as {
		sequence: number;
		type: string;
		message: string;
		details?: Record<string, unknown>;
	});
	assert.deepEqual(events.map((event) => event.sequence), events.map((_event, index) => index + 1));
	assert.deepEqual(events.filter((event) => event.type === "phase").map((event) => event.message), ["independent-reviews", "challenge-reviews", "synthesis"]);
	const agentStarts = events.filter((event) => event.type === "agent-start");
	assert.equal(agentStarts.length, 7);
	assert.ok(agentStarts.every((event) => event.details?.idleTimeoutMs === 500));
	assert.ok(agentStarts.every((event) => event.details?.timeoutMs === 1_000));
});

test("native agent defaults inherit parent model, current phase, and deterministic labels", async (t) => {
	const source = workflowSource(
		"test",
		'phase("test"); const first = await agent("inspect"); return await agent(`follow ${first}`, {model:"override-model"});',
	);
	const project = await makeProject(t, source, "test", {
		...config(),
		profiles: { fast: {}, deep: {}, review: {} },
	});
	const runner = new FakeDynamicRunner();
	const engine = new DynamicWorkflowEngine({ projectRoot: project, runner });
	const started = await engine.start("test", "native defaults", project, { provider: "parent-provider", model: "parent-model", thinking: "medium" });
	const state = await waitForTerminal(engine, started.runId);
	assert.equal(state.status, "completed");
	assert.deepEqual(
		runner.tasks.map(({ provider, model, thinking, label, phase }) => ({ provider, model, thinking, label, phase })),
		[
			{ provider: "parent-provider", model: "parent-model", thinking: "medium", label: "inspect", phase: "test" },
			{ provider: "parent-provider", model: "override-model", thinking: undefined, label: "follow inspect-output", phase: "test" },
		],
	);
});

test("a terminal workflow ignores chained Agent calls scheduled after completion", async (t) => {
	const source = workflowSource(
		"test",
		'phase("test"); void agent("first").then(() => agent("late")); return "done";',
	);
	const project = await makeProject(t, source, "test", {
		...config(),
		profiles: { fast: {}, deep: {}, review: {} },
	});
	const runner = new FakeDynamicRunner();
	const engine = new DynamicWorkflowEngine({ projectRoot: project, runner });
	const started = await engine.start("test", "terminal race", project, { provider: "parent", model: "model" });
	const state = await waitForTerminal(engine, started.runId);
	assert.equal(state.status, "completed");
	assert.equal(state.agentsStarted, 1);
	assert.equal(state.agentsCompleted, 1);
	assert.deepEqual(runner.tasks.map((task) => task.prompt), ["first"]);
	await new Promise((resolvePromise) => setTimeout(resolvePromise, 25));
	assert.deepEqual(runner.tasks.map((task) => task.prompt), ["first"]);
});

test("agent and item caps fail closed and drain active fake agents", async (t) => {
	const source = workflowSource(
		"test",
		'phase("test"); return await parallel([() => agent("one", {...args.models.fast,label:"one",phase:"test"}), () => agent("two", {...args.models.fast,label:"two",phase:"test"})]);',
	);
	const project = await makeProject(t, source, "test", config(1));
	const runner = new FakeDynamicRunner();
	const engine = new DynamicWorkflowEngine({ projectRoot: project, runner });
	const started = await engine.start("test", "cap", project, undefined);
	const state = await waitForTerminal(engine, started.runId);
	assert.equal(state.status, "failed");
	assert.match(state.error ?? "", /Agent cap exceeded/);
	assert.equal(state.activeAgents, 0);
	assert.equal(runner.active, 0);
});

test("cancel aborts active agents and converges in the same process", async (t) => {
	const source = await readFile(CANONICAL_WORKFLOW, "utf8");
	const project = await makeProject(t, source, "multi-model-review");
	const runner = new FakeDynamicRunner(true);
	const engine = new DynamicWorkflowEngine({ projectRoot: project, runner });
	const started = await engine.start("multi-model-review", "cancel this", project, undefined);
	for (let attempt = 0; attempt < 100 && runner.tasks.length < 3; attempt++) {
		await new Promise((resolvePromise) => setTimeout(resolvePromise, 5));
	}
	const state = await engine.cancel(started.runId);
	assert.equal(state.status, "cancelled");
	assert.equal(state.activeAgents, 0);
	assert.equal(runner.aborted, 3);
	assert.equal(runner.active, 0);
});

test("user cancellation remains authoritative when Agent cleanup crosses the run deadline", async (t) => {
	const source = workflowSource(
		"test",
		'phase("test"); return await agent("hang", {...args.models.fast,label:"delayed-cleanup",phase:"test"});',
	);
	const project = await makeProject(t, source, "test", config(8, 300));
	const runner = new FakeDynamicRunner(true);
	runner.abortDelayMs = 450;
	const engine = new DynamicWorkflowEngine({ projectRoot: project, runner });
	const started = await engine.start("test", "cancel before deadline", project, undefined);
	for (let attempt = 0; attempt < 100 && runner.tasks.length < 1; attempt++) {
		await new Promise((resolvePromise) => setTimeout(resolvePromise, 2));
	}
	assert.equal(runner.tasks.length, 1);
	const state = await engine.cancel(started.runId);
	assert.equal(state.status, "cancelled");
	assert.doesNotMatch(state.error ?? "", /Dynamic Workflow timed out/);
	assert.match(state.error ?? "", /cancel/i);
	assert.equal(state.activeAgents, 0);
	assert.equal(runner.aborted, 1);
	assert.equal(runner.active, 0);
});

test("multi-model review fails when review quorum or final synthesis fails", async (t) => {
	const source = await readFile(CANONICAL_WORKFLOW, "utf8");
	const allFailedProject = await makeProject(t, source, "multi-model-review");
	const allFailedRunner = new FakeDynamicRunner();
	allFailedRunner.failAll = true;
	allFailedRunner.failureStderr = [
		'429: {"code":"1308","message":"已达到 5 小时的使用上限","token":"sk-do-not-persist-123456"}',
		'429: {"code":"1308","message":"已达到 5 小时的使用上限","token":"sk-do-not-persist-123456"}',
	].join("\n");
	const allFailedEngine = new DynamicWorkflowEngine({ projectRoot: allFailedProject, runner: allFailedRunner });
	const allFailedRun = await allFailedEngine.start("multi-model-review", "all fail", allFailedProject, undefined);
	const allFailedState = await waitForTerminal(allFailedEngine, allFailedRun.runId);
	assert.equal(allFailedState.status, "failed");
	assert.match(allFailedState.error ?? "", /at least two successful independent reviews/);
	assert.equal(allFailedState.agentsStarted, 3);
	assert.equal(allFailedState.agentsCompleted, 0);
	assert.equal(allFailedState.failureCauses?.length, 3);
	assert.ok(allFailedState.failureCauses?.every((cause) => cause.includes("429") && cause.includes("[REDACTED]")));
	const allFailedRunRoot = join(allFailedProject, "dynamic-workflow", "runs", allFailedState.runId);
	const persistedFailure = `${await readFile(join(allFailedRunRoot, "state.json"), "utf8")}\n${await readFile(join(allFailedRunRoot, "events.jsonl"), "utf8")}`;
	assert.doesNotMatch(persistedFailure, /sk-do-not-persist/);
	assert.doesNotMatch(persistedFailure, /\"stderr\"/);

	const finalFailedProject = await makeProject(t, source, "multi-model-review");
	const finalFailedRunner = new FakeDynamicRunner();
	finalFailedRunner.failLabels.add("final-synthesis");
	const finalFailedEngine = new DynamicWorkflowEngine({ projectRoot: finalFailedProject, runner: finalFailedRunner });
	const finalFailedRun = await finalFailedEngine.start("multi-model-review", "final fail", finalFailedProject, undefined);
	const finalFailedState = await waitForTerminal(finalFailedEngine, finalFailedRun.runId);
	assert.equal(finalFailedState.status, "failed");
	assert.match(finalFailedState.error ?? "", /final synthesis failed/);
	assert.equal(finalFailedState.agentsStarted, 7);
	assert.equal(finalFailedState.agentsCompleted, 6);
});

test("invalid import and non-JSON result fail without invoking a model", async (t) => {
	const importProject = await makeProject(t, workflowSource("test", 'import "node:fs"; return null;'));
	const importRunner = new FakeDynamicRunner();
	const importEngine = new DynamicWorkflowEngine({ projectRoot: importProject, runner: importRunner });
	const importRun = await importEngine.start("test", "invalid import", importProject, undefined);
	assert.equal((await waitForTerminal(importEngine, importRun.runId)).status, "failed");
	assert.equal(importRunner.tasks.length, 0);

	const resultProject = await makeProject(t, workflowSource("test", "return () => undefined;"));
	const resultRunner = new FakeDynamicRunner();
	const resultEngine = new DynamicWorkflowEngine({ projectRoot: resultProject, runner: resultRunner });
	const resultRun = await resultEngine.start("test", "invalid result", resultProject, undefined);
	const resultState = await waitForTerminal(resultEngine, resultRun.runId);
	assert.equal(resultState.status, "failed");
	assert.match(resultState.error ?? "", /not plain JSON data/);
	assert.equal(resultRunner.tasks.length, 0);
});

test("workflow globals omit host capabilities and synchronous loops time out", async (t) => {
	const globalsSource = workflowSource(
		"test",
		'return {require:typeof require,process:typeof process,fs:typeof fs,shell:typeof shell};',
	);
	const globalsProject = await makeProject(t, globalsSource);
	const globalsEngine = new DynamicWorkflowEngine({ projectRoot: globalsProject, runner: new FakeDynamicRunner() });
	const globalsRun = await globalsEngine.start("test", "globals", globalsProject, undefined);
	const globalsState = await waitForTerminal(globalsEngine, globalsRun.runId);
	assert.equal(globalsState.status, "completed");
	const globalsResult = JSON.parse(await readFile(join(globalsProject, "dynamic-workflow", "runs", globalsRun.runId, "result.json"), "utf8")) as { value: Record<string, string> };
	assert.deepEqual(globalsResult.value, { require: "undefined", process: "undefined", fs: "undefined", shell: "undefined" });

	const timeoutProject = await makeProject(t, workflowSource("test", "while (true) {}"));
	const timeoutEngine = new DynamicWorkflowEngine({ projectRoot: timeoutProject, runner: new FakeDynamicRunner() });
	const timeoutRun = await timeoutEngine.start("test", "timeout", timeoutProject, undefined);
	const timeoutState = await waitForTerminal(timeoutEngine, timeoutRun.runId);
	assert.equal(timeoutState.status, "failed");
	assert.match(timeoutState.error ?? "", /timed out/);

	const continuationProject = await makeProject(t, workflowSource("test", "await Promise.resolve(); while (true) {}"), "test", config(8, 100));
	const continuationEngine = new DynamicWorkflowEngine({ projectRoot: continuationProject, runner: new FakeDynamicRunner() });
	const continuationRun = await continuationEngine.start("test", "continuation timeout", continuationProject, undefined);
	const continuationState = await waitForTerminal(continuationEngine, continuationRun.runId);
	assert.equal(continuationState.status, "failed");
	assert.equal(continuationState.error, "Dynamic Workflow timed out");
});

test("foreground Dynamic Workflow renders live TUI/RPC progress, waits for completion, and cleans UI state", async (t) => {
	const source = workflowSource(
		"test",
		'phase("test"); return await agent("inspect", {...args.models.fast,label:"ui-agent",phase:"test"});',
	);
	const project = await makeProject(t, source);
	for (const mode of ["tui", "rpc"] as const) {
		const runner = new FakeDynamicRunner();
		runner.retryOnce = true;
		const engine = new DynamicWorkflowEngine({ projectRoot: project, runner });
		const { ctx, log } = fakeCommandContext(mode, project);
		const state = await runDynamicWorkflowForeground({
			engine,
			ctx,
			workflowId: "test",
			task: `${mode} foreground`,
			cwd: project,
			parent: undefined,
			projectRoot: project,
			publishResult: captureResult(log),
		});
		assert.equal(state?.status, "completed");
		assert.equal(state?.agentsCompleted, 1);
		assert.ok(log.widgets.some(({ content }) => content?.some((line) => /successful=1/.test(line))));
		assert.ok(log.widgets.some(({ content }) => content?.some((line) => /recent Agent events/.test(line))));
		assert.ok(log.widgets.some(({ content }) => content?.some((line) => /retry 1\/3/.test(line) && /wait 2s/.test(line))));
		assert.equal(log.widgets.at(-1)?.content, undefined);
		assert.equal(log.statuses.at(-1)?.text, undefined);
		assert.equal(log.workingMessages.at(-1), undefined);
		assert.equal(log.resultEntries.length, 1);
		assert.equal(log.resultEntries[0]?.preview, "ui-agent-output");
		assert.match(log.resultEntries[0]?.resultPath ?? "", /result\.json$/);
		const persistedEvents = await readFile(join(project, "dynamic-workflow", "runs", state?.runId ?? "missing", "events.jsonl"), "utf8");
		assert.match(persistedEvents, /"type":"agent-retry"/);
		assert.match(persistedEvents, /"delayMs":2000/);
		if (mode === "tui") {
			assert.equal(log.notifications.length, 0);
			assert.ok(log.widgets.some(({ content }) => content?.includes("press Esc to cancel this foreground run")));
			assert.equal(log.unsubscribed, 1);
		} else {
			assert.equal(log.notifications.length, 1);
			assert.match(log.notifications[0]?.message ?? "", /ui-agent-output/);
			assert.match(log.notifications[0]?.message ?? "", /result=.*result\.json/);
			assert.equal(log.terminalHandler, undefined);
		}
	}
	await writeFile(
		join(project, "dynamic-workflow", "shared", "workflows", "test.js"),
		workflowSource("test", 'return "长".repeat(13050);'),
		"utf8",
	);
	const largeEngine = new DynamicWorkflowEngine({ projectRoot: project, runner: new FakeDynamicRunner() });
	const largeUi = fakeCommandContext("tui", project);
	const largeState = await runDynamicWorkflowForeground({
		engine: largeEngine,
		ctx: largeUi.ctx,
		workflowId: "test",
		task: "large result",
		cwd: project,
		parent: undefined,
		projectRoot: project,
		publishResult: captureResult(largeUi.log),
	});
	assert.equal(largeUi.log.resultEntries.length, 1);
	assert.equal(largeUi.log.resultEntries[0]?.previewTruncated, true);
	assert.equal(largeUi.log.resultEntries[0]?.preview.length, DYNAMIC_WORKFLOW_RESULT_PREVIEW_CHARS);
	assert.match(largeUi.log.resultEntries[0]?.preview ?? "", /preview truncated/);
	assert.equal(largeUi.log.notifications.length, 0);
	const fullLargeResult = JSON.parse(
		await readFile(join(project, "dynamic-workflow", "runs", largeState?.runId ?? "missing", "result.json"), "utf8"),
	) as { value: string };
	assert.equal(fullLargeResult.value, "长".repeat(13_050));

	for (const mode of ["json", "print"] as const) {
		const unsupportedProject = await makeProject(t, source);
		const unsupportedRunner = new FakeDynamicRunner();
		const unsupportedEngine = new DynamicWorkflowEngine({ projectRoot: unsupportedProject, runner: unsupportedRunner });
		let startCalls = 0;
		const originalStart = unsupportedEngine.start.bind(unsupportedEngine);
		unsupportedEngine.start = async (...args) => {
			startCalls++;
			return await originalStart(...args);
		};
		const unsupportedUi = fakeCommandContext(mode, unsupportedProject);
		await assert.rejects(
			() =>
				runDynamicWorkflowForeground({
					engine: unsupportedEngine,
					ctx: unsupportedUi.ctx,
					workflowId: "test",
					task: "must not start",
					cwd: unsupportedProject,
					parent: undefined,
					projectRoot: unsupportedProject,
					publishResult: captureResult(unsupportedUi.log),
				}),
			/requires Pi TUI or RPC mode/,
		);
		assert.equal(startCalls, 0);
		assert.equal(unsupportedRunner.tasks.length, 0);
		assert.equal(unsupportedUi.log.widgets.length, 0);
	}
});

test("foreground failure shows the provider quota cause with the workflow gate error and no secret", async (t) => {
	const sanitized = sanitizeDynamicDiagnostic(SECRET_DIAGNOSTIC);
	for (const secret of [
		"quoted secret value with spaces",
		"unquoted secret value with spaces",
		"bearer-secret-value-123456",
		"ghp_abcdefghijklmnopqrstuvwxyz123456",
		"github_pat_11AAabcdefghijklmnopqrstuvwxyz123456",
		"AKIA1234567890ABCDEF",
		"sk-do-not-persist-123456",
	]) {
		assert.doesNotMatch(sanitized, new RegExp(secret));
	}
	assert.match(sanitized, /\[REDACTED\]/);
	assert.deepEqual(
		sanitizeDynamicDiagnosticJson({
			api_key: "plain value without a recognizable prefix",
			nested: { access_token: "another plain value", message: "safe" },
		}),
		{ api_key: "[REDACTED]", nested: { access_token: "[REDACTED]", message: "safe" } },
	);
	const source = workflowSource(
		"test",
		'phase("test"); await agent("inspect", {...args.models.fast,label:"quota-agent",phase:"test"}); throw new Error("review quorum failed");',
	);
	const project = await makeProject(t, source);
	const runner = new FakeDynamicRunner();
	runner.failAll = true;
	runner.failureStderr = '429: {"code":"1308","message":"已达到 5 小时的使用上限","api_key":"sk-do-not-persist-123456"}';
	const engine = new DynamicWorkflowEngine({ projectRoot: project, runner });
	const { ctx, log } = fakeCommandContext("tui", project);
	const state = await runDynamicWorkflowForeground({
		engine,
		ctx,
		workflowId: "test",
		task: "show root cause",
		cwd: project,
		parent: undefined,
		projectRoot: project,
		publishResult: captureResult(log),
	});
	assert.equal(state?.status, "failed");
	assert.ok(state);
	assert.match(log.notifications.at(-1)?.message ?? "", /review quorum failed/);
	assert.match(log.notifications.at(-1)?.message ?? "", /429/);
	assert.match(log.notifications.at(-1)?.message ?? "", /使用上限/);
	assert.doesNotMatch(log.notifications.at(-1)?.message ?? "", /sk-do-not-persist/);
	assert.ok(log.widgets.some(({ content }) => content?.some((line) => /failed=1/.test(line))));
	assert.equal(log.widgets.at(-1)?.content, undefined);
	assert.equal(log.resultEntries.length, 0);
	await assert.rejects(() => engine.completedResult(state.runId), /status=failed/);

	const topLevelProject = await makeProject(
		t,
		workflowSource(
			"test",
			'phase("test"); const value = await agent("inspect", {...args.models.fast,label:"secret-agent",phase:"test"}); throw new Error(`top-level ${value}`);',
		),
	);
	const topLevelRunner = new FakeDynamicRunner();
	topLevelRunner.successOutput = SECRET_DIAGNOSTIC;
	const topLevelEngine = new DynamicWorkflowEngine({ projectRoot: topLevelProject, runner: topLevelRunner });
	const topLevelUi = fakeCommandContext("tui", topLevelProject);
	const topLevelState = await runDynamicWorkflowForeground({
		engine: topLevelEngine,
		ctx: topLevelUi.ctx,
		workflowId: "test",
		task: "sanitize top-level errors",
		cwd: topLevelProject,
		parent: undefined,
		projectRoot: topLevelProject,
		publishResult: captureResult(topLevelUi.log),
	});
	assert.equal(topLevelState?.status, "failed");
	assert.equal(topLevelUi.log.resultEntries.length, 0);
	assert.match(topLevelState?.error ?? "", /\[REDACTED\]/);
	const topLevelRunRoot = join(topLevelProject, "dynamic-workflow", "runs", topLevelState?.runId ?? "missing");
	const persistedTopLevel = `${await readFile(join(topLevelRunRoot, "workflow.js"), "utf8")}\n${await readFile(join(topLevelRunRoot, "state.json"), "utf8")}\n${await readFile(join(topLevelRunRoot, "events.jsonl"), "utf8")}`;
	for (const forbidden of ["quoted secret", "unquoted secret", "bearer-secret", "ghp_", "github_pat_", "AKIA1234567890ABCDEF", "sk-do-not-persist"]) {
		assert.doesNotMatch(persistedTopLevel, new RegExp(forbidden));
		assert.doesNotMatch(topLevelUi.log.notifications.at(-1)?.message ?? "", new RegExp(forbidden));
	}
});

test("persistent result entry keeps short Unicode output visible, redacts secrets, and renders the authoritative path", () => {
	const state: DynamicRunState = {
		schemaVersion: 1,
		runId: "dw-20260818120218460-fe68d4d7",
		workflow: "multi-model-review",
		workflowHash: "hash",
		status: "completed",
		task: "分析架构风险",
		cwd: "/tmp/project",
		createdAt: "2026-08-18T12:02:18.460Z",
		updatedAt: "2026-08-18T12:03:18.460Z",
		agentsStarted: 7,
		agentsCompleted: 6,
		activeAgents: 0,
		resultFile: "result.json",
		failureCauses: ["challenge-review: exitCode=1 stopReason=toolUse"],
	};
	const resultPath = "/tmp/project/dynamic-workflow/runs/dw-20260818120218460-fe68d4d7/result.json";
	const entry = createDynamicWorkflowResultEntry(state, "结论：优先修复三项。\napi_key=sk-do-not-show-123456", resultPath);
	assert.equal(entry.agentsSuccessful, 6);
	assert.equal(entry.agentsStarted, 7);
	assert.equal(entry.agentsFailed, 1);
	assert.equal(entry.previewTruncated, false);
	assert.match(entry.preview, /结论：优先修复三项/);
	assert.match(entry.preview, /\[REDACTED\]/);
	assert.doesNotMatch(entry.preview, /sk-do-not-show/);
	assert.equal(entry.resultPath, resultPath);
	assert.match(formatDynamicWorkflowResultEntry(entry), /agents=6\/7 successful/);
	const controlledPath = createDynamicWorkflowResultEntry(state, "safe", "/tmp/result\n\u001b[31m.json");
	assert.equal(controlledPath.resultPath.startsWith("/"), true);
	assert.doesNotMatch(controlledPath.resultPath, /[\u0000-\u001F\u007F]/);
	assert.doesNotMatch(controlledPath.resultPath, /\u001b/);
	assert.throws(
		() => createDynamicWorkflowResultEntry({ ...state, agentsStarted: -1 }, "bad", resultPath),
		/non-negative integer/,
	);
	assert.throws(
		() => createDynamicWorkflowResultEntry({ ...state, agentsStarted: 1, agentsCompleted: 2 }, "bad", resultPath),
		/cannot exceed/,
	);
	const typical = createDynamicWorkflowResultEntry(state, "中".repeat(6_222), resultPath);
	assert.equal(typical.preview.length, 6_222);
	assert.equal(typical.previewTruncated, false);
	const exactBoundary = createDynamicWorkflowResultEntry(state, "界".repeat(DYNAMIC_WORKFLOW_RESULT_PREVIEW_CHARS), resultPath);
	assert.equal(exactBoundary.preview.length, DYNAMIC_WORKFLOW_RESULT_PREVIEW_CHARS);
	assert.equal(exactBoundary.previewTruncated, false);
	const overBoundary = createDynamicWorkflowResultEntry(state, "界".repeat(DYNAMIC_WORKFLOW_RESULT_PREVIEW_CHARS + 1), resultPath);
	assert.equal(overBoundary.preview.length, DYNAMIC_WORKFLOW_RESULT_PREVIEW_CHARS);
	assert.equal(overBoundary.previewTruncated, true);
	const noticeLength = "\n… [preview truncated; open result.json for the complete result]".length;
	const surrogateBoundary = createDynamicWorkflowResultEntry(
		state,
		`${"界".repeat(DYNAMIC_WORKFLOW_RESULT_PREVIEW_CHARS - noticeLength - 1)}🚀${"界".repeat(100)}`,
		resultPath,
	);
	assert.equal(surrogateBoundary.previewTruncated, true);
	assert.ok(surrogateBoundary.preview.length <= DYNAMIC_WORKFLOW_RESULT_PREVIEW_CHARS);
	assert.doesNotMatch(surrogateBoundary.preview, /[\uD800-\uDFFF](?=\n…)/);

	let registeredType = "";
	let registeredRenderer: unknown;
	const fakePi = {
		registerEntryRenderer(type: string, renderer: unknown) {
			registeredType = type;
			registeredRenderer = renderer;
		},
	} as unknown as ExtensionAPI;
	registerDynamicWorkflowResultRenderer(fakePi);
	assert.equal(registeredType, DYNAMIC_WORKFLOW_RESULT_ENTRY_TYPE);
	const renderer = registeredRenderer as (
		entry: { data: DynamicWorkflowResultEntryData },
		options: { expanded: boolean },
		theme: { fg(color: string, text: string): string; bg(color: string, text: string): string },
	) => { render(width: number): string[] };
	const component = renderer(
		{ data: entry },
		{ expanded: false },
		{
			fg: (_color, text) => text,
			bg: (_color, text) => text,
		},
	);
	const rendered = component.render(120).join("\n");
	assert.match(rendered, /Dynamic Workflow result/);
	assert.match(rendered, /6\/7 Agents successful/);
	assert.match(rendered, /challenge-review/);
	assert.match(rendered, /结论：优先修复三项/);
	assert.match(rendered, /result\.json/);
});

test("result publication falls back to a bounded notification without changing a completed run", async (t) => {
	const project = await makeProject(t, workflowSource("test", 'return "fallback 中文 result";'));
	const engine = new DynamicWorkflowEngine({ projectRoot: project, runner: new FakeDynamicRunner() });
	const ui = fakeCommandContext("tui", project);
	let publishCalls = 0;
	const state = await runDynamicWorkflowForeground({
		engine,
		ctx: ui.ctx,
		workflowId: "test",
		task: "publisher failure",
		cwd: project,
		parent: undefined,
		projectRoot: project,
		publishResult: () => {
			publishCalls++;
			throw new Error("session append unavailable");
		},
	});
	assert.equal(state?.status, "completed");
	assert.equal(publishCalls, 1);
	assert.equal((await engine.status(state?.runId)).status, "completed");
	assert.match(ui.log.notifications.at(-1)?.message ?? "", /persistent result card could not be appended/);
	assert.match(ui.log.notifications.at(-1)?.message ?? "", /fallback 中文 result/);
	assert.match(ui.log.notifications.at(-1)?.message ?? "", /result\.json/);
});

test("stored result display selects the latest completed run without Agent calls and leaves result.json unchanged", async (t) => {
	const project = await makeProject(t, workflowSource("test", 'return "可恢复的最终结果";'));
	const runner = new FakeDynamicRunner();
	const engine = new DynamicWorkflowEngine({ projectRoot: project, runner });
	const completedRun = await engine.start("test", "completed", project, undefined);
	const completed = await engine.wait(completedRun.runId);
	assert.equal(completed.status, "completed");
	const resultPath = join(project, "dynamic-workflow", "runs", completed.runId, "result.json");
	const before = await readFile(resultPath, "utf8");

	await writeFile(join(project, "dynamic-workflow", "shared", "workflows", "test.js"), workflowSource("test", 'throw new Error("later failed run");'), "utf8");
	const failedRun = await engine.start("test", "failed", project, undefined);
	const failed = await engine.wait(failedRun.runId);
	assert.equal(failed.status, "failed");
	await mkdir(join(project, "dynamic-workflow", "runs", "dw-corrupt1"));
	const tasksBeforeDisplay = runner.tasks.length;
	const ui = fakeCommandContext("tui", project);
	const entry = await displayStoredDynamicWorkflowResult({
		engine,
		ctx: ui.ctx,
		projectRoot: project,
		publishResult: captureResult(ui.log),
	});
	assert.equal(entry.runId, completed.runId);
	assert.equal(entry.preview, "可恢复的最终结果");
	assert.equal(ui.log.resultEntries.length, 1);
	assert.equal(runner.tasks.length, tasksBeforeDisplay);
	assert.equal(await readFile(resultPath, "utf8"), before);
	await assert.rejects(
		() =>
			displayStoredDynamicWorkflowResult({
				engine,
				ctx: ui.ctx,
				runId: failed.runId,
				projectRoot: project,
				publishResult: captureResult(ui.log),
			}),
		/status=failed/,
	);
	await assert.rejects(
		() =>
			displayStoredDynamicWorkflowResult({
				engine,
				ctx: ui.ctx,
				runId: "dw-corrupt1",
				projectRoot: project,
				publishResult: captureResult(ui.log),
			}),
		/ENOENT/,
	);
	assert.equal(ui.log.resultEntries.length, 1);
	assert.equal(runner.tasks.length, tasksBeforeDisplay);
});

test("Esc cancels a foreground Dynamic Workflow while its command handler is awaiting", async (t) => {
	const source = workflowSource(
		"test",
		'phase("test"); return await agent("hang", {...args.models.fast,label:"hanging-agent",phase:"test"});',
	);
	const project = await makeProject(t, source);
	const runner = new FakeDynamicRunner(true);
	const engine = new DynamicWorkflowEngine({ projectRoot: project, runner });
	let releaseStart = (): void => undefined;
	const startGate = new Promise<void>((resolvePromise) => {
		releaseStart = resolvePromise;
	});
	const originalStart = engine.start.bind(engine);
	engine.start = async (...args) => {
		await startGate;
		return await originalStart(...args);
	};
	const { ctx, log } = fakeCommandContext("tui", project);
	const foreground = runDynamicWorkflowForeground({
		engine,
		ctx,
		workflowId: "test",
		task: "cancel me",
		cwd: project,
		parent: undefined,
		projectRoot: project,
		publishResult: captureResult(log),
	});
	assert.equal(log.terminalHandler?.("\x1b")?.consume, true);
	releaseStart();
	const state = await foreground;
	assert.equal(state?.status, "cancelled");
	assert.ok(state);
	assert.ok(runner.aborted <= 1);
	assert.equal(log.notifications.at(-1)?.type, "warning");
	assert.equal(log.unsubscribed, 1);
	assert.equal(log.widgets.at(-1)?.content, undefined);
	assert.equal(log.resultEntries.length, 0);
	await assert.rejects(() => engine.completedResult(state.runId), /status=cancelled/);
});

test("Pi dynamic runner forwards exact model and thinking with fixed read-only tools", async () => {
	const runner = new PiDynamicAgentRunner({
		projectRoot: resolve("."),
		piCommand: { command: process.execPath, args: [resolve("test/fixtures/pi-child-stub.mjs"), "success"] },
	});
	const result = await runner.run(
		{
			provider: "provider-exact",
			model: "model-exact",
			thinking: "high",
			label: "exact",
			phase: "test",
			prompt: "inspect",
			cwd: resolve("."),
			timeoutMs: 1_000,
		},
		new AbortController().signal,
	);
	assert.equal(result.exitCode, 0);
	const output = JSON.parse(result.output as string) as { argv: string[] };
	const modelIndex = output.argv.indexOf("--model");
	const thinkingIndex = output.argv.indexOf("--thinking");
	const toolsIndex = output.argv.indexOf("--tools");
	assert.equal(output.argv[modelIndex + 1], "provider-exact/model-exact");
	assert.equal(output.argv[thinkingIndex + 1], "high");
	assert.equal(output.argv[toolsIndex + 1], "read,grep,find,ls");
	assert.equal(output.argv.at(-1), "Task: inspect");
});

test("Pi dynamic runner renews only the idle deadline on valid stdout JSON activity", async () => {
	const runner = new PiDynamicAgentRunner({
		projectRoot: resolve("."),
		piCommand: { command: process.execPath, args: [resolve("test/fixtures/pi-child-stub.mjs"), "valid-activity-then-success"] },
	});
	const startedAt = Date.now();
	const result = await runner.run(
		{
			provider: "provider-exact",
			model: "model-exact",
			label: "activity-renewal",
			prompt: "inspect",
			cwd: resolve("."),
			idleTimeoutMs: 180,
			timeoutMs: 1_200,
		},
		new AbortController().signal,
	);
	assert.equal(result.exitCode, 0);
	assert.equal(result.stopReason, "stop");
	assert.equal(result.output, '{"activity":"kept-alive"}');
	assert.ok(Date.now() - startedAt >= 300, "the child should outlive one idle window because valid activity renews it");
	assert.doesNotMatch(result.stderr, /timed out|hard timeout/);
});

test("Pi dynamic runner preserves UTF-8 when one JSON event is split inside a multibyte character", async () => {
	const runner = new PiDynamicAgentRunner({
		projectRoot: resolve("."),
		piCommand: { command: process.execPath, args: [resolve("test/fixtures/pi-child-stub.mjs"), "split-unicode-json"] },
	});
	const result = await runner.run(
		{
			provider: "provider-exact",
			model: "model-exact",
			label: "split-unicode-json",
			prompt: "inspect",
			cwd: resolve("."),
			idleTimeoutMs: 500,
			timeoutMs: 1_000,
		},
		new AbortController().signal,
	);
	assert.equal(result.exitCode, 0);
	assert.equal(result.stopReason, "stop");
	assert.equal(result.output, "中文结果");
	assert.doesNotMatch(`${result.output}${result.stderr}`, /�|Invalid Pi JSON event/);
});

test("Pi dynamic runner idle-times out silence, invalid stdout, and stderr-only noise", async () => {
	for (const mode of ["silent", "invalid-stdout-activity-forever", "stderr-activity-forever"] as const) {
		const runner = new PiDynamicAgentRunner({
			projectRoot: resolve("."),
			piCommand: { command: process.execPath, args: [resolve("test/fixtures/pi-child-stub.mjs"), mode] },
			forceKillAfterMs: 50,
		});
		const result = await runner.run(
			{
				provider: "provider-exact",
				model: "model-exact",
				label: mode,
				prompt: "inspect",
				cwd: resolve("."),
				idleTimeoutMs: 180,
				timeoutMs: 1_200,
			},
			new AbortController().signal,
		);
		assert.equal(result.exitCode, 1, mode);
		assert.match(
			result.stderr,
			/Dynamic agent idle timed out after 180ms without valid stdout JSON activity/,
			mode,
		);
		assert.doesNotMatch(result.stderr, /absolute hard timeout/, mode);
	}
});

test("Pi dynamic runner safely rejects parseable non-object JSON without renewing idle", async () => {
	const runner = new PiDynamicAgentRunner({
		projectRoot: resolve("."),
		piCommand: { command: process.execPath, args: [resolve("test/fixtures/pi-child-stub.mjs"), "invalid-json-shape-activity-forever"] },
		forceKillAfterMs: 50,
	});
	const result = await runner.run(
		{
			provider: "provider-exact",
			model: "model-exact",
			label: "invalid-json-shape",
			prompt: "inspect",
			cwd: resolve("."),
			idleTimeoutMs: 180,
			timeoutMs: 1_200,
		},
		new AbortController().signal,
	);
	assert.equal(result.exitCode, 1);
	assert.match(result.stderr, /Dynamic agent idle timed out after 180ms without valid stdout JSON activity/);
	assert.match(result.stderr, /Invalid Pi JSON event: expected a plain object with a non-empty string type/);
	assert.doesNotMatch(result.stderr, /absolute hard timeout/);
});

test("Pi dynamic runner fails cleanly on malformed known-event fields", async () => {
	const runner = new PiDynamicAgentRunner({
		projectRoot: resolve("."),
		piCommand: { command: process.execPath, args: [resolve("test/fixtures/pi-child-stub.mjs"), "malformed-known-events"] },
	});
	const result = await runner.run(
		{
			provider: "provider-exact",
			model: "model-exact",
			label: "malformed-known-events",
			prompt: "inspect",
			cwd: resolve("."),
			idleTimeoutMs: 500,
			timeoutMs: 1_000,
		},
		new AbortController().signal,
	);
	assert.equal(result.exitCode, 1);
	assert.match(result.stderr, /Invalid Pi JSON event/);
	assert.match(result.stderr, /Missing terminal assistant message/);
});

test("Pi dynamic runner absolute hard cap is not renewed by continuous valid activity", async () => {
	const runner = new PiDynamicAgentRunner({
		projectRoot: resolve("."),
		piCommand: { command: process.execPath, args: [resolve("test/fixtures/pi-child-stub.mjs"), "valid-activity-forever"] },
		forceKillAfterMs: 50,
	});
	const result = await runner.run(
		{
			provider: "provider-exact",
			model: "model-exact",
			label: "absolute-hard-cap",
			prompt: "inspect",
			cwd: resolve("."),
			idleTimeoutMs: 180,
			timeoutMs: 320,
		},
		new AbortController().signal,
	);
	assert.equal(result.exitCode, 1);
	assert.match(result.stderr, /Dynamic agent reached the 320ms absolute hard timeout/);
	assert.doesNotMatch(result.stderr, /idle timed out/);
});

test("Pi dynamic runner keeps legacy timeout fallback and abort semantics", async () => {
	const legacyRunner = new PiDynamicAgentRunner({
		projectRoot: resolve("."),
		piCommand: { command: process.execPath, args: [resolve("test/fixtures/pi-child-stub.mjs"), "silent"] },
		forceKillAfterMs: 50,
	});
	const legacy = await legacyRunner.run(
		{
			provider: "provider-exact",
			model: "model-exact",
			label: "legacy-timeout",
			prompt: "inspect",
			cwd: resolve("."),
			timeoutMs: 220,
		},
		new AbortController().signal,
	);
	assert.equal(legacy.exitCode, 1);
	assert.match(legacy.stderr, /timed out after 220ms|220ms absolute hard timeout/);

	const abortRunner = new PiDynamicAgentRunner({
		projectRoot: resolve("."),
		piCommand: { command: process.execPath, args: [resolve("test/fixtures/pi-child-stub.mjs"), "silent"] },
		forceKillAfterMs: 50,
	});
	const controller = new AbortController();
	const abortTimer = setTimeout(() => controller.abort(new Error("test abort")), 100);
	const aborted = await abortRunner.run(
		{
			provider: "provider-exact",
			model: "model-exact",
			label: "abort",
			prompt: "inspect",
			cwd: resolve("."),
			idleTimeoutMs: 800,
			timeoutMs: 1_000,
		},
		controller.signal,
	);
	clearTimeout(abortTimer);
	assert.equal(aborted.exitCode, 1);
	assert.match(aborted.stderr, /Dynamic agent aborted/);
	assert.doesNotMatch(aborted.stderr, /idle timed out|absolute hard timeout/);
});

test("Pi dynamic runner reports retries and only short-circuits an explicit hard usage quota", async () => {
	assert.equal(isHardQuotaDiagnostic('429: {"code":"1308","message":"已达到 5 小时的使用上限"}'), true);
	assert.equal(isHardQuotaDiagnostic("429: usage limit exceeded"), true);
	assert.equal(isHardQuotaDiagnostic('503: {"code":"1308","message":"temporary routing failure"}'), false);
	assert.equal(isHardQuotaDiagnostic("429: temporary rate limit"), false);
	const task: DynamicAgentTask = {
		provider: "provider-exact",
		model: "model-exact",
		label: "retry-test",
		phase: "test",
		prompt: "inspect",
		cwd: resolve("."),
		idleTimeoutMs: 1_000,
		timeoutMs: 2_000,
	};
	const hardQuotaProgress: Array<{ hardQuota: boolean; diagnostic: string; delayMs: number }> = [];
	const hardQuotaRunner = new PiDynamicAgentRunner({
		projectRoot: resolve("."),
		piCommand: { command: process.execPath, args: [resolve("test/fixtures/pi-child-stub.mjs"), "hard-quota-retry"] },
		forceKillAfterMs: 100,
	});
	const startedAt = Date.now();
	const hardQuota = await hardQuotaRunner.run(task, new AbortController().signal, (progress) => hardQuotaProgress.push(progress));
	assert.equal(hardQuota.exitCode, 1);
	assert.ok(Date.now() - startedAt < 1_500, "hard quota should not wait for exponential retry backoff");
	assert.deepEqual(hardQuotaProgress.map(({ hardQuota, delayMs }) => ({ hardQuota, delayMs })), [{ hardQuota: true, delayMs: 2_000 }]);
	assert.match(hardQuotaProgress[0]?.diagnostic ?? "", /429/);
	assert.doesNotMatch(JSON.stringify({ hardQuotaProgress, hardQuota }), /sk-do-not-persist/);

	const transientProgress: Array<{ hardQuota: boolean; diagnostic: string }> = [];
	const transientRunner = new PiDynamicAgentRunner({
		projectRoot: resolve("."),
		piCommand: { command: process.execPath, args: [resolve("test/fixtures/pi-child-stub.mjs"), "transient-retry"] },
	});
	const transient = await transientRunner.run(task, new AbortController().signal, (progress) => transientProgress.push(progress));
	assert.equal(transient.exitCode, 0);
	assert.equal(transient.stopReason, "stop");
	assert.deepEqual(transientProgress.map(({ hardQuota }) => hardQuota), [false]);

	const nonQuota1308Progress: Array<{ hardQuota: boolean }> = [];
	const nonQuota1308Runner = new PiDynamicAgentRunner({
		projectRoot: resolve("."),
		piCommand: { command: process.execPath, args: [resolve("test/fixtures/pi-child-stub.mjs"), "code1308-nonquota-retry"] },
	});
	const nonQuota1308 = await nonQuota1308Runner.run(task, new AbortController().signal, (progress) => nonQuota1308Progress.push(progress));
	assert.equal(nonQuota1308.exitCode, 0);
	assert.equal(nonQuota1308.stopReason, "stop");
	assert.deepEqual(nonQuota1308Progress.map(({ hardQuota }) => hardQuota), [false]);
});
