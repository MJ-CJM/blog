import assert from "node:assert/strict";
import test from "node:test";
import { canTransition, isTerminalPhase, transitionState } from "../src/reducer.ts";
import type { WorkflowState } from "../src/types.ts";

const base: WorkflowState = {
	schemaVersion: 1,
	runId: "egc-test-run",
	phase: "created",
	createdAt: "2026-01-01T00:00:00.000Z",
	updatedAt: "2026-01-01T00:00:00.000Z",
	contractHash: "hash",
	runtimeHash: "runtime-hash",
	repairCount: 0,
	maxRepair: 1,
};

test("reducer permits only declared workflow transitions", () => {
	assert.equal(canTransition("created", "baseline_captured"), true);
	assert.equal(canTransition("created", "implementing"), false);
	const captured = transitionState(base, "baseline_captured", "2026-01-01T00:01:00.000Z");
	assert.equal(captured.phase, "baseline_captured");
	assert.throws(() => transitionState(captured, "completed", "2026-01-01T00:02:00.000Z"), /Invalid workflow transition/);
});

test("terminal phases cannot transition", () => {
	for (const phase of ["completed", "blocked", "rejected", "cancelled"] as const) {
		assert.equal(isTerminalPhase(phase), true);
		assert.equal(canTransition(phase, "created"), false);
	}
});
