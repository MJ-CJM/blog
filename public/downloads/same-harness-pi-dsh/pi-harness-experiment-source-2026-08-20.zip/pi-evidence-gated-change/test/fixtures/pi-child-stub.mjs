const mode = process.argv[2];

function terminal(stopReason = "stop", text = "{}") {
	process.stdout.write(`${JSON.stringify({
		type: "message_end",
		message: { role: "assistant", content: [{ type: "text", text }], stopReason },
	})}\n`);
}

switch (mode) {
	case "success":
		terminal("stop", JSON.stringify({ argv: process.argv.slice(3) }));
		break;
	case "length":
		terminal("length", "{}");
		break;
	case "invalid-json":
		process.stdout.write("not-json\n");
		terminal();
		break;
	case "missing-terminal":
		process.stdout.write(`${JSON.stringify({ type: "session" })}\n`);
		break;
	case "nonzero":
		process.exitCode = 7;
		break;
	case "hang":
		process.on("SIGTERM", () => {});
		setInterval(() => {}, 1_000);
		break;
	case "silent":
		setInterval(() => {}, 1_000);
		break;
	case "valid-activity-then-success": {
		let events = 0;
		const activity = setInterval(() => {
			events++;
			process.stdout.write(`${JSON.stringify({ type: "message_update", event: { type: "text_delta", delta: "." } })}\n`);
			if (events === 6) {
				clearInterval(activity);
				terminal("stop", '{"activity":"kept-alive"}');
			}
		}, 60);
		break;
	}
	case "split-unicode-json": {
		const event = Buffer.from(`${JSON.stringify({
			type: "message_end",
			message: { role: "assistant", content: [{ type: "text", text: "中文结果" }], stopReason: "stop" },
		})}\n`, "utf8");
		const characterStart = event.indexOf(Buffer.from("中", "utf8"));
		if (characterStart < 0) throw new Error("Unicode split fixture could not find target character");
		process.stdout.write(event.subarray(0, characterStart + 1));
		setTimeout(() => process.stdout.write(event.subarray(characterStart + 1)), 20);
		break;
	}
	case "valid-activity-forever":
		setInterval(() => {
			process.stdout.write(`${JSON.stringify({ type: "message_update", event: { type: "text_delta", delta: "." } })}\n`);
		}, 50);
		break;
	case "invalid-stdout-activity-forever":
		setInterval(() => process.stdout.write("not-json-activity\n"), 50);
		break;
	case "invalid-json-shape-activity-forever": {
		const invalidShapes = [null, [], "scalar", 1];
		let shape = 0;
		setInterval(() => {
			process.stdout.write(`${JSON.stringify(invalidShapes[shape++ % invalidShapes.length])}\n`);
		}, 50);
		break;
	}
	case "malformed-known-events":
		process.stdout.write(`${JSON.stringify({
			type: "auto_retry_start",
			attempt: 1,
			maxAttempts: 3,
			delayMs: 20,
			errorMessage: 42,
		})}\n`);
		process.stdout.write(`${JSON.stringify({
			type: "message_end",
			message: { role: "assistant", content: {}, stopReason: "stop" },
		})}\n`);
		break;
	case "stderr-activity-forever":
		setInterval(() => process.stderr.write("diagnostic activity\n"), 50);
		break;
	case "cooperative-timeout":
		process.on("SIGTERM", () => {
			terminal("stop", "{}");
			process.exit(0);
		});
		setInterval(() => {}, 1_000);
		break;
	case "hard-quota-retry":
		process.stdout.write(`${JSON.stringify({
			type: "auto_retry_start",
			attempt: 1,
			maxAttempts: 3,
			delayMs: 2_000,
			errorMessage: '429: {"code":"1308","message":"已达到 5 小时的使用上限","token":"sk-do-not-persist-123456"}',
		})}\n`);
		setInterval(() => {}, 1_000);
		break;
	case "transient-retry":
		process.stdout.write(`${JSON.stringify({
			type: "auto_retry_start",
			attempt: 1,
			maxAttempts: 3,
			delayMs: 20,
			errorMessage: "429: temporary rate limit",
		})}\n`);
		setTimeout(() => terminal("stop", '{"recovered":true}'), 20);
		break;
	case "code1308-nonquota-retry":
		process.stdout.write(`${JSON.stringify({
			type: "auto_retry_start",
			attempt: 1,
			maxAttempts: 3,
			delayMs: 20,
			errorMessage: '503: {"code":"1308","message":"temporary routing failure"}',
		})}\n`);
		setTimeout(() => terminal("stop", '{"recovered":true}'), 20);
		break;
	default:
		throw new Error(`Unknown stub mode: ${mode}`);
}
