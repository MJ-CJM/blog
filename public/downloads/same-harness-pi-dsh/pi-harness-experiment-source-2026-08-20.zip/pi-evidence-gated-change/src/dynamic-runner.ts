import { spawn } from "node:child_process";
import { existsSync, readFileSync } from "node:fs";
import { join } from "node:path";
import { isHardQuotaDiagnostic, sanitizeDynamicDiagnostic } from "./dynamic-diagnostics.ts";
import type { DynamicAgentProgressListener, DynamicAgentResult, DynamicAgentRunner, DynamicAgentTask } from "./dynamic-types.ts";

export interface PiDynamicRunnerConfiguration {
	projectRoot: string;
	piCommand?: { command: string; args?: string[] };
	forceKillAfterMs?: number;
}

interface PiJsonMessage {
	role?: string;
	content?: Array<{ type?: string; text?: string }>;
	stopReason?: string;
	errorMessage?: string;
}

interface PiJsonEvent {
	type?: string;
	message?: PiJsonMessage;
	attempt?: number;
	maxAttempts?: number;
	delayMs?: number;
	errorMessage?: string;
}

function isPlainRecord(value: unknown): value is Record<string, unknown> {
	return value !== null && typeof value === "object" && !Array.isArray(value) && Object.getPrototypeOf(value) === Object.prototype;
}

function invocation(configuration: PiDynamicRunnerConfiguration): { command: string; args: string[] } {
	if (configuration.piCommand) return { command: configuration.piCommand.command, args: configuration.piCommand.args ?? [] };
	const packagePath = join(configuration.projectRoot, "node_modules", "@earendil-works", "pi-coding-agent", "package.json");
	const packageJson = JSON.parse(readFileSync(packagePath, "utf8")) as { version?: string };
	if (packageJson.version !== "0.84.2") throw new Error(`Expected local Pi 0.84.2, found ${packageJson.version ?? "unknown"}`);
	const binary = join(configuration.projectRoot, "node_modules", ".bin", "pi");
	if (!existsSync(binary)) throw new Error(`Pinned local Pi runner is missing: ${binary}`);
	return { command: binary, args: [] };
}

export class PiDynamicAgentRunner implements DynamicAgentRunner {
	private readonly configuration: PiDynamicRunnerConfiguration;

	constructor(configuration: PiDynamicRunnerConfiguration) {
		this.configuration = configuration;
	}

	async run(task: DynamicAgentTask, signal: AbortSignal, onProgress?: DynamicAgentProgressListener): Promise<DynamicAgentResult> {
		const idleTimeoutMs = task.idleTimeoutMs ?? task.timeoutMs;
		if (!Number.isInteger(idleTimeoutMs) || idleTimeoutMs <= 0) throw new Error("Dynamic agent idle timeout must be a positive integer");
		if (!Number.isInteger(task.timeoutMs) || task.timeoutMs <= 0) throw new Error("Dynamic agent hard timeout must be a positive integer");
		if (idleTimeoutMs > task.timeoutMs) throw new Error("Dynamic agent idle timeout cannot exceed hard timeout");
		const childGuard = join(this.configuration.projectRoot, "src", "child-guard.ts");
		const args = [
			"--mode",
			"json",
			"-p",
			"--no-session",
			"--no-extensions",
			"-e",
			childGuard,
			"--no-skills",
			"--no-prompt-templates",
			"--no-context-files",
			"--no-approve",
			"--append-system-prompt",
			"You are a read-only Dynamic Workflow review agent. Do not edit files or run shell commands.",
			"--tools",
			"read,grep,find,ls",
			"--model",
			`${task.provider}/${task.model}`,
		];
		if (task.thinking) args.push("--thinking", task.thinking);
		args.push(`Task: ${task.prompt}`);
		const command = invocation(this.configuration);

		return await new Promise<DynamicAgentResult>((resolvePromise) => {
			const child = spawn(command.command, [...command.args, ...args], {
				cwd: task.cwd,
				shell: false,
				stdio: ["ignore", "pipe", "pipe"],
				env: process.env,
			});
			child.stdout.setEncoding("utf8");
			child.stderr.setEncoding("utf8");
			let stdoutBuffer = "";
			let stderr = "";
			let output = "";
			let stopReason: string | undefined;
			let terminal = false;
			let invalidJson = false;
			let settled = false;
			let terminationReason: "aborted" | "idle-timeout" | "hard-timeout" | "hard-quota" | undefined;
			let forceKill: NodeJS.Timeout | undefined;
			let idleTimeout: NodeJS.Timeout;

			const resetIdleTimeout = (): void => {
				if (settled || terminationReason) return;
				clearTimeout(idleTimeout);
				idleTimeout = setTimeout(() => terminate("idle-timeout"), idleTimeoutMs);
				idleTimeout.unref();
			};
			const rejectEventShape = (detail: string): void => {
				invalidJson = true;
				stderr += `Invalid Pi JSON event shape: ${detail}\n`;
			};

			const processLine = (line: string): void => {
				if (!line.trim()) return;
				let parsed: unknown;
				try {
					parsed = JSON.parse(line) as unknown;
				} catch {
					invalidJson = true;
					stderr += `Invalid Pi JSON event: ${line.slice(0, 200)}\n`;
					return;
				}
				const plainObject = isPlainRecord(parsed);
				const eventType = plainObject ? (parsed as Record<string, unknown>).type : undefined;
				if (!plainObject || typeof eventType !== "string" || eventType.trim() === "") {
					invalidJson = true;
					stderr += "Invalid Pi JSON event: expected a plain object with a non-empty string type\n";
					return;
				}
				const event = parsed as PiJsonEvent;
				if (event.type === "auto_retry_start") {
					if (typeof event.errorMessage !== "string") {
						rejectEventShape("auto_retry_start.errorMessage must be a string");
						return;
					}
					resetIdleTimeout();
					const attempt = Number.isInteger(event.attempt) && (event.attempt ?? 0) > 0 ? event.attempt as number : 1;
					const maxAttempts = Number.isInteger(event.maxAttempts) && (event.maxAttempts ?? 0) > 0 ? event.maxAttempts as number : attempt;
					const delayMs = Number.isFinite(event.delayMs) && (event.delayMs ?? -1) >= 0 ? event.delayMs as number : 0;
					const diagnostic = sanitizeDynamicDiagnostic(event.errorMessage);
					const hardQuota = isHardQuotaDiagnostic(diagnostic);
					stderr += `Retry ${attempt}/${maxAttempts} after ${delayMs}ms: ${diagnostic}\n`;
					try {
						onProgress?.({ type: "retry", attempt, maxAttempts, delayMs, diagnostic, hardQuota });
					} catch {
						// Progress reporting is observational and must not break child settlement.
					}
					if (hardQuota) terminate("hard-quota");
					return;
				}
				if (event.type === "message_end") {
					const message = event.message as unknown;
					if (!isPlainRecord(message)) {
						rejectEventShape("message_end.message must be a plain object");
						return;
					}
					if (typeof message.role !== "string") {
						rejectEventShape("message_end.message.role must be a string");
						return;
					}
					if (message.stopReason !== undefined && typeof message.stopReason !== "string") {
						rejectEventShape("message_end.message.stopReason must be a string");
						return;
					}
					if (message.errorMessage !== undefined && typeof message.errorMessage !== "string") {
						rejectEventShape("message_end.message.errorMessage must be a string");
						return;
					}
					if (message.role !== "assistant") {
						resetIdleTimeout();
						return;
					}
					if (!Array.isArray(message.content)) {
						rejectEventShape("message_end assistant content must be an array");
						return;
					}
					let textOutput = "";
					let foundText = false;
					for (let index = 0; index < message.content.length; index++) {
						const part = message.content[index];
						if (!isPlainRecord(part)) {
							rejectEventShape(`message_end assistant content[${index}] must be a plain object`);
							return;
						}
						if (typeof part.type !== "string" || part.type.trim() === "") {
							rejectEventShape(`message_end assistant content[${index}].type must be a non-empty string`);
							return;
						}
						if (part.type === "text" && typeof part.text !== "string") {
							rejectEventShape(`message_end assistant content[${index}].text must be a string`);
							return;
						}
						if (!foundText && part.type === "text") {
							textOutput = part.text as string;
							foundText = true;
						}
					}
					resetIdleTimeout();
					terminal = true;
					output = textOutput;
					stopReason = message.stopReason as string | undefined;
					if (typeof message.errorMessage === "string") {
						stderr += `${sanitizeDynamicDiagnostic(message.errorMessage)}\n`;
					}
					return;
				}
				resetIdleTimeout();
			};

			child.stdout.on("data", (chunk: string) => {
				stdoutBuffer += chunk;
				const lines = stdoutBuffer.split("\n");
				stdoutBuffer = lines.pop() ?? "";
				for (const line of lines) processLine(line);
			});
			child.stderr.on("data", (chunk: string) => {
				stderr += chunk;
			});

			const terminate = (reason: "aborted" | "idle-timeout" | "hard-timeout" | "hard-quota"): void => {
				if (terminationReason) return;
				terminationReason = reason;
				const terminationDiagnostic =
					reason === "aborted"
						? "Dynamic agent aborted"
						: reason === "idle-timeout"
							? `Dynamic agent idle timed out after ${idleTimeoutMs}ms without valid stdout JSON activity`
							: reason === "hard-timeout"
								? `Dynamic agent reached the ${task.timeoutMs}ms absolute hard timeout`
								: "Dynamic agent stopped early because the provider reported a hard usage quota";
				// Put the terminal cause first so bounded failure summaries cannot hide it behind retry diagnostics.
				stderr = `${terminationDiagnostic}\n${stderr}`;
				child.kill("SIGTERM");
				forceKill = setTimeout(() => child.kill("SIGKILL"), this.configuration.forceKillAfterMs ?? 5_000);
				forceKill.unref();
			};
			idleTimeout = setTimeout(() => terminate("idle-timeout"), idleTimeoutMs);
			idleTimeout.unref();
			const hardTimeout = setTimeout(() => terminate("hard-timeout"), task.timeoutMs);
			hardTimeout.unref();
			const abort = (): void => terminate("aborted");
			if (signal.aborted) abort();
			else signal.addEventListener("abort", abort, { once: true });

			const finish = (exitCode: number): void => {
				if (settled) return;
				settled = true;
				clearTimeout(idleTimeout);
				clearTimeout(hardTimeout);
				if (forceKill) clearTimeout(forceKill);
				signal.removeEventListener("abort", abort);
				if (stdoutBuffer.trim()) processLine(stdoutBuffer);
				if (!terminal) stderr += "Missing terminal assistant message\n";
				const effectiveExitCode =
					exitCode !== 0 || terminationReason || invalidJson || !terminal || stopReason !== "stop" ? exitCode || 1 : 0;
				const result: DynamicAgentResult = { exitCode: effectiveExitCode, output, stderr };
				if (stopReason !== undefined) result.stopReason = stopReason;
				resolvePromise(result);
			};

			child.on("error", (error) => {
				stderr += `${error.message}\n`;
				finish(1);
			});
			child.on("close", (code, childSignal) => {
				if (childSignal) stderr += `Dynamic agent terminated by ${childSignal}\n`;
				finish(code ?? 1);
			});
		});
	}
}
