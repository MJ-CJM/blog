import { randomUUID } from "node:crypto";
import { writeFile } from "node:fs/promises";
import { join, resolve } from "node:path";
import {
	appendEvent,
	changedFiles,
	createIsolatedFixture,
	createPatch,
	getRunPaths,
	hashContract,
	hashRuntime,
	hashTree,
	initializeRunDirectory,
	isDirectory,
	readJson,
	readLastEventSequence,
	readWorkflowEvents,
	saveState,
	writeJsonAtomic,
} from "./artifacts.ts";
import { canonicalJson, extractJson, parseDiscovery, parsePlan, parseReview, sha256 } from "./json.ts";
import { isTerminalPhase, transitionState } from "./reducer.ts";
import { SchemaValidator } from "./schema-validator.ts";
import type {
	AgentRole,
	AgentRunResult,
	ApprovalArtifact,
	DiscoveryArtifact,
	PlanArtifact,
	ReviewArtifact,
	RunPaths,
	VerificationArtifact,
	WorkflowEvent,
	WorkflowOptions,
	WorkflowState,
} from "./types.ts";
import { verifyWorktree } from "./verifier.ts";

const REQUIRED_PLAN_FILES = ["README.md", "src/TodoService.ts", "test/TodoService.test.ts"] as const;

class WorkflowCancelledError extends Error {
	constructor() {
		super("Workflow cancelled");
		this.name = "WorkflowCancelledError";
	}
}

function errorMessage(error: unknown): string {
	return error instanceof Error ? error.message : String(error);
}

function safeClone<T>(value: T): T {
	return structuredClone(value);
}

export class EvidenceGatedWorkflow {
	private readonly projectRoot: string;
	private readonly runner: WorkflowOptions["runner"];
	private readonly schema: SchemaValidator;
	private readonly onSnapshot: WorkflowOptions["onSnapshot"];
	private readonly now: () => Date;
	private readonly idFactory: () => string;
	private readonly controllers = new Map<string, AbortController>();
	private readonly activeSettlements = new Map<string, Promise<void>>();
	private readonly sequences = new Map<string, number>();
	private readonly eventQueues = new Map<string, Promise<void>>();

	constructor(options: WorkflowOptions) {
		this.projectRoot = resolve(options.projectRoot);
		this.runner = options.runner;
		this.schema = new SchemaValidator(this.projectRoot);
		this.onSnapshot = options.onSnapshot;
		this.now = options.now ?? (() => new Date());
		this.idFactory = options.idFactory ?? randomUUID;
	}

	async start(): Promise<WorkflowState> {
		const timestamp = this.now().toISOString().replace(/[-:.TZ]/g, "").slice(0, 14).toLowerCase();
		const runId = `egc-${timestamp}-${this.idFactory().replaceAll("-", "").slice(0, 8).toLowerCase()}`;
		const paths = getRunPaths(this.projectRoot, runId);
		await initializeRunDirectory(paths);
		const now = this.now().toISOString();
		let state: WorkflowState = {
			schemaVersion: 1,
			runId,
			phase: "created",
			createdAt: now,
			updatedAt: now,
			contractHash: await hashContract(this.projectRoot),
			runtimeHash: await hashRuntime(this.projectRoot),
			repairCount: 0,
			maxRepair: 1,
		};
		await this.persist(paths, state);
		await this.emit(state, { kind: "state", name: "run-created", status: "ok" });

		return await this.withController(runId, async (signal) => {
			try {
				state = await this.captureBaseline(state, paths, signal);
				state = await this.discoverAndPlan(state, paths, signal);
				return state;
			} catch (error) {
				return await this.failRun(paths, error);
			}
		});
	}

	async approve(runId: string, suppliedApprovalHash: string): Promise<WorkflowState> {
		const paths = getRunPaths(this.projectRoot, runId);
		let state = await this.reconcileEventLog(paths, await this.load(paths));
		state = await this.recoverInterruptedDecision(paths, state);
		if (state.phase !== "awaiting_approval") throw new Error(`Run ${runId} is not awaiting approval`);
		if (!state.approvalHash || suppliedApprovalHash !== state.approvalHash) {
			throw new Error(`Approval hash mismatch for ${runId}; expected ${state.approvalHash ?? "none"}`);
		}
		if ((await hashContract(this.projectRoot)) !== state.contractHash) {
			throw new Error("Contract, Skill, or role prompts changed after planning; start a new run");
		}
		if ((await hashRuntime(this.projectRoot)) !== state.runtimeHash) {
			throw new Error("Workflow adapter or verifier changed after planning; start a new run");
		}
		await this.assertApprovalIntegrity(paths, state);
		if (!state.planHash || !state.baselineHash || !state.approvalHash) throw new Error("Incomplete approval binding");
		const approval: ApprovalArtifact = {
			runId,
			planHash: state.planHash,
			baselineHash: state.baselineHash,
			contractHash: state.contractHash,
			runtimeHash: state.runtimeHash,
			approvalHash: state.approvalHash,
			decision: "approved",
			decidedAt: this.now().toISOString(),
		};
		this.schema.validate<ApprovalArtifact>("approval", approval);
		state = await this.writeDecisionReceipt(paths, state, approval, "record-approval");
		state = await this.transition(paths, state, "implementing", "approval-accepted");

		return await this.withController(runId, async (signal) => {
			try {
				return await this.implementReviewVerify(state, paths, signal, false);
			} catch (error) {
				return await this.failRun(paths, error);
			}
		});
	}

	async reject(runId: string, suppliedApprovalHash: string, reason: string): Promise<WorkflowState> {
		const paths = getRunPaths(this.projectRoot, runId);
		let state = await this.reconcileEventLog(paths, await this.load(paths));
		state = await this.recoverInterruptedDecision(paths, state);
		if (state.phase !== "awaiting_approval") throw new Error(`Run ${runId} is not awaiting approval`);
		if (!state.planHash || !state.baselineHash || !state.approvalHash || suppliedApprovalHash !== state.approvalHash) {
			throw new Error(`Approval hash mismatch for ${runId}`);
		}
		const approval: ApprovalArtifact = {
			runId,
			planHash: state.planHash,
			baselineHash: state.baselineHash,
			contractHash: state.contractHash,
			runtimeHash: state.runtimeHash,
			approvalHash: state.approvalHash,
			decision: "rejected",
			decidedAt: this.now().toISOString(),
		};
		if (reason.trim()) approval.reason = reason.trim();
		this.schema.validate<ApprovalArtifact>("approval", approval);
		state = await this.writeDecisionReceipt(paths, state, approval, "record-rejection");
		state = { ...state, terminalReason: reason.trim() || "Rejected by user" };
		state = await this.transition(paths, state, "rejected", "approval-rejected");
		await this.writeReport(paths, state);
		return state;
	}

	async cancel(runId: string): Promise<WorkflowState> {
		const paths = getRunPaths(this.projectRoot, runId);
		const controller = this.controllers.get(runId);
		if (controller) {
			controller.abort();
			await this.activeSettlements.get(runId);
			return await this.reconcileEventLog(paths, await this.load(paths));
		}
		let state = await this.reconcileEventLog(paths, await this.load(paths));
		if (isTerminalPhase(state.phase)) return state;
		if (state.pendingOperation) state = await this.settle(paths, state, "cancelled", { recovered: true });
		state = { ...state, terminalReason: "Cancelled by user" };
		state = await this.transition(paths, state, "cancelled", "cancelled");
		await this.writeReport(paths, state);
		return state;
	}

	async resume(runId: string): Promise<WorkflowState> {
		const paths = getRunPaths(this.projectRoot, runId);
		let state = await this.reconcileEventLog(paths, await this.load(paths));
		if (isTerminalPhase(state.phase) || state.phase === "awaiting_approval") return state;
		if ((await hashContract(this.projectRoot)) !== state.contractHash) {
			state = { ...state, lastError: "Contract hash drift detected during resume" };
			return await this.failRun(paths, new Error(state.lastError));
		}
		if ((await hashRuntime(this.projectRoot)) !== state.runtimeHash) {
			return await this.failRun(paths, new Error("Runtime adapter hash drift detected during resume"));
		}
		if (state.baselineHash && (await hashTree(paths.baselineDir)) !== state.baselineHash) {
			return await this.failRun(paths, new Error("Baseline hash drift detected during resume"));
		}
		if (state.planHash) await this.assertPlanIntegrity(paths, state);
		if (state.phase === "implementing" || state.phase === "reviewing_verifying") {
			await this.assertApprovalArtifact(paths, state);
		}
		if (state.pendingOperation) {
			state = await this.settle(paths, state, "error", { recovered: true, reason: "unsettled-intent" });
		}

		return await this.withController(runId, async (signal) => {
			try {
				if (state.phase === "created") state = await this.captureBaseline(state, paths, signal);
				if (state.phase === "baseline_captured" || state.phase === "discovering" || state.phase === "planning") {
					return await this.resumePreApproval(state, paths, signal);
				}
				if (state.phase === "implementing") {
					const files = await changedFiles(paths.baselineDir, paths.worktreeDir);
					if (files.length > 0) {
						state = await this.transition(paths, state, "reviewing_verifying", "recovered-implementation-for-review");
						return await this.reviewVerify(state, paths, signal);
					}
					return await this.implementReviewVerify(state, paths, signal, state.repairCount > 0);
				}
				if (state.phase === "reviewing_verifying") return await this.reviewVerify(state, paths, signal);
				throw new Error(`Cannot resume phase ${state.phase}`);
			} catch (error) {
				return await this.failRun(paths, error);
			}
		});
	}

	async status(runId: string): Promise<WorkflowState> {
		const paths = getRunPaths(this.projectRoot, runId);
		return await this.reconcileEventLog(paths, await this.load(paths));
	}

	async abortAll(): Promise<void> {
		for (const controller of this.controllers.values()) controller.abort();
		await Promise.allSettled([...this.activeSettlements.values()]);
	}

	private async captureBaseline(state: WorkflowState, paths: RunPaths, signal: AbortSignal): Promise<WorkflowState> {
		state = await this.begin(paths, state, "capture-baseline");
		this.throwIfAborted(signal);
		await createIsolatedFixture(this.projectRoot, paths);
		const baselineHash = await hashTree(paths.baselineDir);
		await writeJsonAtomic(join(paths.runDir, "baseline.json"), {
			runId: state.runId,
			fixture: "todo-service",
			baselineHash,
			contractHash: state.contractHash,
			runtimeHash: state.runtimeHash,
			capturedAt: this.now().toISOString(),
		});
		state = { ...state, baselineHash };
		state = await this.settle(paths, state, "ok", { baselineHash });
		return await this.transition(paths, state, "baseline_captured", "baseline-captured");
	}

	private async resumePreApproval(state: WorkflowState, paths: RunPaths, signal: AbortSignal): Promise<WorkflowState> {
		if (!(await isDirectory(paths.baselineDir)) || !(await isDirectory(paths.worktreeDir))) {
			throw new Error("Incomplete baseline capture cannot be resumed safely; start a new run");
		}
		if (!state.baselineHash || (await hashTree(paths.baselineDir)) !== state.baselineHash) {
			throw new Error("Baseline drift detected during resume");
		}
		if (state.phase !== "baseline_captured") {
			state = { ...state, phase: "baseline_captured", updatedAt: this.now().toISOString() };
			await this.persist(paths, state);
			await this.emit(state, { kind: "state", name: "resume-from-last-settled-phase", status: "ok" });
		}
		return await this.discoverAndPlan(state, paths, signal);
	}

	private async discoverAndPlan(state: WorkflowState, paths: RunPaths, signal: AbortSignal): Promise<WorkflowState> {
		state = await this.transition(paths, state, "discovering", "discovery-started");
		state = await this.begin(paths, state, "parallel-discovery");
		const stageController = new AbortController();
		const abortStage = () => stageController.abort();
		if (signal.aborted) abortStage();
		else signal.addEventListener("abort", abortStage, { once: true });
		const validateDiscovery = (result: AgentRunResult): DiscoveryArtifact => {
			this.schema.validate<DiscoveryArtifact>("discovery", extractJson(result.output));
			return parseDiscovery(result.output);
		};
		const codePromise = this.runAgent(
				state,
				paths,
				"code-scout",
				paths.baselineDir,
				["read", "grep", "find", "ls"],
				`Inspect the TodoService baseline. Identify implementation files and risks for adding requestId idempotency. Output exactly one JSON object matching this inline schema: ${this.schema.inline("discovery")}`,
				stageController.signal,
			).then(validateDiscovery).catch((error: unknown) => {
				stageController.abort();
				throw error;
			});
		const testPromise = this.runAgent(
				state,
				paths,
				"test-scout",
				paths.baselineDir,
				["read", "grep", "find", "ls"],
				`Inspect the TodoService tests and documentation. Identify coverage needed for requestId idempotency. Output exactly one JSON object matching this inline schema: ${this.schema.inline("discovery")}`,
				stageController.signal,
			).then(validateDiscovery).catch((error: unknown) => {
				stageController.abort();
				throw error;
			});
		const discoveryResults = await Promise.allSettled([codePromise, testPromise]);
		signal.removeEventListener("abort", abortStage);
		const discoveryFailure = discoveryResults.find((result) => result.status === "rejected");
		if (discoveryFailure?.status === "rejected") throw discoveryFailure.reason;
		const codeDiscovery = discoveryResults[0].status === "fulfilled" ? discoveryResults[0].value : undefined;
		const testDiscovery = discoveryResults[1].status === "fulfilled" ? discoveryResults[1].value : undefined;
		if (!codeDiscovery || !testDiscovery) throw new Error("Parallel discovery did not produce both results");
		await Promise.all([
			writeJsonAtomic(join(paths.runDir, "discovery-code.json"), codeDiscovery),
			writeJsonAtomic(join(paths.runDir, "discovery-tests.json"), testDiscovery),
		]);
		state = await this.settle(paths, state, "ok", { agents: ["code-scout", "test-scout"] });

		state = await this.transition(paths, state, "planning", "planning-started");
		state = await this.begin(paths, state, "create-plan");
		const plannerResult = await this.runAgent(
			state,
			paths,
			"planner",
			paths.baselineDir,
			["read"],
			[
				"Create an implementation plan for TodoService.createTask requestId idempotency.",
				"The plan must change exactly README.md, src/TodoService.ts, and test/TodoService.test.ts.",
				"A repeated non-empty requestId must return a defensive copy of the original task even when title or completed differs, must not add a task, and must not consume an ID.",
				"A different requestId must create a new task even when the title matches. Empty and whitespace-only requestId values must throw. The public TypeScript input type must require requestId.",
				`Output exactly one JSON object matching this inline schema: ${this.schema.inline("plan")}`,
				`Code discovery: ${canonicalJson(codeDiscovery)}`,
				`Test discovery: ${canonicalJson(testDiscovery)}`,
			].join("\n\n"),
			signal,
		);
		this.schema.validate<PlanArtifact>("plan", extractJson(plannerResult.output));
		const plan = parsePlan(plannerResult.output);
		this.validatePlanFiles(plan);
		const planHash = sha256(canonicalJson(plan));
		if (!state.baselineHash) throw new Error("Missing baseline hash while binding approval");
		const approvalHash = this.computeApprovalHash({ ...state, planHash });
		await writeJsonAtomic(join(paths.runDir, "plan.json"), { ...plan, planHash });
		state = { ...state, planHash, approvalHash };
		state = await this.settle(paths, state, "ok", { planHash, approvalHash });
		return await this.transition(paths, state, "awaiting_approval", "plan-awaiting-approval");
	}

	private async implementReviewVerify(
		state: WorkflowState,
		paths: RunPaths,
		signal: AbortSignal,
		isRepair: boolean,
	): Promise<WorkflowState> {
		state = await this.begin(paths, state, isRepair ? "repair-change" : "implement-change");
		const plan = await this.loadPlan(paths);
		let failureContext = "";
		if (isRepair) {
			const verification = await readJson<VerificationArtifact>(join(paths.runDir, "verification.json"));
			const review = await readJson<ReviewArtifact>(join(paths.runDir, "review.json"));
			failureContext = `Previous deterministic verification: ${canonicalJson(verification)}\nPrevious review: ${canonicalJson(review)}`;
		}
		const result = await this.runAgent(
			state,
			paths,
			isRepair ? "repair" : "implementer",
			paths.worktreeDir,
			["read", "grep", "find", "ls", "edit", "write"],
			[
				isRepair ? "Repair the existing implementation." : "Implement the approved plan.",
				"Only modify README.md, src/TodoService.ts, and test/TodoService.test.ts inside the current isolated worktree.",
				"Enforce the fixed contract: same requestId returns a defensive copy of the first task without consuming an ID even when later fields differ; different requestId creates a task even for the same title; requestId is required and cannot be empty or whitespace-only.",
				"Do not execute shell commands. Do not claim tests passed; the parent verifier runs them.",
				`Approved plan: ${canonicalJson(plan)}`,
				failureContext,
				`After editing, output exactly one JSON object matching this inline schema: ${this.schema.inline("implementation")}`,
			].filter(Boolean).join("\n\n"),
			signal,
		);
		this.validateImplementationReceipt(result.output);
		const files = await changedFiles(paths.baselineDir, paths.worktreeDir);
		if (files.length === 0) throw new Error("Implementer produced no file changes");
		await writeJsonAtomic(join(paths.runDir, isRepair ? "repair.json" : "implementation.json"), extractJson(result.output));
		await this.writePatch(paths);
		state = await this.settle(paths, state, "ok", { changedFiles: files, repair: isRepair });
		state = await this.transition(paths, state, "reviewing_verifying", "review-and-verification-started");
		return await this.reviewVerify(state, paths, signal);
	}

	private async reviewVerify(state: WorkflowState, paths: RunPaths, signal: AbortSignal): Promise<WorkflowState> {
		state = await this.begin(paths, state, "parallel-review-verification");
		const plan = await this.loadPlan(paths);
		const patch = await this.writePatch(paths);
		if (!state.baselineHash) throw new Error("Missing baseline hash");

		const stageController = new AbortController();
		const abortStage = () => stageController.abort();
		if (signal.aborted) abortStage();
		else signal.addEventListener("abort", abortStage, { once: true });
		const reviewPromise = this.runAgent(
			state,
			paths,
			"reviewer",
			paths.worktreeDir,
			["read", "grep", "find", "ls"],
			[
				"Review the isolated TodoService change against the approved plan and idempotency contract.",
				"Check same-request conflict behavior, different-request same-title behavior, defensive copies, ID sequencing, empty/whitespace rejection, and a required requestId input type.",
				"Do not claim tests passed. Review semantics, tests, and documentation only.",
				`Output exactly one JSON object matching this inline schema: ${this.schema.inline("review")}`,
				`Approved plan: ${canonicalJson(plan)}`,
				`Patch:\n${patch}`,
			].join("\n\n"),
			stageController.signal,
		).then((result) => {
			this.schema.validate<ReviewArtifact>("review", extractJson(result.output));
			return parseReview(result.output);
		}).catch((error: unknown) => {
			stageController.abort();
			throw error;
		});
		const verificationPromise = verifyWorktree({
			projectRoot: this.projectRoot,
			baselineDir: paths.baselineDir,
			worktreeDir: paths.worktreeDir,
			baselineHash: state.baselineHash,
			allowedFiles: plan.files,
			signal: stageController.signal,
		}).catch((error: unknown) => {
			stageController.abort();
			throw error;
		});
		const parallelResults = await Promise.allSettled([reviewPromise, verificationPromise]);
		signal.removeEventListener("abort", abortStage);
		const parallelFailure = parallelResults.find((result) => result.status === "rejected");
		if (parallelFailure?.status === "rejected") throw parallelFailure.reason;
		const review = parallelResults[0].status === "fulfilled" ? parallelResults[0].value : undefined;
		const verification = parallelResults[1].status === "fulfilled" ? parallelResults[1].value : undefined;
		if (!review || !verification) throw new Error("Review and verification did not both settle");
		this.schema.validate<VerificationArtifact>("verification", verification);
		await Promise.all([
			writeJsonAtomic(join(paths.runDir, "review.json"), review),
			writeJsonAtomic(join(paths.runDir, "verification.json"), verification),
		]);
		const gatePassed = review.verdict === "pass" && verification.passed;
		await this.emit(state, {
			kind: "gate",
			name: "deterministic-gate",
			status: gatePassed ? "ok" : "error",
			details: {
				reviewVerdict: review.verdict,
				verificationPassed: verification.passed,
				commandExitCodes: verification.commands.map((command) => command.exitCode),
			},
		});
		state = await this.settle(paths, state, gatePassed ? "ok" : "error", { gatePassed });

		if (gatePassed) {
			state = await this.transition(paths, state, "completed", "workflow-completed");
			await this.writeReport(paths, state);
			return state;
		}
		if (state.repairCount < state.maxRepair) {
			state = { ...state, repairCount: state.repairCount + 1 };
			state = await this.transition(paths, state, "implementing", "single-repair-authorized");
			return await this.implementReviewVerify(state, paths, signal, true);
		}
		state = {
			...state,
			lastError: "Deterministic gate failed after the single permitted repair",
			terminalReason: "verification-or-review-failed",
		};
		state = await this.transition(paths, state, "blocked", "workflow-blocked");
		await this.writeReport(paths, state);
		return state;
	}

	private async runAgent(
		state: WorkflowState,
		paths: RunPaths,
		role: AgentRole,
		cwd: string,
		tools: string[],
		prompt: string,
		signal: AbortSignal,
	): Promise<AgentRunResult> {
		this.throwIfAborted(signal);
		await this.emit(state, { kind: "agent", name: `${role}-started`, details: { role } });
		const result = await this.runner.run({ role, prompt, cwd, tools, timeoutMs: 120_000 }, signal);
		const aborted = signal.aborted;
		const failed = aborted || result.exitCode !== 0 || result.stopReason !== "stop";
		await this.emit(state, {
			kind: "agent",
			name: `${role}-settled`,
			status: aborted ? "cancelled" : failed ? "error" : "ok",
			details: { role, exitCode: result.exitCode, stopReason: result.stopReason ?? null },
		});
		if (aborted) throw new WorkflowCancelledError();
		if (failed) throw new Error(`${role} failed: ${result.stderr || result.stopReason || `exit ${result.exitCode}`}`);
		if (!result.output.trim()) throw new Error(`${role} exited without a terminal assistant JSON message`);
		return result;
	}

	private validatePlanFiles(plan: PlanArtifact): void {
		const actual = [...new Set(plan.files)].sort();
		const required = [...REQUIRED_PLAN_FILES].sort();
		if (canonicalJson(actual) !== canonicalJson(required)) {
			throw new Error(`Plan files must be exactly: ${required.join(", ")}`);
		}
	}

	private validateImplementationReceipt(text: string): void {
		const value = extractJson(text);
		this.schema.validate("implementation", value);
		if (!value || typeof value !== "object" || Array.isArray(value)) throw new Error("Implementation receipt must be an object");
		const receipt = value as Record<string, unknown>;
		if (typeof receipt.summary !== "string" || !Array.isArray(receipt.filesChanged)) {
			throw new Error("Implementation receipt requires summary and filesChanged");
		}
	}

	private async loadPlan(paths: RunPaths): Promise<PlanArtifact> {
		const stored = await readJson<PlanArtifact & { planHash?: string }>(join(paths.runDir, "plan.json"));
		const { planHash: _planHash, ...plan } = stored;
		return plan;
	}

	private async assertPlanIntegrity(paths: RunPaths, state: WorkflowState): Promise<void> {
		if (!state.planHash) throw new Error("Missing state plan hash");
		const stored = await readJson<PlanArtifact & { planHash?: string }>(join(paths.runDir, "plan.json"));
		const { planHash, ...plan } = stored;
		const actual = sha256(canonicalJson(plan));
		if (planHash !== state.planHash || actual !== state.planHash) {
			throw new Error("plan.json no longer matches the approved plan hash");
		}
		this.validatePlanFiles(plan);
	}

	private async assertApprovalIntegrity(paths: RunPaths, state: WorkflowState): Promise<void> {
		if (!state.baselineHash) throw new Error("Missing baseline hash");
		if ((await hashTree(paths.baselineDir)) !== state.baselineHash) throw new Error("Baseline changed before approval");
		if ((await hashTree(paths.worktreeDir)) !== state.baselineHash) throw new Error("Worktree changed before approval");
		await this.assertPlanIntegrity(paths, state);
		if (!state.approvalHash || this.computeApprovalHash(state) !== state.approvalHash) {
			throw new Error("Approval binding no longer matches plan, baseline, contract, and runtime hashes");
		}
	}

	private async assertApprovalArtifact(paths: RunPaths, state: WorkflowState): Promise<void> {
		const approval = await readJson<ApprovalArtifact>(join(paths.runDir, "approval.json"));
		this.schema.validate<ApprovalArtifact>("approval", approval);
		if (
			approval.decision !== "approved" ||
			approval.runId !== state.runId ||
			!state.planHash ||
			!state.baselineHash ||
			!state.approvalHash ||
			approval.planHash !== state.planHash ||
			approval.baselineHash !== state.baselineHash ||
			approval.contractHash !== state.contractHash ||
			approval.runtimeHash !== state.runtimeHash ||
			approval.approvalHash !== state.approvalHash ||
			this.computeApprovalHash(state) !== state.approvalHash
		) {
			throw new Error("Missing or invalid approval receipt for a mutating phase");
		}
	}

	private async recoverInterruptedDecision(paths: RunPaths, state: WorkflowState): Promise<WorkflowState> {
		if (!state.pendingOperation) return state;
		if (
			state.phase !== "awaiting_approval" ||
			!new Set(["record-approval", "record-rejection"]).has(state.pendingOperation.name)
		) {
			throw new Error(`Cannot recover unexpected pending operation ${state.pendingOperation.name} during a decision`);
		}
		return await this.settle(paths, state, "error", { recovered: true, reason: "decision-retried-after-crash" });
	}

	private async writeDecisionReceipt(
		paths: RunPaths,
		state: WorkflowState,
		approval: ApprovalArtifact,
		operationName: "record-approval" | "record-rejection",
	): Promise<WorkflowState> {
		state = await this.begin(paths, state, operationName);
		try {
			await writeJsonAtomic(join(paths.runDir, "approval.json"), approval);
			return await this.settle(paths, state, "ok", { decision: approval.decision, approvalHash: approval.approvalHash });
		} catch (error) {
			await this.settle(paths, state, "error", { error: errorMessage(error) });
			throw error;
		}
	}

	private computeApprovalHash(state: WorkflowState): string {
		if (!state.planHash || !state.baselineHash) throw new Error("Cannot compute approval hash before planning and baseline capture");
		return sha256(
			canonicalJson({
				planHash: state.planHash,
				baselineHash: state.baselineHash,
				contractHash: state.contractHash,
				runtimeHash: state.runtimeHash,
			}),
		);
	}

	private async writePatch(paths: RunPaths): Promise<string> {
		const patch = await createPatch(paths.baselineDir, paths.worktreeDir);
		await writeFileText(join(paths.runDir, "patch.diff"), patch);
		return patch;
	}

	private async writeReport(paths: RunPaths, state: WorkflowState): Promise<void> {
		const artifactNames = [
			"baseline.json",
			"discovery-code.json",
			"discovery-tests.json",
			"plan.json",
			"approval.json",
			"patch.diff",
			"review.json",
			"verification.json",
		];
		const report = [
			`# Evidence-Gated Change Run ${state.runId}`,
			"",
			`- Phase: ${state.phase}`,
			`- Plan hash: ${state.planHash ?? "not-created"}`,
			`- Approval hash: ${state.approvalHash ?? "not-created"}`,
			`- Contract hash: ${state.contractHash}`,
			`- Runtime hash: ${state.runtimeHash}`,
			`- Repair count: ${state.repairCount}/${state.maxRepair}`,
			`- Last error: ${state.lastError ?? "none"}`,
			`- Terminal reason: ${state.terminalReason ?? "none"}`,
			"",
			"## Evidence",
			"",
			...artifactNames.map((name) => `- ${name}`),
			"- events.jsonl",
			"",
			"The deterministic gate uses real command exit codes. Agent prose is never treated as test evidence.",
			"",
		].join("\n");
		await writeFileText(join(paths.runDir, "report.md"), report);
	}

	private async failRun(paths: RunPaths, error: unknown): Promise<WorkflowState> {
		let state = await this.reconcileEventLog(paths, await this.load(paths));
		const cancelled = error instanceof WorkflowCancelledError;
		if (state.pendingOperation) {
			state = await this.settle(paths, state, cancelled ? "cancelled" : "error", { error: errorMessage(error) });
		}
		if (!isTerminalPhase(state.phase)) {
			state = {
				...state,
				lastError: errorMessage(error),
				terminalReason: cancelled ? "cancelled" : "workflow-error",
			};
			state = await this.transition(paths, state, cancelled ? "cancelled" : "blocked", cancelled ? "cancelled" : "workflow-error");
		}
		await this.writeReport(paths, state);
		return state;
	}

	private async begin(paths: RunPaths, state: WorkflowState, name: string): Promise<WorkflowState> {
		if (state.pendingOperation) throw new Error(`Unsettled operation already exists: ${state.pendingOperation.id}`);
		const operationId = this.idFactory();
		state = {
			...state,
			pendingOperation: { id: operationId, name, phase: state.phase, startedAt: this.now().toISOString() },
			updatedAt: this.now().toISOString(),
		};
		await this.emit(state, { kind: "intent", name, operationId });
		await this.persist(paths, state);
		return state;
	}

	private async settle(
		paths: RunPaths,
		state: WorkflowState,
		status: "ok" | "error" | "cancelled",
		details?: Record<string, unknown>,
	): Promise<WorkflowState> {
		const operation = state.pendingOperation;
		if (!operation) throw new Error("Cannot settle without a pending operation");
		const existingEvents = await readWorkflowEvents(paths.eventsFile);
		if (existingEvents.some((event) => event.kind === "settled" && event.operationId === operation.id)) {
			throw new Error(`Operation ${operation.id} already has a durable settlement`);
		}
		const { pendingOperation: _pendingOperation, ...rest } = state;
		const next: WorkflowState = { ...rest, updatedAt: this.now().toISOString() };
		this.schema.validate<WorkflowState>("state", next);
		const settledEvent: Omit<WorkflowEvent, "schemaVersion" | "sequence" | "timestamp" | "runId" | "phase"> = {
			kind: "settled",
			name: operation.name,
			operationId: operation.id,
			status,
		};
		settledEvent.details = { ...(details ?? {}), committedState: next };
		await this.emit(state, settledEvent);
		await this.persist(paths, next);
		return next;
	}

	private async transition(paths: RunPaths, state: WorkflowState, phase: WorkflowState["phase"], name: string): Promise<WorkflowState> {
		const next = transitionState(state, phase, this.now().toISOString());
		await this.persist(paths, next);
		await this.emit(next, { kind: "state", name, status: "ok", details: { from: state.phase, to: phase } });
		return next;
	}

	private async persist(paths: RunPaths, state: WorkflowState): Promise<void> {
		this.schema.validate<WorkflowState>("state", state);
		await saveState(paths, state);
		this.onSnapshot?.(safeClone(state));
	}

	private async load(paths: RunPaths): Promise<WorkflowState> {
		return this.schema.validate<WorkflowState>("state", await readJson<WorkflowState>(paths.stateFile));
	}

	private async reconcileEventLog(paths: RunPaths, state: WorkflowState): Promise<WorkflowState> {
		const events = await readWorkflowEvents(paths.eventsFile);
		const intents = events.filter((event) => event.kind === "intent" && event.operationId);
		const settlements = events.filter((event) => event.kind === "settled" && event.operationId);
		const settlementCounts = new Map<string, number>();
		for (const event of settlements) {
			const operationId = event.operationId ?? "";
			settlementCounts.set(operationId, (settlementCounts.get(operationId) ?? 0) + 1);
		}
		for (const [operationId, count] of settlementCounts) {
			if (count !== 1) throw new Error(`Operation ${operationId} has ${count} durable settlements`);
		}

		if (state.pendingOperation) {
			const operationId = state.pendingOperation.id;
			if (intents.filter((event) => event.operationId === operationId).length !== 1) {
				throw new Error(`Pending operation ${operationId} does not have exactly one durable intent`);
			}
			const settlement = settlements.find((event) => event.operationId === operationId);
			if (!settlement) return state;
			const committed = settlement.details?.committedState;
			const recovered = this.schema.validate<WorkflowState>("state", committed);
			if (recovered.runId !== state.runId || recovered.pendingOperation) {
				throw new Error(`Settlement ${operationId} contains an invalid committed state`);
			}
			await this.persist(paths, recovered);
			return recovered;
		}

		const unsettledIntents = intents.filter(
			(intent) => !settlements.some((settlement) => settlement.operationId === intent.operationId),
		);
		if (unsettledIntents.length > 1) throw new Error("Event log contains multiple unsettled intents");
		const orphan = unsettledIntents[0];
		if (!orphan?.operationId) return state;
		if (orphan.phase !== state.phase) {
			throw new Error(`Orphan intent phase ${orphan.phase} does not match state phase ${state.phase}`);
		}
		const recovered: WorkflowState = {
			...state,
			pendingOperation: {
				id: orphan.operationId,
				name: orphan.name,
				phase: orphan.phase,
				startedAt: orphan.timestamp,
			},
			updatedAt: this.now().toISOString(),
		};
		await this.persist(paths, recovered);
		return recovered;
	}

	private async emit(state: WorkflowState, partial: Omit<WorkflowEvent, "schemaVersion" | "sequence" | "timestamp" | "runId" | "phase">): Promise<void> {
		const prior = this.eventQueues.get(state.runId) ?? Promise.resolve();
		const next = prior.then(async () => {
			const currentSequence = this.sequences.has(state.runId)
				? (this.sequences.get(state.runId) ?? 0)
				: await readLastEventSequence(getRunPaths(this.projectRoot, state.runId).eventsFile);
			const sequence = currentSequence + 1;
			this.sequences.set(state.runId, sequence);
			const event: WorkflowEvent = {
				schemaVersion: 1,
				sequence,
				timestamp: this.now().toISOString(),
				runId: state.runId,
				phase: state.phase,
				...partial,
			};
			await appendEvent(getRunPaths(this.projectRoot, state.runId).eventsFile, event);
		});
		this.eventQueues.set(state.runId, next);
		await next;
	}

	private async withController<T>(runId: string, action: (signal: AbortSignal) => Promise<T>): Promise<T> {
		if (this.controllers.has(runId)) throw new Error(`Run ${runId} already has an active operation`);
		const controller = new AbortController();
		let markSettled: (() => void) | undefined;
		const settlement = new Promise<void>((resolvePromise) => {
			markSettled = resolvePromise;
		});
		this.controllers.set(runId, controller);
		this.activeSettlements.set(runId, settlement);
		try {
			return await action(controller.signal);
		} finally {
			this.controllers.delete(runId);
			this.activeSettlements.delete(runId);
			markSettled?.();
		}
	}

	private throwIfAborted(signal: AbortSignal): void {
		if (signal.aborted) throw new WorkflowCancelledError();
	}
}

async function writeFileText(filePath: string, content: string): Promise<void> {
	await writeFile(filePath, content, { encoding: "utf8", mode: 0o600 });
}
