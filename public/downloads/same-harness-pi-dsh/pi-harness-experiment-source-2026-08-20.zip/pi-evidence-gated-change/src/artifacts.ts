import { createHash, randomUUID } from "node:crypto";
import { execFile } from "node:child_process";
import { cp, mkdir, open, readFile, readdir, rename, stat, writeFile } from "node:fs/promises";
import { dirname, join, relative, resolve, sep } from "node:path";
import { promisify } from "node:util";
import type { RunPaths, WorkflowEvent, WorkflowState } from "./types.ts";
import { canonicalJson, sha256 } from "./json.ts";

const execFileAsync = promisify(execFile);

export function assertInside(root: string, target: string, label = "path"): string {
	const resolvedRoot = resolve(root);
	const resolvedTarget = resolve(target);
	const prefix = resolvedRoot.endsWith(sep) ? resolvedRoot : `${resolvedRoot}${sep}`;
	if (resolvedTarget !== resolvedRoot && !resolvedTarget.startsWith(prefix)) {
		throw new Error(`${label} escapes root: ${resolvedTarget}`);
	}
	return resolvedTarget;
}

export function getRunPaths(projectRoot: string, runId: string): RunPaths {
	if (!/^[a-z0-9][a-z0-9-]{5,80}$/.test(runId)) throw new Error(`Invalid run id: ${runId}`);
	const runsRoot = resolve(projectRoot, "runs");
	const runDir = assertInside(runsRoot, join(runsRoot, runId), "run directory");
	return {
		runDir,
		baselineDir: join(runDir, "baseline"),
		worktreeDir: join(runDir, "worktree"),
		eventsFile: join(runDir, "events.jsonl"),
		stateFile: join(runDir, "state.json"),
	};
}

export async function writeJsonAtomic(filePath: string, value: unknown): Promise<void> {
	await mkdir(dirname(filePath), { recursive: true });
	const tempPath = `${filePath}.${process.pid}.${randomUUID()}.tmp`;
	await writeFile(tempPath, `${JSON.stringify(value, null, 2)}\n`, { encoding: "utf8", mode: 0o600 });
	await rename(tempPath, filePath);
}

export async function appendEvent(filePath: string, event: WorkflowEvent): Promise<void> {
	await mkdir(dirname(filePath), { recursive: true });
	const handle = await open(filePath, "a", 0o600);
	try {
		await handle.appendFile(`${canonicalJson(event)}\n`, "utf8");
		await handle.sync();
	} finally {
		await handle.close();
	}
}

export async function readWorkflowEvents(filePath: string): Promise<WorkflowEvent[]> {
	try {
		const lines = (await readFile(filePath, "utf8")).trim().split("\n").filter(Boolean);
		const events = lines.map((line) => JSON.parse(line) as WorkflowEvent);
		for (let index = 0; index < events.length; index++) {
			if (events[index]?.sequence !== index + 1) throw new Error(`Event sequence gap at line ${index + 1}`);
		}
		return events;
	} catch (error) {
		const candidate = error as NodeJS.ErrnoException;
		if (candidate.code === "ENOENT") return [];
		throw error;
	}
}

export async function readLastEventSequence(filePath: string): Promise<number> {
	const events = await readWorkflowEvents(filePath);
	return events.at(-1)?.sequence ?? 0;
}

export async function readJson<T>(filePath: string): Promise<T> {
	return JSON.parse(await readFile(filePath, "utf8")) as T;
}

export async function saveState(paths: RunPaths, state: WorkflowState): Promise<void> {
	await writeJsonAtomic(paths.stateFile, state);
}

export async function initializeRunDirectory(paths: RunPaths): Promise<void> {
	await mkdir(dirname(paths.runDir), { recursive: true });
	await mkdir(paths.runDir, { recursive: false });
}

export async function createIsolatedFixture(projectRoot: string, paths: RunPaths): Promise<void> {
	const fixtureRoot = resolve(projectRoot, "fixtures", "todo-service");
	assertInside(projectRoot, fixtureRoot, "fixture root");
	await cp(fixtureRoot, paths.baselineDir, { recursive: true, errorOnExist: true });
	await cp(fixtureRoot, paths.worktreeDir, { recursive: true, errorOnExist: true });
}

async function walkFiles(root: string, current = root): Promise<string[]> {
	const files: string[] = [];
	for (const entry of await readdir(current, { withFileTypes: true })) {
		if (entry.name === "node_modules" || entry.name === ".git") continue;
		const fullPath = join(current, entry.name);
		if (entry.isSymbolicLink()) throw new Error(`Symlinks are forbidden in workflow trees: ${fullPath}`);
		if (entry.isDirectory()) files.push(...(await walkFiles(root, fullPath)));
		else if (entry.isFile()) files.push(relative(root, fullPath).split(sep).join("/"));
	}
	return files.sort();
}

export async function hashTree(root: string): Promise<string> {
	const digest = createHash("sha256");
	for (const file of await walkFiles(root)) {
		digest.update(file);
		digest.update("\0");
		digest.update(await readFile(join(root, file)));
		digest.update("\0");
	}
	return digest.digest("hex");
}

export async function hashContract(projectRoot: string): Promise<string> {
	const roots = [
		resolve(projectRoot, "contract"),
		resolve(projectRoot, "skills", "evidence-gated-change"),
		resolve(projectRoot, "agents"),
		resolve(projectRoot, "fixtures", "todo-service"),
	];
	const entries: Array<{ path: string; hash: string }> = [];
	for (const root of roots) {
		for (const file of await walkFiles(root)) {
			const projectRelative = relative(projectRoot, join(root, file)).split(sep).join("/");
			if (projectRelative === "contract/manifest.json") continue;
			entries.push({ path: projectRelative, hash: sha256(await readFile(join(root, file))) });
		}
	}
	entries.sort((left, right) => left.path.localeCompare(right.path));
	const digest = createHash("sha256");
	for (const entry of entries) digest.update(`${entry.path}\0${entry.hash}\0`);
	return digest.digest("hex");
}

export async function hashRuntime(projectRoot: string): Promise<string> {
	const paths: string[] = [];
	for (const file of await walkFiles(resolve(projectRoot, "src"))) paths.push(`src/${file}`);
	paths.push("scripts/verify-fixture.mjs", "package.json", "package-lock.json");
	paths.sort();
	const digest = createHash("sha256");
	for (const path of paths) {
		const absolute = assertInside(projectRoot, resolve(projectRoot, path), "runtime hash path");
		digest.update(`${path}\0${sha256(await readFile(absolute))}\0`);
	}
	return digest.digest("hex");
}

export async function changedFiles(baselineDir: string, worktreeDir: string): Promise<string[]> {
	const baselineFiles = await walkFiles(baselineDir);
	const worktreeFiles = await walkFiles(worktreeDir);
	const all = [...new Set([...baselineFiles, ...worktreeFiles])].sort();
	const changed: string[] = [];
	for (const file of all) {
		let left: Buffer | undefined;
		let right: Buffer | undefined;
		try {
			left = await readFile(join(baselineDir, file));
		} catch {}
		try {
			right = await readFile(join(worktreeDir, file));
		} catch {}
		if (!left || !right || sha256(left) !== sha256(right)) changed.push(file);
	}
	return changed;
}

export async function createPatch(baselineDir: string, worktreeDir: string): Promise<string> {
	try {
		const result = await execFileAsync(
			"git",
			["diff", "--no-index", "--binary", "--src-prefix=a/", "--dst-prefix=b/", "--", baselineDir, worktreeDir],
			{ maxBuffer: 10 * 1024 * 1024 },
		);
		return result.stdout;
	} catch (error) {
		const candidate = error as { code?: number; stdout?: string; stderr?: string };
		if (candidate.code === 1 && typeof candidate.stdout === "string") return candidate.stdout;
		throw new Error(`Unable to create patch: ${candidate.stderr ?? String(error)}`);
	}
}

export async function isDirectory(path: string): Promise<boolean> {
	try {
		return (await stat(path)).isDirectory();
	} catch {
		return false;
	}
}
