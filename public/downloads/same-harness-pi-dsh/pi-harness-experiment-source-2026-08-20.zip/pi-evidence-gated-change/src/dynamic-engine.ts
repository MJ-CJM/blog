import { randomUUID } from "node:crypto";
import { appendFile, mkdir, readFile, readdir, writeFile } from "node:fs/promises";
import { basename, join, resolve, sep } from "node:path";
import { Worker } from "node:worker_threads";
import { writeJsonAtomic } from "./artifacts.ts";
import { sanitizeDynamicDiagnostic, sanitizeDynamicDiagnosticJson, summarizeDynamicAgentFailure } from "./dynamic-diagnostics.ts";
import { loadDynamicConfig, listDynamicWorkflows, loadDynamicWorkflow, resolveDynamicModels } from "./dynamic-parser.ts";
import type {
	DynamicAgentRunner,
	DynamicConfig,
	DynamicEvent,
	DynamicJson,
	DynamicParentModel,
	DynamicRunProgress,
	DynamicRunProgressListener,
	DynamicRunState,
	DynamicStartOptions,
	DynamicThinkingLevel,
	ParsedDynamicWorkflow,
	ResolvedDynamicModel,
} from "./dynamic-types.ts";
import { DYNAMIC_THINKING_LEVELS } from "./dynamic-types.ts";

const RUN_ID = /^dw-[a-z0-9-]{8,80}$/;

class DynamicFatalError extends Error {}

interface DynamicPaths {
	runDir: string;
	stateFile: string;
	eventsFile: string;
	resultFile: string;
	workflowFile: string;
}

interface ActiveRun {
	controller: AbortController;
	promise: Promise<DynamicRunState>;
	cancelRequested: boolean;
	onProgress?: DynamicRunProgressListener;
}

type DynamicWorkerMessage =
	| { type: "agent"; id: number; prompt: unknown; options?: unknown }
	| { type: "phase"; title: unknown }
	| { type: "log"; message: unknown }
	| { type: "completed"; value: unknown }
	| { type: "failed"; error: string };

interface DynamicEngineOptions {
	projectRoot: string;
	runner: DynamicAgentRunner;
}

function inside(root: string, target: string): string {
	const resolvedRoot = resolve(root);
	const resolvedTarget = resolve(target);
	const prefix = resolvedRoot.endsWith(sep) ? resolvedRoot : `${resolvedRoot}${sep}`;
	if (!resolvedTarget.startsWith(prefix)) throw new Error(`Path escapes Dynamic Workflow root: ${resolvedTarget}`);
	return resolvedTarget;
}

function getPaths(projectRoot: string, runId: string): DynamicPaths {
	if (!RUN_ID.test(runId)) throw new Error(`Invalid Dynamic Workflow run id: ${runId}`);
	const root = resolve(projectRoot, "dynamic-workflow", "runs");
	const runDir = inside(root, join(root, runId));
	return {
		runDir,
		stateFile: join(runDir, "state.json"),
		eventsFile: join(runDir, "events.jsonl"),
		resultFile: join(runDir, "result.json"),
		workflowFile: join(runDir, "workflow.js"),
	};
}

function materializeJson(value: unknown, label: string, maxBytes: number): DynamicJson {
	const visit = (candidate: unknown, path: string): void => {
		if (candidate === null || typeof candidate === "string" || typeof candidate === "boolean") return;
		if (typeof candidate === "number") {
			if (!Number.isFinite(candidate)) throw new DynamicFatalError(`${path} contains a non-finite number`);
			return;
		}
		if (Array.isArray(candidate)) {
			for (let index = 0; index < candidate.length; index++) visit(candidate[index], `${path}[${index}]`);
			return;
		}
		if (typeof candidate !== "object" || Object.prototype.toString.call(candidate) !== "[object Object]") {
			throw new DynamicFatalError(`${path} is not plain JSON data`);
		}
		const keys = Reflect.ownKeys(candidate);
		if (keys.some((key) => typeof key !== "string")) throw new DynamicFatalError(`${path} contains a symbol key`);
		for (const key of keys as string[]) {
			const descriptor = Object.getOwnPropertyDescriptor(candidate, key);
			if (!descriptor?.enumerable || !("value" in descriptor)) throw new DynamicFatalError(`${path}.${key} is not a plain JSON property`);
			visit(descriptor.value, `${path}.${key}`);
		}
	};
	visit(value, label);
	let serialized: string;
	try {
		serialized = JSON.stringify(value);
	} catch (error) {
		throw new DynamicFatalError(`${label} cannot be materialized: ${error instanceof Error ? error.message : String(error)}`);
	}
	if (serialized === undefined) throw new DynamicFatalError(`${label} cannot be undefined`);
	if (Buffer.byteLength(serialized) > maxBytes) throw new DynamicFatalError(`${label} exceeds ${maxBytes} bytes`);
	return JSON.parse(serialized) as DynamicJson;
}

function readAgentOptions(
	value: unknown,
	maxBytes: number,
	parent: DynamicParentModel | undefined,
	currentPhase: string | undefined,
	prompt: string,
): ResolvedDynamicModel & { label: string; phase?: string } {
	const materialized = value === undefined || value === null ? {} : materializeJson(value, "agent options", maxBytes);
	if (!materialized || typeof materialized !== "object" || Array.isArray(materialized)) {
		throw new DynamicFatalError("agent options must be an object");
	}
	for (const key of Object.keys(materialized)) {
		if (!["provider", "model", "thinking", "label", "phase"].includes(key)) {
			throw new DynamicFatalError(`agent option ${key} is not supported`);
		}
	}
	const provider = materialized.provider ?? parent?.provider;
	const model = materialized.model ?? parent?.model;
	const firstLine = prompt.split("\n", 1)[0] ?? prompt;
	const defaultLabel = firstLine.length <= 48 ? firstLine : `${firstLine.slice(0, 47)}…`;
	const label = materialized.label ?? defaultLabel;
	if (typeof provider !== "string" || !provider) throw new DynamicFatalError("agent option provider must be a non-empty string");
	if (typeof model !== "string" || !model) throw new DynamicFatalError("agent option model must be a non-empty string");
	if (typeof label !== "string" || !label) throw new DynamicFatalError("agent option label must be a non-empty string");
	const result: ResolvedDynamicModel & { label: string; phase?: string } = { provider, model, label };
	const phase = materialized.phase ?? currentPhase;
	if (phase !== undefined) {
		if (typeof phase !== "string" || !phase) throw new DynamicFatalError("agent option phase must be a non-empty string");
		result.phase = phase;
	}
	if (materialized.thinking !== undefined) {
		if (typeof materialized.thinking !== "string" || !DYNAMIC_THINKING_LEVELS.includes(materialized.thinking as DynamicThinkingLevel)) {
			throw new DynamicFatalError("agent option thinking is invalid");
		}
		result.thinking = materialized.thinking as DynamicThinkingLevel;
	} else if (parent?.thinking && provider === parent.provider && model === parent.model) {
		result.thinking = parent.thinking;
	}
	return result;
}

function createSemaphore(limit: number, signal: AbortSignal): { acquire(): Promise<() => void> } {
	let active = 0;
	const waiters: Array<{ resolve: (release: () => void) => void; reject: (error: Error) => void }> = [];
	const release = (): void => {
		active--;
		const waiter = waiters.shift();
		if (!waiter) return;
		if (signal.aborted) {
			waiter.reject(new DynamicFatalError("Dynamic Workflow cancelled"));
			release();
			return;
		}
		active++;
		waiter.resolve(release);
	};
	return {
		async acquire(): Promise<() => void> {
			if (signal.aborted) throw new DynamicFatalError("Dynamic Workflow cancelled");
			if (active < limit) {
				active++;
				return release;
			}
			return await new Promise<() => void>((resolvePromise, rejectPromise) => {
				waiters.push({ resolve: resolvePromise, reject: rejectPromise });
			});
		},
	};
}

function publishProgress(listener: DynamicRunProgressListener | undefined, state: DynamicRunState, event?: DynamicEvent): void {
	if (!listener) return;
	const progress: DynamicRunProgress = {
		state: structuredClone(state),
		...(event ? { event: structuredClone(event) } : {}),
	};
	try {
		listener(progress);
	} catch {
		// UI/reporting callbacks are observational and must not change workflow settlement.
	}
}

export class DynamicWorkflowEngine {
	private readonly projectRoot: string;
	private readonly runner: DynamicAgentRunner;
	private readonly active = new Map<string, ActiveRun>();

	constructor(options: DynamicEngineOptions) {
		this.projectRoot = options.projectRoot;
		this.runner = options.runner;
	}

	private get workflowsRoot(): string {
		return resolve(this.projectRoot, "dynamic-workflow", "shared", "workflows");
	}

	private get configPath(): string {
		return resolve(this.projectRoot, "dynamic-workflow", "pi", "model-profiles.json");
	}

	async list(): Promise<Array<{ name: string; description: string; whenToUse?: string }>> {
		const config = await loadDynamicConfig(this.configPath);
		return (await listDynamicWorkflows(this.workflowsRoot, config.limits.maxSourceBytes)).map((workflow) => ({
			name: workflow.meta.name,
			description: workflow.meta.description,
			...(workflow.meta.whenToUse ? { whenToUse: workflow.meta.whenToUse } : {}),
		}));
	}

	async models(parent: DynamicParentModel | undefined): Promise<Record<string, ResolvedDynamicModel | { inherit: true }>> {
		const config = await loadDynamicConfig(this.configPath);
		const result: Record<string, ResolvedDynamicModel | { inherit: true }> = {};
		for (const [name, profile] of Object.entries(config.profiles)) {
			if (profile.provider && profile.model) {
				result[name] = { provider: profile.provider, model: profile.model, ...(profile.thinking ? { thinking: profile.thinking } : {}) };
			} else if (parent) {
				result[name] = { provider: parent.provider, model: parent.model, ...(parent.thinking ? { thinking: parent.thinking } : {}) };
			} else {
				result[name] = { inherit: true };
			}
		}
		return result;
	}

	async start(
		workflowId: string,
		task: string,
		cwd: string,
		parent: DynamicParentModel | undefined,
		options: DynamicStartOptions = {},
	): Promise<DynamicRunState> {
		if (!task.trim()) throw new Error("Dynamic Workflow task must not be empty");
		const config = await loadDynamicConfig(this.configPath);
		const workflow = await loadDynamicWorkflow(this.workflowsRoot, workflowId, config.limits.maxSourceBytes);
		const models = resolveDynamicModels(config, parent);
		const runId = `dw-${new Date().toISOString().replace(/[-:.TZ]/g, "").toLowerCase()}-${randomUUID().slice(0, 8)}`;
		const paths = getPaths(this.projectRoot, runId);
		await mkdir(resolve(this.projectRoot, "dynamic-workflow", "runs"), { recursive: true });
		await mkdir(paths.runDir, { recursive: false });
		await writeFile(paths.workflowFile, workflow.source, { encoding: "utf8", mode: 0o600 });
		const now = new Date().toISOString();
		const state: DynamicRunState = {
			schemaVersion: 1,
			runId,
			workflow: workflow.meta.name,
			workflowHash: workflow.sourceHash,
			status: "queued",
			task,
			cwd: resolve(cwd),
			createdAt: now,
			updatedAt: now,
			agentsStarted: 0,
			agentsCompleted: 0,
			activeAgents: 0,
		};
		await writeJsonAtomic(paths.stateFile, state);
		const controller = new AbortController();
		const active: ActiveRun = {
			controller,
			promise: Promise.resolve(state),
			cancelRequested: false,
			...(options.onProgress ? { onProgress: options.onProgress } : {}),
		};
		this.active.set(runId, active);
		publishProgress(active.onProgress, state);
		active.promise = this.execute(workflow, config, models, parent, state, paths, controller.signal, active).finally(() => {
			this.active.delete(runId);
		});
		return structuredClone(state);
	}

	async wait(runId: string): Promise<DynamicRunState> {
		const active = this.active.get(runId);
		if (active) return await active.promise;
		const state = await this.status(runId);
		if (["completed", "failed", "cancelled"].includes(state.status)) return state;
		throw new Error(`Run ${runId} is not active in this Pi process; it cannot be awaited`);
	}

	async result(runId: string): Promise<DynamicJson> {
		const state = await this.status(runId);
		if (state.status !== "completed") throw new Error(`Run ${runId} has no completed result (status=${state.status})`);
		return await this.readStoredResult(runId);
	}

	async completedResult(runId?: string): Promise<{ state: DynamicRunState; value: DynamicJson }> {
		const selected = runId ?? (await this.latestRunId("completed"));
		if (!selected) throw new Error("No completed Dynamic Workflow run exists");
		const state = await this.status(selected);
		if (state.status !== "completed") {
			throw new Error(`Run ${selected} has no completed result (status=${state.status})`);
		}
		return { state, value: await this.readStoredResult(selected) };
	}

	private async readStoredResult(runId: string): Promise<DynamicJson> {
		const parsed = JSON.parse(await readFile(getPaths(this.projectRoot, runId).resultFile, "utf8")) as { value?: unknown };
		if (!("value" in parsed)) throw new Error(`Run ${runId} result.json does not contain value`);
		return materializeJson(parsed.value, "stored workflow result", Number.MAX_SAFE_INTEGER);
	}

	async status(runId?: string): Promise<DynamicRunState> {
		const selected = runId ?? (await this.latestRunId());
		if (!selected) throw new Error("No Dynamic Workflow run exists");
		return JSON.parse(await readFile(getPaths(this.projectRoot, selected).stateFile, "utf8")) as DynamicRunState;
	}

	async cancel(runId: string): Promise<DynamicRunState> {
		const active = this.active.get(runId);
		if (!active) {
			const state = await this.status(runId);
			if (["completed", "failed", "cancelled"].includes(state.status)) return state;
			throw new Error(`Run ${runId} is not active in this Pi process; cross-session resume and cancel are not supported`);
		}
		active.cancelRequested = true;
		active.controller.abort(new Error("Cancelled by user"));
		return await active.promise;
	}

	async abortAll(): Promise<void> {
		const runs = [...this.active.values()];
		for (const run of runs) {
			run.cancelRequested = true;
			run.controller.abort(new Error("Pi session shut down"));
		}
		await Promise.allSettled(runs.map((run) => run.promise));
	}

	private async latestRunId(status?: DynamicRunState["status"]): Promise<string | undefined> {
		const root = resolve(this.projectRoot, "dynamic-workflow", "runs");
		let entries;
		try {
			entries = await readdir(root, { withFileTypes: true });
		} catch (error) {
			if ((error as NodeJS.ErrnoException).code === "ENOENT") return undefined;
			throw error;
		}
		const candidates = await Promise.allSettled(
			entries
				.filter((entry) => entry.isDirectory() && RUN_ID.test(entry.name))
				.map(async (entry) => JSON.parse(await readFile(join(root, entry.name, "state.json"), "utf8")) as DynamicRunState),
		);
		const states = candidates.flatMap((candidate) => (candidate.status === "fulfilled" ? [candidate.value] : []));
		return states
			.filter((state) => status === undefined || state.status === status)
			.sort((left, right) => right.updatedAt.localeCompare(left.updatedAt))[0]?.runId;
	}

	private async execute(
		workflow: ParsedDynamicWorkflow,
		config: DynamicConfig,
		models: Record<string, ResolvedDynamicModel>,
		parent: DynamicParentModel | undefined,
		state: DynamicRunState,
		paths: DynamicPaths,
		signal: AbortSignal,
		activeRun: ActiveRun,
	): Promise<DynamicRunState> {
		let sequence = 0;
		let eventQueue: Promise<void> = Promise.resolve();
		let stateQueue: Promise<void> = Promise.resolve();
		let persistedState = structuredClone(state);
		const emit = async (type: DynamicEvent["type"], message: string, details?: Record<string, DynamicJson>): Promise<void> => {
			const sanitizedDetails = details ? sanitizeDynamicDiagnosticJson(details) as Record<string, DynamicJson> : undefined;
			const event: DynamicEvent = {
				schemaVersion: 1,
				sequence: ++sequence,
				timestamp: new Date().toISOString(),
				runId: state.runId,
				type,
				message: sanitizeDynamicDiagnostic(message),
				...(sanitizedDetails ? { details: sanitizedDetails } : {}),
			};
			const operation = eventQueue.then(async () => {
				await appendFile(paths.eventsFile, `${JSON.stringify(event)}\n`, { encoding: "utf8", mode: 0o600 });
				publishProgress(activeRun.onProgress, persistedState, event);
			});
			eventQueue = operation.catch(() => undefined);
			await operation;
		};
		const save = async (): Promise<void> => {
			state.updatedAt = new Date().toISOString();
			const snapshot = structuredClone(state);
			const operation = stateQueue.then(async () => {
				await writeJsonAtomic(paths.stateFile, snapshot);
				persistedState = snapshot;
				publishProgress(activeRun.onProgress, snapshot);
			});
			stateQueue = operation.catch(() => undefined);
			await operation;
		};
		const semaphore = createSemaphore(config.limits.maxParallel, signal);
		const declaredPhases = new Set((workflow.meta.phases ?? []).map((phase) => phase.title));
		const agentOperations = new Set<Promise<DynamicJson>>();
		let scriptWorker: Worker | undefined;
		let timedOut = false;
		const runTimeout = setTimeout(() => {
			if (!signal.aborted) {
				timedOut = true;
				activeRun.controller.abort(new Error("Dynamic Workflow timed out"));
			}
		}, config.limits.runTimeoutMs);
		runTimeout.unref();
		const abortOnFailure = (operation: Promise<void>): void => {
			void operation.catch((error: unknown) => {
				if (!signal.aborted) activeRun.controller.abort(error);
			});
		};

		try {
			state.status = "running";
			await save();
			await emit("state", "running");
			const runAgent = async (rawPrompt: unknown, rawOptions: unknown): Promise<DynamicJson> => {
				if (signal.aborted) throw new DynamicFatalError("Dynamic Workflow cancelled");
				if (typeof rawPrompt !== "string" || !rawPrompt.trim()) throw new DynamicFatalError("agent prompt must be a non-empty string");
				const nextAgentNumber = state.agentsStarted + 1;
				const options = readAgentOptions(rawOptions, config.limits.maxResultBytes, parent, state.currentPhase, rawPrompt);
				if (options.phase && declaredPhases.size > 0 && !declaredPhases.has(options.phase)) {
					throw new DynamicFatalError(`Unknown agent phase: ${options.phase}`);
				}
				if (nextAgentNumber > config.limits.maxAgents) throw new DynamicFatalError(`Agent cap exceeded: ${config.limits.maxAgents}`);
				state.agentsStarted = nextAgentNumber;
				const release = await semaphore.acquire();
				state.activeAgents++;
				await save();
				await emit("agent-start", options.label, {
					provider: options.provider,
					model: options.model,
					...(options.thinking ? { thinking: options.thinking } : {}),
					idleTimeoutMs: config.limits.agentIdleTimeoutMs,
					timeoutMs: config.limits.agentTimeoutMs,
				});
				try {
					const result = await this.runner.run(
						{
							provider: options.provider,
							model: options.model,
							...(options.thinking ? { thinking: options.thinking } : {}),
							label: options.label,
							...(options.phase ? { phase: options.phase } : {}),
							prompt: rawPrompt,
							cwd: state.cwd,
							idleTimeoutMs: config.limits.agentIdleTimeoutMs,
							timeoutMs: config.limits.agentTimeoutMs,
						},
						signal,
						(progress) => {
							abortOnFailure(
								emit("agent-retry", `${options.label}: retry ${progress.attempt}/${progress.maxAttempts}`, {
									attempt: progress.attempt,
									maxAttempts: progress.maxAttempts,
									delayMs: progress.delayMs,
									hardQuota: progress.hardQuota,
									diagnostic: progress.diagnostic,
								}),
							);
						},
					);
					if (signal.aborted) throw new DynamicFatalError("Dynamic Workflow cancelled");
					if (result.exitCode !== 0 || result.stopReason !== "stop") {
						const cause = summarizeDynamicAgentFailure(options.label, result.exitCode, result.stopReason, result.stderr);
						state.failureCauses ??= [];
						if (!state.failureCauses.includes(cause) && state.failureCauses.length < 8) state.failureCauses.push(cause);
						await save();
						await emit("agent-end", `${options.label}: failed`, {
							exitCode: result.exitCode,
							...(result.stopReason ? { stopReason: result.stopReason } : {}),
							error: cause,
						});
						return null;
					}
					const output = materializeJson(result.output, `agent ${options.label} output`, config.limits.maxResultBytes);
					state.agentsCompleted++;
					await save();
					await emit("agent-end", `${options.label}: completed`);
					return output;
				} finally {
					state.activeAgents--;
					release();
					await save();
				}
			};
			scriptWorker = new Worker(new URL("./dynamic-vm-worker.ts", import.meta.url), {
				execArgv: ["--experimental-strip-types"],
				workerData: {
					body: workflow.body,
					meta: workflow.meta,
					args: materializeJson({ task: state.task, models }, "workflow args", config.limits.maxResultBytes),
					syncTimeoutMs: config.limits.syncTimeoutMs,
					maxItemsPerCall: config.limits.maxItemsPerCall,
					maxResultBytes: config.limits.maxResultBytes,
				},
			});
			const worker = scriptWorker;
			let workerSettled = false;
			let removeAbortListener = (): void => undefined;
			const value = await new Promise<unknown>((resolvePromise, rejectPromise) => {
				const workerEntryClosed = (): boolean => workerSettled || signal.aborted;
				const respondToWorker = (message: unknown): void => {
					if (workerEntryClosed()) return;
					try {
						worker.postMessage(message);
					} catch (error) {
						if (!workerEntryClosed()) activeRun.controller.abort(error);
					}
				};
				const settle = (result: { ok: true; value: unknown } | { ok: false; error: Error }): void => {
					if (workerSettled) return;
					workerSettled = true;
					removeAbortListener();
					if (result.ok) resolvePromise(result.value);
					else rejectPromise(result.error);
				};
				const abort = (): void => {
					void worker.terminate();
					settle({ ok: false, error: signal.reason instanceof Error ? signal.reason : new DynamicFatalError("Dynamic Workflow cancelled") });
				};
				removeAbortListener = (): void => signal.removeEventListener("abort", abort);
				if (signal.aborted) abort();
				else signal.addEventListener("abort", abort, { once: true });
				worker.on("message", (message: DynamicWorkerMessage) => {
					if ((message.type === "agent" || message.type === "phase" || message.type === "log") && workerEntryClosed()) return;
					if (message.type === "phase") {
						if (typeof message.title !== "string" || (declaredPhases.size > 0 && !declaredPhases.has(message.title))) {
							activeRun.controller.abort(new DynamicFatalError(`Unknown phase: ${String(message.title)}`));
							return;
						}
						state.currentPhase = message.title;
						abortOnFailure(
							(async () => {
								await save();
								await emit("phase", message.title as string);
							})(),
						);
						return;
					}
					if (message.type === "log") {
						if (typeof message.message !== "string") activeRun.controller.abort(new DynamicFatalError("log() requires a string"));
						else abortOnFailure(emit("log", message.message));
						return;
					}
					if (message.type === "agent") {
						const operation = runAgent(message.prompt, message.options);
						agentOperations.add(operation);
						void operation
							.then((result) => respondToWorker({ type: "agent-result", id: message.id, ok: true, value: result }))
							.catch((error: unknown) =>
								respondToWorker({ type: "agent-result", id: message.id, ok: false, error: error instanceof Error ? error.message : String(error) }),
							)
							.finally(() => agentOperations.delete(operation));
						return;
					}
					if (message.type === "completed") settle({ ok: true, value: message.value });
					else settle({ ok: false, error: new DynamicFatalError(message.error) });
				});
				worker.on("error", (error) => settle({ ok: false, error }));
				worker.on("exit", (code) => {
					if (!workerSettled) settle({ ok: false, error: new DynamicFatalError(`Dynamic Workflow worker exited before a terminal result (${code})`) });
				});
			});
			const detached = await Promise.allSettled([...agentOperations]);
			const detachedFailure = detached.find((result) => result.status === "rejected");
			if (detachedFailure?.status === "rejected") throw detachedFailure.reason;
			if (signal.aborted) throw signal.reason instanceof Error ? signal.reason : new DynamicFatalError("Dynamic Workflow cancelled");
			const materialized = materializeJson(value, "workflow result", config.limits.maxResultBytes);
			await writeJsonAtomic(paths.resultFile, {
				schemaVersion: 1,
				runId: state.runId,
				workflow: workflow.meta.name,
				workflowHash: workflow.sourceHash,
				value: materialized,
			});
			if (signal.aborted) throw signal.reason instanceof Error ? signal.reason : new DynamicFatalError("Dynamic Workflow cancelled");
			state.status = "completed";
			state.resultFile = basename(paths.resultFile);
			await save();
			await emit("state", "completed");
		} catch (error) {
			if (!signal.aborted) activeRun.controller.abort(error);
			await Promise.allSettled([...agentOperations]);
			state.status = activeRun.cancelRequested ? "cancelled" : "failed";
			state.error = sanitizeDynamicDiagnostic(
				timedOut ? "Dynamic Workflow timed out" : error instanceof Error ? error.message : String(error),
			);
			state.activeAgents = 0;
			await save();
			await emit("state", state.status, { error: state.error });
		} finally {
			clearTimeout(runTimeout);
			if (scriptWorker) await scriptWorker.terminate();
			await Promise.allSettled([eventQueue, stateQueue]);
		}
		return structuredClone(state);
	}
}
