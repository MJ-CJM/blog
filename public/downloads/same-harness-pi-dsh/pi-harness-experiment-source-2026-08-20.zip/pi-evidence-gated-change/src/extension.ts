import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import type { ExtensionAPI, ExtensionCommandContext } from "@earendil-works/pi-coding-agent";
import { DynamicWorkflowEngine } from "./dynamic-engine.ts";
import {
	DYNAMIC_WORKFLOW_RESULT_ENTRY_TYPE,
	registerDynamicWorkflowResultRenderer,
	type DynamicWorkflowResultEntryData,
} from "./dynamic-result.ts";
import { PiDynamicAgentRunner } from "./dynamic-runner.ts";
import type { DynamicParentModel, DynamicThinkingLevel } from "./dynamic-types.ts";
import { displayDynamicState, displayStoredDynamicWorkflowResult, runDynamicWorkflowForeground } from "./dynamic-ui.ts";
import { PiSubprocessAgentRunner } from "./pi-runner.ts";
import type { WorkflowState } from "./types.ts";
import { EvidenceGatedWorkflow } from "./workflow.ts";

const STATE_ENTRY_TYPE = "evidence-gated-change-state";
const PROJECT_ROOT = resolve(dirname(fileURLToPath(import.meta.url)), "..");

function isWorkflowState(value: unknown): value is WorkflowState {
	if (!value || typeof value !== "object" || Array.isArray(value)) return false;
	const record = value as Record<string, unknown>;
	return record.schemaVersion === 1 && typeof record.runId === "string" && typeof record.phase === "string";
}

function parseTokens(args: string): string[] {
	return args.trim() ? args.trim().split(/\s+/) : [];
}

function displayState(state: WorkflowState): string {
	return [
		`run=${state.runId}`,
		`phase=${state.phase}`,
		`planHash=${state.planHash ?? "not-created"}`,
		`approvalHash=${state.approvalHash ?? "not-created"}`,
		`repair=${state.repairCount}/${state.maxRepair}`,
		`artifacts=${join(PROJECT_ROOT, "runs", state.runId)}`,
	].join("\n");
}

function dynamicParentModel(ctx: ExtensionCommandContext): DynamicParentModel | undefined {
	if (!ctx.model) return undefined;
	const result: DynamicParentModel = { provider: ctx.model.provider, model: ctx.model.id };
	if (ctx.thinkingLevel) result.thinking = ctx.thinkingLevel as DynamicThinkingLevel;
	return result;
}

export default function evidenceGatedChangeExtension(pi: ExtensionAPI): void {
	registerDynamicWorkflowResultRenderer(pi);
	const branchRunIds = new Set<string>();
	let latestRunId: string | undefined;
	let sessionActive = false;
	const runner = new PiSubprocessAgentRunner({ projectRoot: PROJECT_ROOT });
	const workflow = new EvidenceGatedWorkflow({
		projectRoot: PROJECT_ROOT,
		runner,
		onSnapshot(state) {
			branchRunIds.add(state.runId);
			latestRunId = state.runId;
			if (!sessionActive) return;
			try {
				pi.appendEntry(STATE_ENTRY_TYPE, state);
			} catch {
				// A session replacement invalidates the old ExtensionAPI. Disk artifacts remain authoritative.
			}
		},
	});
	const dynamicWorkflow = new DynamicWorkflowEngine({
		projectRoot: PROJECT_ROOT,
		runner: new PiDynamicAgentRunner({ projectRoot: PROJECT_ROOT }),
	});
	const publishDynamicResult = (entry: DynamicWorkflowResultEntryData): void => {
		pi.appendEntry(DYNAMIC_WORKFLOW_RESULT_ENTRY_TYPE, entry);
	};

	function configureRunner(ctx: ExtensionCommandContext): void {
		const model = ctx.model ? `${ctx.model.provider}/${ctx.model.id}` : undefined;
		runner.configure({ model, thinkingLevel: ctx.thinkingLevel });
	}

	function requireBranchRun(runId: string): void {
		if (!branchRunIds.has(runId)) {
			throw new Error(`Run ${runId} is not present on the active Pi session branch`);
		}
	}

	pi.on("resources_discover", () => ({
		skillPaths: [join(PROJECT_ROOT, "skills", "evidence-gated-change")],
	}));

	pi.on("session_start", (_event, ctx) => {
		sessionActive = true;
		branchRunIds.clear();
		latestRunId = undefined;
		let latestUpdatedAt = "";
		for (const entry of ctx.sessionManager.getBranch()) {
			if (entry.type !== "custom" || entry.customType !== STATE_ENTRY_TYPE || !isWorkflowState(entry.data)) continue;
			branchRunIds.add(entry.data.runId);
			if (entry.data.updatedAt >= latestUpdatedAt) {
				latestUpdatedAt = entry.data.updatedAt;
				latestRunId = entry.data.runId;
			}
		}
	});

	pi.on("session_shutdown", async () => {
		sessionActive = false;
		await Promise.all([workflow.abortAll(), dynamicWorkflow.abortAll()]);
	});

	pi.registerCommand("egc-start", {
		description: "Start fixed TodoService discovery and produce a hash-bound plan",
		handler: async (args, ctx) => {
			if (args.trim()) throw new Error("/egc-start does not accept a target path; it always uses the fixed fixture");
			await ctx.waitForIdle();
			configureRunner(ctx);
			ctx.ui.notify("EGC: parallel discovery and planning started", "info");
			const state = await workflow.start();
			ctx.ui.notify(displayState(state), state.phase === "awaiting_approval" ? "info" : "error");
		},
	});

	pi.registerCommand("egc-status", {
		description: "Show the active-branch EGC run state",
		handler: async (args, ctx) => {
			const [explicitRunId] = parseTokens(args);
			const runId = explicitRunId ?? latestRunId;
			if (!runId) throw new Error("No Evidence-Gated Change run exists on this session branch");
			if (!explicitRunId) requireBranchRun(runId);
			const state = await workflow.status(runId);
			ctx.ui.notify(displayState(state), state.phase === "blocked" ? "error" : "info");
		},
	});

	pi.registerCommand("egc-approve", {
		description: "Approve an EGC run by its plan/baseline/contract/runtime binding hash",
		handler: async (args, ctx) => {
			const [runId, approvalHash, ...extra] = parseTokens(args);
			if (!runId || !approvalHash || extra.length > 0) throw new Error("Usage: /egc-approve <runId> <approvalHash>");
			requireBranchRun(runId);
			await ctx.waitForIdle();
			configureRunner(ctx);
			ctx.ui.notify("EGC: approval accepted; isolated implementation started", "info");
			const state = await workflow.approve(runId, approvalHash);
			ctx.ui.notify(displayState(state), state.phase === "completed" ? "info" : "error");
		},
	});

	pi.registerCommand("egc-reject", {
		description: "Reject an EGC run by exact approval binding hash",
		handler: async (args, ctx) => {
			const [runId, approvalHash, ...reasonParts] = parseTokens(args);
			if (!runId || !approvalHash) throw new Error("Usage: /egc-reject <runId> <approvalHash> [reason]");
			requireBranchRun(runId);
			const state = await workflow.reject(runId, approvalHash, reasonParts.join(" "));
			ctx.ui.notify(displayState(state), "warning");
		},
	});

	pi.registerCommand("egc-resume", {
		description: "Resume a non-terminal EGC run from its last settled state",
		handler: async (args, ctx) => {
			const [runId, ...extra] = parseTokens(args);
			if (!runId || extra.length > 0) throw new Error("Usage: /egc-resume <runId>");
			requireBranchRun(runId);
			await ctx.waitForIdle();
			configureRunner(ctx);
			const state = await workflow.resume(runId);
			ctx.ui.notify(displayState(state), state.phase === "blocked" ? "error" : "info");
		},
	});

	pi.registerCommand("egc-cancel", {
		description: "Request cancellation of an active or interrupted EGC run",
		handler: async (args, ctx) => {
			const [runId, ...extra] = parseTokens(args);
			if (!runId || extra.length > 0) throw new Error("Usage: /egc-cancel <runId>");
			requireBranchRun(runId);
			const state = await workflow.cancel(runId);
			ctx.ui.notify(`Cancellation requested\n${displayState(state)}`, "warning");
		},
	});

	pi.registerCommand("dw-run", {
		description: "Run a saved Dynamic Workflow in the foreground with live progress: /dw-run <workflow> <task...>",
		handler: async (args, ctx) => {
			const [workflowId, ...taskParts] = parseTokens(args);
			if (!workflowId || taskParts.length === 0) throw new Error("Usage: /dw-run <workflow> <task...>");
			await ctx.waitForIdle();
			await runDynamicWorkflowForeground({
				engine: dynamicWorkflow,
				ctx,
				workflowId,
				task: taskParts.join(" "),
				cwd: ctx.cwd,
				parent: dynamicParentModel(ctx),
				projectRoot: PROJECT_ROOT,
				publishResult: publishDynamicResult,
			});
		},
	});

	pi.registerCommand("dw-result", {
		description: "Re-display the latest or selected completed Dynamic Workflow result without calling a model",
		handler: async (args, ctx) => {
			const [runId, ...extra] = parseTokens(args);
			if (extra.length > 0) throw new Error("Usage: /dw-result [runId]");
			await displayStoredDynamicWorkflowResult({
				engine: dynamicWorkflow,
				ctx,
				...(runId ? { runId } : {}),
				projectRoot: PROJECT_ROOT,
				publishResult: publishDynamicResult,
			});
		},
	});

	pi.registerCommand("dw-status", {
		description: "Show the latest or selected Dynamic Workflow run",
		handler: async (args, ctx) => {
			const [runId, ...extra] = parseTokens(args);
			if (extra.length > 0) throw new Error("Usage: /dw-status [runId]");
			const state = await dynamicWorkflow.status(runId);
			ctx.ui.notify(displayDynamicState(state, PROJECT_ROOT), state.status === "failed" ? "error" : "info");
		},
	});

	pi.registerCommand("dw-list", {
		description: "List saved Dynamic Workflows",
		handler: async (args, ctx) => {
			if (args.trim()) throw new Error("Usage: /dw-list");
			const workflows = await dynamicWorkflow.list();
			ctx.ui.notify(workflows.map((entry) => `${entry.name}: ${entry.description}`).join("\n") || "No saved workflows", "info");
		},
	});

	pi.registerCommand("dw-cancel", {
		description: "Cancel an active Dynamic Workflow in this Pi process",
		handler: async (args, ctx) => {
			const [runId, ...extra] = parseTokens(args);
			if (!runId || extra.length > 0) throw new Error("Usage: /dw-cancel <runId>");
			const state = await dynamicWorkflow.cancel(runId);
			ctx.ui.notify(displayDynamicState(state, PROJECT_ROOT), "warning");
		},
	});

	pi.registerCommand("dw-models", {
		description: "Show effective Dynamic Workflow model profiles",
		handler: async (args, ctx) => {
			if (args.trim()) throw new Error("Usage: /dw-models");
			const models = await dynamicWorkflow.models(dynamicParentModel(ctx));
			const lines = Object.entries(models).map(([name, model]) =>
				"inherit" in model
					? `${name}=inherit (no active parent model)`
					: `${name}=${model.provider}/${model.model}${model.thinking ? ` thinking=${model.thinking}` : ""}`,
			);
			ctx.ui.notify(lines.join("\n"), "info");
		},
	});
}
