export const PHASES = [
	"created",
	"baseline_captured",
	"discovering",
	"planning",
	"awaiting_approval",
	"implementing",
	"reviewing_verifying",
	"completed",
	"blocked",
	"rejected",
	"cancelled",
] as const;

export type Phase = (typeof PHASES)[number];

export const AGENT_ROLES = ["code-scout", "test-scout", "planner", "implementer", "repair", "reviewer"] as const;
export type AgentRole = (typeof AGENT_ROLES)[number];

export interface PendingOperation {
	id: string;
	name: string;
	phase: Phase;
	startedAt: string;
}

export interface WorkflowState {
	schemaVersion: 1;
	runId: string;
	phase: Phase;
	createdAt: string;
	updatedAt: string;
	baselineHash?: string;
	contractHash: string;
	runtimeHash: string;
	planHash?: string;
	approvalHash?: string;
	repairCount: number;
	maxRepair: 1;
	pendingOperation?: PendingOperation;
	lastError?: string;
	terminalReason?: string;
}

export interface WorkflowEvent {
	schemaVersion: 1;
	sequence: number;
	timestamp: string;
	runId: string;
	kind: "state" | "intent" | "settled" | "agent" | "gate";
	phase: Phase;
	operationId?: string;
	name: string;
	status?: "ok" | "error" | "cancelled";
	details?: Record<string, unknown>;
}

export interface AgentTask {
	role: AgentRole;
	prompt: string;
	cwd: string;
	tools: string[];
	timeoutMs?: number;
}

export interface AgentRunResult {
	role: AgentRole;
	exitCode: number;
	output: string;
	stderr: string;
	stopReason?: string;
}

export interface AgentRunner {
	run(task: AgentTask, signal: AbortSignal): Promise<AgentRunResult>;
}

export interface DiscoveryArtifact {
	summary: string;
	files: Array<{ path: string; reason: string }>;
	risks: string[];
}

export interface PlanArtifact {
	summary: string;
	files: string[];
	steps: string[];
	tests: string[];
	risks: string[];
}

export interface ReviewArtifact {
	verdict: "pass" | "fail";
	summary: string;
	findings: Array<{ severity: "blocker" | "warning" | "note"; message: string; path?: string }>;
}

export interface VerificationCommandReceipt {
	command: string;
	args: string[];
	exitCode: number;
	stdout: string;
	stderr: string;
	durationMs: number;
}

export interface VerificationArtifact {
	passed: boolean;
	commands: VerificationCommandReceipt[];
	changedFiles: string[];
	allowedFiles: string[];
	policyViolations: string[];
	baselineHashUnchanged: boolean;
}

export interface ApprovalArtifact {
	runId: string;
	planHash: string;
	baselineHash: string;
	contractHash: string;
	runtimeHash: string;
	approvalHash: string;
	decision: "approved" | "rejected";
	decidedAt: string;
	reason?: string;
}

export interface RunPaths {
	runDir: string;
	baselineDir: string;
	worktreeDir: string;
	eventsFile: string;
	stateFile: string;
}

export interface WorkflowOptions {
	projectRoot: string;
	runner: AgentRunner;
	onSnapshot?: (state: WorkflowState) => void;
	now?: () => Date;
	idFactory?: () => string;
}
