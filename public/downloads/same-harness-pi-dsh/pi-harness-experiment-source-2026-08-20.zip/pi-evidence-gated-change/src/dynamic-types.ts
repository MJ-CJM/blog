export type DynamicJson = null | boolean | number | string | DynamicJson[] | { [key: string]: DynamicJson };

export const DYNAMIC_THINKING_LEVELS = ["off", "minimal", "low", "medium", "high", "xhigh", "max"] as const;
export type DynamicThinkingLevel = (typeof DYNAMIC_THINKING_LEVELS)[number];

export interface DynamicWorkflowPhase {
	title: string;
	detail?: string;
	provider?: string;
	model?: string;
}

export interface DynamicWorkflowMeta {
	name: string;
	description: string;
	whenToUse?: string;
	phases?: DynamicWorkflowPhase[];
}

export interface ParsedDynamicWorkflow {
	meta: DynamicWorkflowMeta;
	body: string;
	source: string;
	sourceHash: string;
	filePath: string;
}

export interface DynamicLimits {
	maxParallel: number;
	maxAgents: number;
	maxItemsPerCall: number;
	syncTimeoutMs: number;
	agentIdleTimeoutMs: number;
	agentTimeoutMs: number;
	runTimeoutMs: number;
	maxSourceBytes: number;
	maxResultBytes: number;
}

export interface DynamicModelProfile {
	provider?: string;
	model?: string;
	thinking?: DynamicThinkingLevel;
}

export interface DynamicConfig {
	schemaVersion: 1;
	limits: DynamicLimits;
	profiles: Record<string, DynamicModelProfile>;
}

export interface DynamicParentModel {
	provider: string;
	model: string;
	thinking?: DynamicThinkingLevel;
}

export interface ResolvedDynamicModel {
	provider: string;
	model: string;
	thinking?: DynamicThinkingLevel;
}

export interface DynamicAgentTask extends ResolvedDynamicModel {
	label: string;
	phase?: string;
	prompt: string;
	cwd: string;
	idleTimeoutMs?: number;
	timeoutMs: number;
}

export interface DynamicAgentResult {
	exitCode: number;
	output: unknown;
	stderr: string;
	stopReason?: string;
}

export interface DynamicAgentRetryProgress {
	type: "retry";
	attempt: number;
	maxAttempts: number;
	delayMs: number;
	diagnostic: string;
	hardQuota: boolean;
}

export type DynamicAgentProgress = DynamicAgentRetryProgress;

export type DynamicAgentProgressListener = (progress: DynamicAgentProgress) => void;

export interface DynamicAgentRunner {
	run(task: DynamicAgentTask, signal: AbortSignal, onProgress?: DynamicAgentProgressListener): Promise<DynamicAgentResult>;
}

export type DynamicRunStatus = "queued" | "running" | "completed" | "failed" | "cancelled";

export interface DynamicRunState {
	schemaVersion: 1;
	runId: string;
	workflow: string;
	workflowHash: string;
	status: DynamicRunStatus;
	task: string;
	cwd: string;
	createdAt: string;
	updatedAt: string;
	currentPhase?: string;
	agentsStarted: number;
	agentsCompleted: number;
	activeAgents: number;
	resultFile?: string;
	error?: string;
	failureCauses?: string[];
}

export interface DynamicEvent {
	schemaVersion: 1;
	sequence: number;
	timestamp: string;
	runId: string;
	type: "state" | "phase" | "log" | "agent-start" | "agent-retry" | "agent-end";
	message: string;
	details?: Record<string, DynamicJson>;
}

export interface DynamicRunProgress {
	state: DynamicRunState;
	event?: DynamicEvent;
}

export type DynamicRunProgressListener = (progress: DynamicRunProgress) => void;

export interface DynamicStartOptions {
	onProgress?: DynamicRunProgressListener;
}
