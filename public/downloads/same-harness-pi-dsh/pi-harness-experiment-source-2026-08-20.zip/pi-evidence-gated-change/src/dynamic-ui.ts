import { join } from "node:path";
import type { ExtensionCommandContext } from "@earendil-works/pi-coding-agent";
import { sanitizeDynamicDiagnostic } from "./dynamic-diagnostics.ts";
import { DynamicWorkflowEngine } from "./dynamic-engine.ts";
import {
	createDynamicWorkflowResultEntry,
	formatDynamicWorkflowResultEntry,
	type DynamicWorkflowResultEntryData,
} from "./dynamic-result.ts";
import type { DynamicParentModel, DynamicRunProgress, DynamicRunState } from "./dynamic-types.ts";

const STATUS_KEY = "dynamic-workflow";
const WIDGET_KEY = "dynamic-workflow-progress";
const RECENT_AGENT_EVENTS = 5;

function safeUi(operation: () => void): void {
	try {
		operation();
	} catch {
		// A non-interactive host may intentionally implement only part of the UI surface.
	}
}

function compactLine(value: string, maxLength = 220): string {
	const line = sanitizeDynamicDiagnostic(value, maxLength * 4).replace(/\s+/g, " ").trim();
	return line.length <= maxLength ? line : `${line.slice(0, maxLength - 1)}…`;
}

function formatAgentEvent(progress: DynamicRunProgress): string | undefined {
	const event = progress.event;
	if (!event || !["agent-start", "agent-retry", "agent-end"].includes(event.type)) return undefined;
	if (event.type === "agent-start") {
		const provider = typeof event.details?.provider === "string" ? compactLine(event.details.provider, 80) : "unknown-provider";
		const model = typeof event.details?.model === "string" ? compactLine(event.details.model, 80) : "unknown-model";
		return `→ ${event.message} (${provider}/${model})`;
	}
	if (event.type === "agent-retry") {
		const delayMs = typeof event.details?.delayMs === "number" ? event.details.delayMs : 0;
		const diagnostic = typeof event.details?.diagnostic === "string" ? compactLine(event.details.diagnostic) : "retryable provider error";
		const hardQuota = event.details?.hardQuota === true ? " · hard quota, stopping child" : "";
		return `↻ ${event.message} · wait ${Math.ceil(delayMs / 1_000)}s${hardQuota} — ${diagnostic}`;
	}
	const error = typeof event.details?.error === "string" ? compactLine(event.details.error) : undefined;
	return `${error ? "✗" : "✓"} ${event.message}${error ? ` — ${error}` : ""}`;
}

export function displayDynamicState(state: DynamicRunState, projectRoot: string): string {
	return [
		`run=${state.runId}`,
		`workflow=${compactLine(state.workflow)}`,
		`status=${state.status}`,
		`phase=${state.currentPhase ? compactLine(state.currentPhase) : "not-started"}`,
		`agents successful=${state.agentsCompleted}/${state.agentsStarted} active=${state.activeAgents}`,
		`artifacts=${join(projectRoot, "dynamic-workflow", "runs", state.runId)}`,
		...(state.error ? [`error=${sanitizeDynamicDiagnostic(state.error)}`] : []),
		...(state.failureCauses?.length ? ["rootCauses:", ...state.failureCauses.map((cause) => `- ${sanitizeDynamicDiagnostic(cause)}`)] : []),
	].join("\n");
}

export type DynamicWorkflowResultPublisher = (entry: DynamicWorkflowResultEntryData) => void | Promise<void>;

interface PublishDynamicWorkflowResultOptions {
	state: DynamicRunState;
	value: Awaited<ReturnType<DynamicWorkflowEngine["result"]>>;
	projectRoot: string;
	publishResult: DynamicWorkflowResultPublisher;
	ctx: ExtensionCommandContext;
}

async function publishDynamicWorkflowResult(options: PublishDynamicWorkflowResultOptions): Promise<DynamicWorkflowResultEntryData> {
	const { state, value, projectRoot, publishResult, ctx } = options;
	const resultPath = join(projectRoot, "dynamic-workflow", "runs", state.runId, state.resultFile ?? "result.json");
	const entry = createDynamicWorkflowResultEntry(state, value, resultPath);
	try {
		await publishResult(entry);
		if (ctx.mode === "rpc") {
			safeUi(() => ctx.ui.notify(formatDynamicWorkflowResultEntry(entry), "info"));
		}
	} catch (error) {
		const cause = sanitizeDynamicDiagnostic(error instanceof Error ? error.message : String(error));
		safeUi(() =>
			ctx.ui.notify(
				`Dynamic Workflow completed, but its persistent result card could not be appended (${cause}).\n\n${formatDynamicWorkflowResultEntry(entry)}`,
				"warning",
			),
		);
	}
	return entry;
}

export async function displayStoredDynamicWorkflowResult(options: {
	engine: DynamicWorkflowEngine;
	ctx: ExtensionCommandContext;
	runId?: string;
	projectRoot: string;
	publishResult: DynamicWorkflowResultPublisher;
}): Promise<DynamicWorkflowResultEntryData> {
	const stored = await options.engine.completedResult(options.runId);
	return await publishDynamicWorkflowResult({
		state: stored.state,
		value: stored.value,
		projectRoot: options.projectRoot,
		publishResult: options.publishResult,
		ctx: options.ctx,
	});
}

interface ForegroundDynamicWorkflowOptions {
	engine: DynamicWorkflowEngine;
	ctx: ExtensionCommandContext;
	workflowId: string;
	task: string;
	cwd: string;
	parent: DynamicParentModel | undefined;
	projectRoot: string;
	publishResult: DynamicWorkflowResultPublisher;
}

export async function runDynamicWorkflowForeground(options: ForegroundDynamicWorkflowOptions): Promise<DynamicRunState | undefined> {
	const { engine, ctx, workflowId, task, cwd, parent, projectRoot, publishResult } = options;
	const liveUi = ctx.mode === "tui" || ctx.mode === "rpc";
	if (!liveUi) {
		throw new Error(`/dw-run foreground execution requires Pi TUI or RPC mode; current mode is ${ctx.mode}`);
	}
	const recent: string[] = [];
	const failedAgents = new Set<string>();
	let activeRunId: string | undefined;
	let cancellationRequested = false;
	let cancellationStarted = false;
	let unsubscribeTerminalInput = (): void => undefined;
	const cancelActiveRun = (): void => {
		if (!activeRunId || cancellationStarted) return;
		cancellationStarted = true;
		void engine.cancel(activeRunId).catch((error: unknown) => {
			ctx.ui.notify(
				`Dynamic Workflow cancellation failed\n${sanitizeDynamicDiagnostic(error instanceof Error ? error.message : String(error))}`,
				"error",
			);
		});
	};

	const render = (progress: DynamicRunProgress): void => {
		if (!liveUi) return;
		const agentEvent = formatAgentEvent(progress);
		if (agentEvent) {
			if (progress.event?.type === "agent-end" && typeof progress.event.details?.error === "string") {
				failedAgents.add(progress.event.message.replace(/:\s*failed$/, ""));
			}
			recent.push(agentEvent);
			if (recent.length > RECENT_AGENT_EVENTS) recent.shift();
		}
		const state = progress.state;
		const phase = state.currentPhase ? compactLine(state.currentPhase) : "starting";
		const summary = `${phase} · successful ${state.agentsCompleted}/${state.agentsStarted} · failed ${failedAgents.size} · active ${state.activeAgents}`;
		safeUi(() => ctx.ui.setWorkingMessage(`Dynamic Workflow · ${summary}`));
		safeUi(() => ctx.ui.setStatus(STATUS_KEY, `DW ${state.status} · ok ${state.agentsCompleted} · failed ${failedAgents.size} · ${phase}`));
		safeUi(() =>
			ctx.ui.setWidget(
				WIDGET_KEY,
				[
					`Dynamic Workflow: ${compactLine(state.workflow)}`,
					`run=${state.runId}`,
					`status=${state.status}  phase=${phase}`,
					`agents started=${state.agentsStarted}  successful=${state.agentsCompleted}  failed=${failedAgents.size}  active=${state.activeAgents}`,
					...(ctx.mode === "tui" ? ["press Esc to cancel this foreground run"] : []),
					...(recent.length ? ["recent Agent events:", ...recent.map((entry) => `  ${entry}`)] : []),
				],
				{ placement: "aboveEditor" },
			),
		);
	};

	if (liveUi) {
		safeUi(() => ctx.ui.setWorkingMessage("Dynamic Workflow · starting"));
		safeUi(() => ctx.ui.setStatus(STATUS_KEY, "DW starting"));
		safeUi(() =>
			ctx.ui.setWidget(
				WIDGET_KEY,
				[`Dynamic Workflow: ${compactLine(workflowId)}`, "status=starting", ...(ctx.mode === "tui" ? ["press Esc to cancel this foreground run"] : [])],
				{ placement: "aboveEditor" },
			),
		);
		if (ctx.mode === "tui") {
			safeUi(() => {
				unsubscribeTerminalInput = ctx.ui.onTerminalInput((data) => {
					if (data !== "\x1b" || cancellationRequested) return;
					cancellationRequested = true;
					safeUi(() => ctx.ui.setWorkingMessage("Dynamic Workflow · cancellation requested"));
					cancelActiveRun();
					return { consume: true };
				});
			});
		}
	}

	try {
		const started = await engine.start(workflowId, task, cwd, parent, { onProgress: render });
		activeRunId = started.runId;
		if (cancellationRequested) cancelActiveRun();
		const terminal = await engine.wait(started.runId);
		render({ state: terminal });
		if (terminal.status === "completed") {
			const result = await engine.result(terminal.runId);
			await publishDynamicWorkflowResult({ state: terminal, value: result, projectRoot, publishResult, ctx });
		} else {
			ctx.ui.notify(displayDynamicState(terminal, projectRoot), terminal.status === "cancelled" ? "warning" : "error");
		}
		return terminal;
	} catch (error) {
		ctx.ui.notify(
			`Dynamic Workflow could not start or read its result\n${sanitizeDynamicDiagnostic(error instanceof Error ? error.message : String(error))}`,
			"error",
		);
		return undefined;
	} finally {
		safeUi(unsubscribeTerminalInput);
		if (liveUi) {
			safeUi(() => ctx.ui.setWidget(WIDGET_KEY, undefined));
			safeUi(() => ctx.ui.setStatus(STATUS_KEY, undefined));
			safeUi(() => ctx.ui.setWorkingMessage());
		}
	}
}
