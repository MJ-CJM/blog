import { execFile } from "node:child_process";
import { realpath, writeFile } from "node:fs/promises";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { promisify } from "node:util";
import { assertInside, changedFiles, hashTree } from "./artifacts.ts";
import type { VerificationArtifact, VerificationCommandReceipt } from "./types.ts";

const execFileAsync = promisify(execFile);
const VERIFIER_ROOT = resolve(dirname(fileURLToPath(import.meta.url)), "..");
export const VERIFIER_PROCESS_LIMITS = { timeoutMs: 30_000, killSignal: "SIGKILL" } as const;

async function runCommand(command: string, args: string[], cwd: string, signal: AbortSignal): Promise<VerificationCommandReceipt> {
	const started = Date.now();
	try {
		const result = await execFileAsync(command, args, {
			cwd,
			timeout: VERIFIER_PROCESS_LIMITS.timeoutMs,
			killSignal: VERIFIER_PROCESS_LIMITS.killSignal,
			maxBuffer: 2 * 1024 * 1024,
			env: { LANG: "C", LC_ALL: "C", NODE_OPTIONS: "", PATH: "" },
			signal,
		});
		return {
			command,
			args,
			exitCode: 0,
			stdout: result.stdout,
			stderr: result.stderr,
			durationMs: Date.now() - started,
		};
	} catch (error) {
		const candidate = error as { code?: number | string; stdout?: string; stderr?: string; message?: string };
		return {
			command,
			args,
			exitCode: typeof candidate.code === "number" ? candidate.code : 1,
			stdout: candidate.stdout ?? "",
			stderr: candidate.stderr ?? candidate.message ?? String(error),
			durationMs: Date.now() - started,
		};
	}
}

function permissionArguments(readPaths: string[]): string[] | null {
	const requiredScopes = [
		"--permission",
		"--allow-fs-read",
		"--allow-fs-write",
		"--allow-child-process",
		"--allow-net",
		"--allow-worker",
	];
	if (requiredScopes.some((flag) => !process.allowedNodeEnvironmentFlags.has(flag))) return null;
	return ["--permission", ...readPaths.map((path) => `--allow-fs-read=${resolve(path)}`)];
}

export async function verifyWorktree(options: {
	projectRoot: string;
	baselineDir: string;
	worktreeDir: string;
	baselineHash: string;
	allowedFiles: string[];
	signal: AbortSignal;
}): Promise<VerificationArtifact> {
	// Node's permission model compares canonical paths. macOS exposes /var as a
	// symlink to /private/var, so lexical temp paths would otherwise be denied
	// after the module loader resolves them through the symlink.
	const projectRoot = await realpath(options.projectRoot);
	const baselineDir = await realpath(options.baselineDir);
	const worktreeDir = await realpath(options.worktreeDir);
	const runsRoot = resolve(projectRoot, "runs");
	assertInside(runsRoot, baselineDir, "baseline directory");
	assertInside(runsRoot, worktreeDir, "worktree directory");
	const files = await changedFiles(baselineDir, worktreeDir);
	const allowed = [...new Set(options.allowedFiles)].sort();
	const policyViolations = files.filter((file) => !allowed.includes(file)).map((file) => `Changed file is not approved: ${file}`);
	for (const file of allowed) {
		if (!files.includes(file)) policyViolations.push(`Approved file was not changed: ${file}`);
	}
	const baselineHashUnchanged = (await hashTree(baselineDir)) === options.baselineHash;
	if (!baselineHashUnchanged) policyViolations.push("Immutable baseline tree changed after approval");
	const permissions = permissionArguments([worktreeDir]);
	if (!permissions) {
		const unsupported: VerificationCommandReceipt = {
			command: process.execPath,
			args: ["--permission"],
			exitCode: 1,
			stdout: "",
			stderr: "Required Node permission scopes are unavailable; refusing to execute agent-modified code without confinement",
			durationMs: 0,
		};
		return {
			passed: false,
			commands: [unsupported],
			changedFiles: files,
			allowedFiles: allowed,
			policyViolations: [...policyViolations, "Node permission model with filesystem, child-process, network, and worker scopes is required"],
			baselineHashUnchanged,
		};
	}

	const projectTests = await runCommand(
		process.execPath,
		[...permissions, "--experimental-strip-types", "test/TodoService.test.ts"],
		worktreeDir,
		options.signal,
	);
	const oraclePath = await realpath(resolve(projectRoot, "scripts", "verify-fixture.mjs"));
	const oraclePermissions = permissionArguments([oraclePath, worktreeDir]);
	if (!oraclePermissions) throw new Error("Node permission model disappeared during verification");
	const oracle = await runCommand(
		process.execPath,
		[...oraclePermissions, oraclePath, worktreeDir],
		projectRoot,
		options.signal,
	);
	const runDir = dirname(worktreeDir);
	const typecheckProbe = resolve(runDir, "typecheck-request-id.ts");
	assertInside(runDir, typecheckProbe, "typecheck probe");
	await writeFile(
		typecheckProbe,
		[
			'import { TodoService } from "./worktree/src/TodoService.ts";',
			"const service = new TodoService();",
			'// @ts-expect-error requestId is required by the public input type',
			'service.createTask({ title: "missing request id" });',
			'service.createTask({ title: "valid", requestId: "typecheck-1" });',
			"",
		].join("\n"),
		{ encoding: "utf8", mode: 0o600 },
	);
	const typeScriptBin = resolve(VERIFIER_ROOT, "node_modules", "typescript", "bin", "tsc");
	const typecheckPermissions = permissionArguments([VERIFIER_ROOT, runDir]);
	if (!typecheckPermissions) throw new Error("Node permission model disappeared during typecheck");
	const typecheck = await runCommand(
		process.execPath,
		[
			...typecheckPermissions,
			typeScriptBin,
			"--noEmit",
			"--allowImportingTsExtensions",
			"--module",
			"NodeNext",
			"--moduleResolution",
			"NodeNext",
			"--target",
			"ES2023",
			"--strict",
			"--skipLibCheck",
			typecheckProbe,
		],
		runDir,
		options.signal,
	);
	const commands = [projectTests, oracle, typecheck];
	return {
		passed: commands.every((receipt) => receipt.exitCode === 0) && policyViolations.length === 0 && files.length > 0,
		commands,
		changedFiles: files,
		allowedFiles: allowed,
		policyViolations,
		baselineHashUnchanged,
	};
}
