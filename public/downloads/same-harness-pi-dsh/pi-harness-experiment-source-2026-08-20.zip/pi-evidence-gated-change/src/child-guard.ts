import { existsSync, realpathSync } from "node:fs";
import { dirname, resolve, sep } from "node:path";
import type { ExtensionAPI } from "@earendil-works/pi-coding-agent";

function inside(root: string, target: string): boolean {
	return target === root || target.startsWith(root.endsWith(sep) ? root : `${root}${sep}`);
}

function nearestExisting(path: string): string {
	let current = path;
	while (!existsSync(current)) {
		const parent = dirname(current);
		if (parent === current) return current;
		current = parent;
	}
	return current;
}

function safePath(cwd: string, raw: unknown): boolean {
	if (raw === undefined) return true;
	if (typeof raw !== "string" || raw.includes("\0")) return false;
	const normalized = raw.startsWith("@") ? raw.slice(1) : raw;
	const root = realpathSync(cwd);
	const target = resolve(cwd, normalized || ".");
	if (!inside(root, target)) return false;
	const existing = nearestExisting(target);
	return inside(root, realpathSync(existing));
}

export default function childGuard(pi: ExtensionAPI): void {
	pi.on("tool_call", (event, ctx) => {
		if (event.toolName === "bash") {
			return { block: true, reason: "Evidence workflow child agents cannot execute shell commands", terminate: true };
		}
		if (!["read", "write", "edit", "grep", "find", "ls"].includes(event.toolName)) return;
		const input = event.input as Record<string, unknown>;
		const candidate = input.path ?? input.file_path;
		if (!safePath(ctx.cwd, candidate)) {
			return {
				block: true,
				reason: `Evidence workflow blocks paths outside the isolated worktree: ${String(candidate)}`,
				terminate: true,
			};
		}
	});
}
