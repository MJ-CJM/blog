import { type MessagePort, parentPort, workerData } from "node:worker_threads";
import { Script, createContext } from "node:vm";
import type { DynamicJson, DynamicWorkflowMeta } from "./dynamic-types.ts";

interface WorkerInit {
	body: string;
	meta: DynamicWorkflowMeta;
	args: DynamicJson;
	syncTimeoutMs: number;
	maxItemsPerCall: number;
	maxResultBytes: number;
}

interface AgentReply {
	type: "agent-result";
	id: number;
	ok: boolean;
	value?: DynamicJson;
	error?: string;
}

class WorkerFatalError extends Error {}

function requireParentPort(): MessagePort {
	if (!parentPort) throw new Error("Dynamic Workflow worker requires a parent port");
	return parentPort;
}

const port = requireParentPort();
const init = workerData as WorkerInit;
let nextAgentId = 0;
const pending = new Map<number, { resolve: (value: DynamicJson) => void; reject: (error: Error) => void }>();

function materialize(value: unknown, label: string): DynamicJson {
	const visit = (candidate: unknown, path: string): void => {
		if (candidate === null || typeof candidate === "string" || typeof candidate === "boolean") return;
		if (typeof candidate === "number") {
			if (!Number.isFinite(candidate)) throw new WorkerFatalError(`${path} contains a non-finite number`);
			return;
		}
		if (Array.isArray(candidate)) {
			for (let index = 0; index < candidate.length; index++) visit(candidate[index], `${path}[${index}]`);
			return;
		}
		if (typeof candidate !== "object" || Object.prototype.toString.call(candidate) !== "[object Object]") {
			throw new WorkerFatalError(`${path} is not plain JSON data`);
		}
		for (const key of Reflect.ownKeys(candidate)) {
			if (typeof key !== "string") throw new WorkerFatalError(`${path} contains a symbol key`);
			const descriptor = Object.getOwnPropertyDescriptor(candidate, key);
			if (!descriptor?.enumerable || !("value" in descriptor)) throw new WorkerFatalError(`${path}.${key} is not a plain JSON property`);
			visit(descriptor.value, `${path}.${key}`);
		}
	};
	visit(value, label);
	const serialized = JSON.stringify(value);
	if (serialized === undefined) throw new WorkerFatalError(`${label} cannot be undefined`);
	if (Buffer.byteLength(serialized) > init.maxResultBytes) throw new WorkerFatalError(`${label} exceeds ${init.maxResultBytes} bytes`);
	return JSON.parse(serialized) as DynamicJson;
}

port.on("message", (message: AgentReply) => {
	if (message.type !== "agent-result") return;
	const request = pending.get(message.id);
	if (!request) return;
	pending.delete(message.id);
	if (message.ok && message.value !== undefined) request.resolve(message.value);
	else request.reject(new WorkerFatalError(message.error ?? "Dynamic agent request failed"));
});

async function run(): Promise<void> {
	const phaseTitles = new Set((init.meta.phases ?? []).map((phase) => phase.title));
	const agent = (prompt: unknown, options?: unknown): Promise<DynamicJson> => {
		if (typeof prompt !== "string" || !prompt.trim()) throw new WorkerFatalError("agent prompt must be a non-empty string");
		const materializedOptions = options === undefined ? null : materialize(options, "agent options");
		const id = ++nextAgentId;
		return new Promise<DynamicJson>((resolvePromise, rejectPromise) => {
			pending.set(id, { resolve: resolvePromise, reject: rejectPromise });
			port.postMessage({ type: "agent", id, prompt, options: materializedOptions });
		});
	};
	const parallel = async (thunks: unknown): Promise<DynamicJson[]> => {
		if (!Array.isArray(thunks)) throw new WorkerFatalError("parallel() requires an array of zero-argument functions");
		if (thunks.length > init.maxItemsPerCall) throw new WorkerFatalError("parallel() item cap exceeded");
		return await Promise.all(
			thunks.map(async (thunk) => {
				if (typeof thunk !== "function") throw new WorkerFatalError("parallel() items must be functions");
				try {
					return materialize(await (thunk as () => unknown)(), "parallel result");
				} catch (error) {
					if (error instanceof WorkerFatalError) throw error;
					return null;
				}
			}),
		);
	};
	const pipeline = async (rawItems: unknown, ...stages: unknown[]): Promise<DynamicJson[]> => {
		const items = materialize(rawItems, "pipeline items");
		if (!Array.isArray(items)) throw new WorkerFatalError("pipeline() requires an items array");
		if (items.length > init.maxItemsPerCall) throw new WorkerFatalError("pipeline() item cap exceeded");
		if (stages.length === 0 || stages.some((stage) => typeof stage !== "function")) throw new WorkerFatalError("pipeline() requires stage functions");
		return await Promise.all(
			items.map(async (item, index) => {
				let value: unknown = item;
				try {
					for (const stage of stages) value = await (stage as (value: unknown, item: DynamicJson, index: number) => unknown)(value, item, index);
					return materialize(value, "pipeline result");
				} catch (error) {
					if (error instanceof WorkerFatalError) throw error;
					return null;
				}
			}),
		);
	};
	const phase = (title: unknown): void => {
		if (typeof title !== "string" || !title) throw new WorkerFatalError("phase() requires a non-empty string");
		if (phaseTitles.size > 0 && !phaseTitles.has(title)) throw new WorkerFatalError(`Unknown phase: ${title}`);
		port.postMessage({ type: "phase", title });
	};
	const log = (message: unknown): void => {
		if (typeof message !== "string") throw new WorkerFatalError("log() requires a string");
		port.postMessage({ type: "log", message });
	};
	const sandbox: Record<string, unknown> = Object.create(null) as Record<string, unknown>;
	Object.assign(sandbox, {
		agent: Object.freeze(agent),
		parallel: Object.freeze(parallel),
		pipeline: Object.freeze(pipeline),
		phase: Object.freeze(phase),
		log: Object.freeze(log),
		args: init.args,
	});
	const context = createContext(sandbox, {
		name: `dynamic-workflow:${init.meta.name}`,
		codeGeneration: { strings: false, wasm: false },
	});
	const compiled = new Script(`(async () => {\n${init.body}\n})()`, {
		filename: `workflow:${init.meta.name}`,
		lineOffset: -1,
	});
	const value = await Promise.resolve(compiled.runInContext(context, { timeout: init.syncTimeoutMs }) as unknown);
	port.postMessage({ type: "completed", value: materialize(value, "workflow result"), agentsStarted: nextAgentId });
}

void run().catch((error: unknown) => {
	port.postMessage({ type: "failed", error: error instanceof Error ? error.message : String(error), agentsStarted: nextAgentId });
});
