import type { DynamicJson } from "./dynamic-types.ts";

const MAX_DIAGNOSTIC_LINE = 600;
const MAX_SANITIZED_DIAGNOSTIC = 2_000;
const SENSITIVE_KEY = "authorization|api[_-]?key|access[_-]?token|refresh[_-]?token|token|secret|password";
const SENSITIVE_KEY_PATTERN = new RegExp(`^(?:${SENSITIVE_KEY})$`, "i");

export function sanitizeDynamicDiagnostic(value: string, maxLength = MAX_SANITIZED_DIAGNOSTIC): string {
	const sanitized = value
		.replace(/\b(Bearer)\s+[^\s,"'}]+/gi, "$1 [REDACTED]")
		.replace(
			new RegExp(`(["']?(?:${SENSITIVE_KEY})["']?\\s*[=:]\\s*)(?:"(?:\\\\.|[^"\\\\])*"|'(?:\\\\.|[^'\\\\])*')`, "gi"),
			"$1[REDACTED]",
		)
		.replace(new RegExp(`(["']?(?:${SENSITIVE_KEY})["']?\\s*[=:]\\s*)[^,;\\r\\n}]+`, "gi"), "$1[REDACTED]")
		.replace(/\bsk-[A-Za-z0-9_-]{8,}\b/g, "[REDACTED]")
		.replace(/\bghp_[A-Za-z0-9]{8,}\b/g, "[REDACTED]")
		.replace(/\bgithub_pat_[A-Za-z0-9_]{8,}\b/g, "[REDACTED]")
		.replace(/\bAKIA[0-9A-Z]{16}\b/g, "[REDACTED]")
		.replace(/\b[A-Za-z0-9+/_=-]{80,}\b/g, "[REDACTED]");
	return sanitized.length <= maxLength
		? sanitized
		: `${sanitized.slice(0, Math.max(0, maxLength - 1))}…`;
}

export function sanitizeDynamicDiagnosticJson(value: DynamicJson): DynamicJson {
	if (typeof value === "string") return sanitizeDynamicDiagnostic(value);
	if (Array.isArray(value)) return value.map((entry) => sanitizeDynamicDiagnosticJson(entry));
	if (value && typeof value === "object") {
		return Object.fromEntries(
			Object.entries(value).map(([key, entry]) => [
				key,
				SENSITIVE_KEY_PATTERN.test(key) ? "[REDACTED]" : sanitizeDynamicDiagnosticJson(entry),
			]),
		);
	}
	return value;
}

export function isHardQuotaDiagnostic(value: string): boolean {
	const sanitized = sanitizeDynamicDiagnostic(value);
	const code1308 = /["']?code["']?\s*[:=]\s*["']?1308\b/i.test(sanitized);
	const rateLimited = /\b429\b/.test(sanitized);
	const quotaSemantics = /(?:使用上限|用量上限|额度(?:已)?用尽|usage\s+(?:limit|quota)|quota\s+(?:limit|exceeded|exhausted))/i.test(sanitized);
	return quotaSemantics && (code1308 || rateLimited);
}

export function summarizeDynamicAgentFailure(
	label: string,
	exitCode: number,
	stopReason: string | undefined,
	diagnostic: string,
): string {
	const uniqueLines: string[] = [];
	for (const rawLine of sanitizeDynamicDiagnostic(diagnostic).split(/\r?\n/)) {
		const line = rawLine.trim();
		if (!line || uniqueLines.includes(line)) continue;
		uniqueLines.push(line.length > MAX_DIAGNOSTIC_LINE ? `${line.slice(0, MAX_DIAGNOSTIC_LINE - 1)}…` : line);
		if (uniqueLines.length === 3) break;
	}
	const fallback = `exitCode=${exitCode}${stopReason ? ` stopReason=${stopReason}` : ""}`;
	return `${label}: ${uniqueLines.join(" | ") || fallback}`;
}
