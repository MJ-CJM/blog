import { createHash } from "node:crypto";
import type { DiscoveryArtifact, PlanArtifact, ReviewArtifact } from "./types.ts";

function normalize(value: unknown): unknown {
	if (Array.isArray(value)) return value.map(normalize);
	if (value && typeof value === "object") {
		return Object.fromEntries(
			Object.entries(value as Record<string, unknown>)
				.sort(([left], [right]) => left.localeCompare(right))
				.map(([key, nested]) => [key, normalize(nested)]),
		);
	}
	return value;
}

export function canonicalJson(value: unknown): string {
	return JSON.stringify(normalize(value));
}

export function sha256(value: string | Buffer): string {
	return createHash("sha256").update(value).digest("hex");
}

export function extractJson(text: string): unknown {
	const trimmed = text.trim();
	const fenced = /^```(?:json)?\s*([\s\S]*?)\s*```$/i.exec(trimmed);
	const candidate = fenced?.[1] ?? trimmed;
	try {
		return JSON.parse(candidate);
	} catch (error) {
		const message = error instanceof Error ? error.message : String(error);
		throw new Error(`Agent output is not a single JSON value: ${message}`);
	}
}

function requireRecord(value: unknown, label: string): Record<string, unknown> {
	if (!value || typeof value !== "object" || Array.isArray(value)) throw new Error(`${label} must be an object`);
	return value as Record<string, unknown>;
}

function requireString(value: unknown, label: string): string {
	if (typeof value !== "string" || value.trim() === "") throw new Error(`${label} must be a non-empty string`);
	return value;
}

function requireStringArray(value: unknown, label: string): string[] {
	if (!Array.isArray(value)) throw new Error(`${label} must be an array`);
	return value.map((item, index) => requireString(item, `${label}[${index}]`));
}

export function parseDiscovery(text: string): DiscoveryArtifact {
	const record = requireRecord(extractJson(text), "discovery");
	if (!Array.isArray(record.files)) throw new Error("discovery.files must be an array");
	return {
		summary: requireString(record.summary, "discovery.summary"),
		files: record.files.map((item, index) => {
			const file = requireRecord(item, `discovery.files[${index}]`);
			return {
				path: requireString(file.path, `discovery.files[${index}].path`),
				reason: requireString(file.reason, `discovery.files[${index}].reason`),
			};
		}),
		risks: requireStringArray(record.risks, "discovery.risks"),
	};
}

export function parsePlan(text: string): PlanArtifact {
	const record = requireRecord(extractJson(text), "plan");
	const files = requireStringArray(record.files, "plan.files");
	for (const file of files) {
		if (file.startsWith("/") || file.includes("..")) throw new Error(`plan.files contains unsafe path: ${file}`);
	}
	return {
		summary: requireString(record.summary, "plan.summary"),
		files,
		steps: requireStringArray(record.steps, "plan.steps"),
		tests: requireStringArray(record.tests, "plan.tests"),
		risks: requireStringArray(record.risks, "plan.risks"),
	};
}

export function parseReview(text: string): ReviewArtifact {
	const record = requireRecord(extractJson(text), "review");
	if (record.verdict !== "pass" && record.verdict !== "fail") throw new Error("review.verdict must be pass or fail");
	if (!Array.isArray(record.findings)) throw new Error("review.findings must be an array");
	return {
		verdict: record.verdict,
		summary: requireString(record.summary, "review.summary"),
		findings: record.findings.map((item, index) => {
			const finding = requireRecord(item, `review.findings[${index}]`);
			if (finding.severity !== "blocker" && finding.severity !== "warning" && finding.severity !== "note") {
				throw new Error(`review.findings[${index}].severity is invalid`);
			}
			const result: ReviewArtifact["findings"][number] = {
				severity: finding.severity,
				message: requireString(finding.message, `review.findings[${index}].message`),
			};
			if (finding.path !== undefined) result.path = requireString(finding.path, `review.findings[${index}].path`);
			return result;
		}),
	};
}
