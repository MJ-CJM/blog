import type { Phase, WorkflowState } from "./types.ts";

const ALLOWED_TRANSITIONS: Readonly<Record<Phase, readonly Phase[]>> = {
	created: ["baseline_captured", "blocked", "cancelled"],
	baseline_captured: ["discovering", "blocked", "cancelled"],
	discovering: ["planning", "blocked", "cancelled"],
	planning: ["awaiting_approval", "blocked", "cancelled"],
	awaiting_approval: ["implementing", "rejected", "cancelled"],
	implementing: ["reviewing_verifying", "blocked", "cancelled"],
	reviewing_verifying: ["implementing", "completed", "blocked", "cancelled"],
	completed: [],
	blocked: [],
	rejected: [],
	cancelled: [],
};

export function canTransition(from: Phase, to: Phase): boolean {
	return ALLOWED_TRANSITIONS[from].includes(to);
}

export function transitionState(state: WorkflowState, to: Phase, updatedAt: string): WorkflowState {
	if (!canTransition(state.phase, to)) {
		throw new Error(`Invalid workflow transition: ${state.phase} -> ${to}`);
	}
	return { ...state, phase: to, updatedAt };
}

export function isTerminalPhase(phase: Phase): boolean {
	return phase === "completed" || phase === "blocked" || phase === "rejected" || phase === "cancelled";
}
