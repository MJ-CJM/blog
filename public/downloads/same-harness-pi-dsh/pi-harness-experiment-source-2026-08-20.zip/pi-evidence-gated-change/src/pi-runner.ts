import { spawn } from "node:child_process";
import { existsSync, readFileSync } from "node:fs";
import { join } from "node:path";
import type { AgentRunResult, AgentRunner, AgentTask } from "./types.ts";

export interface PiRunnerConfiguration {
	projectRoot: string;
	model?: string;
	thinkingLevel?: string;
	piCommand?: { command: string; args?: string[] };
	forceKillAfterMs?: number;
}

interface JsonMessage {
	role?: string;
	content?: Array<{ type?: string; text?: string }>;
	stopReason?: string;
	errorMessage?: string;
}

function getInvocation(projectRoot: string, explicit?: { command: string; args?: string[] }): { command: string; args: string[] } {
	if (explicit) return { command: explicit.command, args: explicit.args ?? [] };
	const packageJsonPath = join(projectRoot, "node_modules", "@earendil-works", "pi-coding-agent", "package.json");
	const packageJson = JSON.parse(readFileSync(packageJsonPath, "utf8")) as { version?: string };
	if (packageJson.version !== "0.84.2") throw new Error(`Expected local Pi 0.84.2, found ${packageJson.version ?? "unknown"}`);
	const localPi = join(projectRoot, "node_modules", ".bin", "pi");
	if (!existsSync(localPi)) throw new Error(`Pinned local Pi runner is missing: ${localPi}`);
	return { command: localPi, args: [] };
}

export class PiSubprocessAgentRunner implements AgentRunner {
	private configuration: PiRunnerConfiguration;

	constructor(configuration: PiRunnerConfiguration) {
		this.configuration = configuration;
	}

	configure({ model, thinkingLevel }: { model: string | undefined; thinkingLevel: string | undefined }): void {
		const { model: _model, thinkingLevel: _thinkingLevel, ...base } = this.configuration;
		this.configuration = { ...base };
		if (model !== undefined) this.configuration.model = model;
		if (thinkingLevel !== undefined) this.configuration.thinkingLevel = thinkingLevel;
	}

	async run(task: AgentTask, signal: AbortSignal): Promise<AgentRunResult> {
		const rolePromptPath = join(this.configuration.projectRoot, "agents", `${task.role}.md`);
		const childGuardPath = join(this.configuration.projectRoot, "src", "child-guard.ts");
		const args = [
			"--mode",
			"json",
			"-p",
			"--no-session",
			"--no-extensions",
			"-e",
			childGuardPath,
			"--no-skills",
			"--no-prompt-templates",
			"--no-context-files",
			"--no-approve",
			"--append-system-prompt",
			rolePromptPath,
			"--tools",
			task.tools.join(","),
		];
		if (this.configuration.model) args.push("--model", this.configuration.model);
		if (this.configuration.thinkingLevel) args.push("--thinking", this.configuration.thinkingLevel);
		args.push(`Task: ${task.prompt}`);

		const invocation = getInvocation(this.configuration.projectRoot, this.configuration.piCommand);
		return await new Promise<AgentRunResult>((resolvePromise) => {
			const child = spawn(invocation.command, [...invocation.args, ...args], {
				cwd: task.cwd,
				shell: false,
				stdio: ["ignore", "pipe", "pipe"],
				env: process.env,
			});
			let stdoutBuffer = "";
			let stderr = "";
			let finalText = "";
			let stopReason: string | undefined;
			let settled = false;
			let sawTerminalAssistant = false;
			let invalidJson = false;

			const processLine = (line: string) => {
				if (!line.trim()) return;
				let event: { type?: string; message?: JsonMessage };
				try {
					event = JSON.parse(line) as { type?: string; message?: JsonMessage };
				} catch {
					invalidJson = true;
					stderr += `Invalid Pi JSON event: ${line.slice(0, 200)}\n`;
					return;
				}
				if (event.type !== "message_end" || event.message?.role !== "assistant") return;
				sawTerminalAssistant = true;
				const text = event.message.content?.find((part) => part.type === "text")?.text;
				if (text !== undefined) finalText = text;
				stopReason = event.message.stopReason;
				if (event.message.errorMessage) stderr += `${event.message.errorMessage}\n`;
			};

			child.stdout.on("data", (chunk: Buffer) => {
				stdoutBuffer += chunk.toString("utf8");
				const lines = stdoutBuffer.split("\n");
				stdoutBuffer = lines.pop() ?? "";
				for (const line of lines) processLine(line);
			});
			child.stderr.on("data", (chunk: Buffer) => {
				stderr += chunk.toString("utf8");
			});

			let forceKill: NodeJS.Timeout | undefined;
			let terminating = false;
			let terminationReason: "aborted" | "timeout" | undefined;
			const terminate = (reason: "aborted" | "timeout") => {
				if (terminating) return;
				terminating = true;
				terminationReason = reason;
				stderr += reason === "aborted" ? "Subagent aborted by workflow\n" : "Subagent timed out\n";
				child.kill("SIGTERM");
				forceKill = setTimeout(() => child.kill("SIGKILL"), this.configuration.forceKillAfterMs ?? 5_000);
				forceKill.unref();
			};
			const timeout = setTimeout(() => terminate("timeout"), task.timeoutMs ?? 120_000);
			const abort = () => terminate("aborted");
			if (signal.aborted) abort();
			else signal.addEventListener("abort", abort, { once: true });

			const finish = (exitCode: number) => {
				if (settled) return;
				settled = true;
				clearTimeout(timeout);
				if (forceKill) clearTimeout(forceKill);
				signal.removeEventListener("abort", abort);
				if (stdoutBuffer.trim()) processLine(stdoutBuffer);
				if (!sawTerminalAssistant) stderr += "Missing terminal assistant message\n";
				const effectiveExitCode =
					exitCode !== 0 ? exitCode : terminationReason || invalidJson || !sawTerminalAssistant ? 1 : 0;
				const result: AgentRunResult = {
					role: task.role,
					exitCode: effectiveExitCode,
					output: finalText,
					stderr,
				};
				if (stopReason !== undefined) result.stopReason = stopReason;
				resolvePromise(result);
			};

			child.on("error", (error) => {
				stderr += `${error.message}\n`;
				finish(1);
			});
			child.on("close", (code, childSignal) => {
				if (childSignal && !stderr.includes(childSignal)) stderr += `Subagent terminated by ${childSignal}\n`;
				finish(code ?? 1);
			});
		});
	}
}
