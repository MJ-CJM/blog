import { isAbsolute, resolve } from "node:path";
import type { ExtensionAPI } from "@earendil-works/pi-coding-agent";
import { Box, Text } from "@earendil-works/pi-tui";
import { sanitizeDynamicDiagnostic } from "./dynamic-diagnostics.ts";
import type { DynamicJson, DynamicRunState } from "./dynamic-types.ts";

export const DYNAMIC_WORKFLOW_RESULT_ENTRY_TYPE = "dynamic-workflow-result";
export const DYNAMIC_WORKFLOW_RESULT_PREVIEW_CHARS = 12_000;

const TRUNCATION_NOTICE = "\n… [preview truncated; open result.json for the complete result]";
const MAX_FAILURE_CAUSES = 8;
const MAX_FAILURE_CAUSE_CHARS = 2_000;

export interface DynamicWorkflowResultEntryData {
	schemaVersion: 1;
	runId: string;
	workflow: string;
	agentsStarted: number;
	agentsSuccessful: number;
	agentsFailed: number;
	failureCauses: string[];
	resultPath: string;
	preview: string;
	previewTruncated: boolean;
	publishedAt: string;
}

function stripTerminalControls(value: string, preserveWhitespace: boolean): string {
	return value
		.replace(/\u001B(?:\[[0-?]*[ -/]*[@-~]|\][^\u0007]*(?:\u0007|\u001B\\))/g, "")
		.replace(preserveWhitespace ? /[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g : /[\u0000-\u001F\u007F]/g, "�");
}

function displaySafe(value: string, maxLength = Number.MAX_SAFE_INTEGER): string {
	return stripTerminalControls(sanitizeDynamicDiagnostic(value, maxLength), true);
}

function checkedCount(label: string, value: number): number {
	if (!Number.isInteger(value) || value < 0) throw new Error(`${label} must be a non-negative integer`);
	return value;
}

function resultText(value: DynamicJson): string {
	return typeof value === "string" ? value : JSON.stringify(value, null, 2);
}

export function createDynamicWorkflowResultEntry(
	state: DynamicRunState,
	value: DynamicJson,
	resultPath: string,
): DynamicWorkflowResultEntryData {
	if (state.status !== "completed") {
		throw new Error(`Run ${state.runId} has no completed result (status=${state.status})`);
	}
	const agentsStarted = checkedCount("agentsStarted", state.agentsStarted);
	const agentsSuccessful = checkedCount("agentsCompleted", state.agentsCompleted);
	if (agentsSuccessful > agentsStarted) throw new Error("agentsCompleted cannot exceed agentsStarted");
	const sanitized = displaySafe(resultText(value));
	const previewTruncated = sanitized.length > DYNAMIC_WORKFLOW_RESULT_PREVIEW_CHARS;
	let preview = sanitized;
	if (previewTruncated) {
		let end = DYNAMIC_WORKFLOW_RESULT_PREVIEW_CHARS - TRUNCATION_NOTICE.length;
		const finalCodeUnit = sanitized.charCodeAt(end - 1);
		const followingCodeUnit = sanitized.charCodeAt(end);
		if (finalCodeUnit >= 0xd800 && finalCodeUnit <= 0xdbff && followingCodeUnit >= 0xdc00 && followingCodeUnit <= 0xdfff) end--;
		preview = `${sanitized.slice(0, end)}${TRUNCATION_NOTICE}`;
	}
	const failureCauses = (state.failureCauses ?? [])
		.slice(0, MAX_FAILURE_CAUSES)
		.map((cause) => displaySafe(cause, MAX_FAILURE_CAUSE_CHARS));
	return {
		schemaVersion: 1,
		runId: state.runId,
		workflow: displaySafe(state.workflow),
		agentsStarted,
		agentsSuccessful,
		agentsFailed: agentsStarted - agentsSuccessful,
		failureCauses,
		resultPath: stripTerminalControls(resolve(resultPath), false),
		preview,
		previewTruncated,
		publishedAt: new Date().toISOString(),
	};
}

export function isDynamicWorkflowResultEntryData(value: unknown): value is DynamicWorkflowResultEntryData {
	if (!value || typeof value !== "object" || Array.isArray(value)) return false;
	const data = value as Record<string, unknown>;
	return (
		data.schemaVersion === 1 &&
		typeof data.runId === "string" &&
		typeof data.workflow === "string" &&
		Number.isInteger(data.agentsStarted) &&
		(data.agentsStarted as number) >= 0 &&
		Number.isInteger(data.agentsSuccessful) &&
		(data.agentsSuccessful as number) >= 0 &&
		Number.isInteger(data.agentsFailed) &&
		(data.agentsFailed as number) >= 0 &&
		(data.agentsSuccessful as number) + (data.agentsFailed as number) === data.agentsStarted &&
		Array.isArray(data.failureCauses) &&
		data.failureCauses.length <= MAX_FAILURE_CAUSES &&
		data.failureCauses.every((cause) => typeof cause === "string") &&
		data.failureCauses.every((cause) => (cause as string).length <= MAX_FAILURE_CAUSE_CHARS) &&
		typeof data.resultPath === "string" &&
		isAbsolute(data.resultPath) &&
		!/[\u0000-\u001F\u007F]/.test(data.resultPath) &&
		typeof data.preview === "string" &&
		data.preview.length <= DYNAMIC_WORKFLOW_RESULT_PREVIEW_CHARS &&
		typeof data.previewTruncated === "boolean" &&
		typeof data.publishedAt === "string"
	);
}

export function formatDynamicWorkflowResultEntry(data: DynamicWorkflowResultEntryData): string {
	return [
		`run=${data.runId}`,
		`workflow=${data.workflow}`,
		`agents=${data.agentsSuccessful}/${data.agentsStarted} successful  failed=${data.agentsFailed}`,
		...(data.failureCauses.length ? ["failureCauses:", ...data.failureCauses.map((cause) => `- ${cause}`)] : []),
		`result=${data.resultPath}`,
		...(data.previewTruncated ? ["preview=truncated to 12,000 characters; result.json is authoritative"] : []),
		"",
		data.preview,
	].join("\n");
}

export function registerDynamicWorkflowResultRenderer(pi: ExtensionAPI): void {
	pi.registerEntryRenderer<DynamicWorkflowResultEntryData>(DYNAMIC_WORKFLOW_RESULT_ENTRY_TYPE, (entry, _options, theme) => {
		const box = new Box(1, 1, (text) => theme.bg("customMessageBg", text));
		if (!isDynamicWorkflowResultEntryData(entry.data)) {
			box.addChild(new Text(theme.fg("error", "[Dynamic Workflow result] invalid persisted entry"), 0, 0));
			return box;
		}
		const data = entry.data;
		const heading = `${theme.fg("accent", "[Dynamic Workflow result]")} ${theme.fg("success", `${data.agentsSuccessful}/${data.agentsStarted} Agents successful`)}`;
		const metadata = [
			`run=${data.runId}`,
			`workflow=${data.workflow}`,
			`failed=${data.agentsFailed}`,
			...(data.failureCauses.length ? ["failureCauses:", ...data.failureCauses.map((cause) => `- ${cause}`)] : []),
			`result=${data.resultPath}`,
			...(data.previewTruncated ? [theme.fg("warning", "preview truncated; result.json is authoritative")] : []),
		].join("\n");
		box.addChild(new Text(`${heading}\n${theme.fg("dim", metadata)}\n`, 0, 0));
		box.addChild(new Text(data.preview, 0, 0));
		return box;
	});
}
