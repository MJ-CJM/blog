import { readFileSync } from "node:fs";
import { join } from "node:path";
import { Ajv2020, type ValidateFunction } from "ajv/dist/2020.js";

export type SchemaName = "approval" | "discovery" | "implementation" | "plan" | "review" | "state" | "verification";

export class SchemaValidator {
	private readonly schemas = new Map<SchemaName, Record<string, unknown>>();
	private readonly validators = new Map<SchemaName, ValidateFunction>();
	private readonly ajv = new Ajv2020({ allErrors: true, strict: true });

	constructor(projectRoot: string) {
		for (const name of ["approval", "discovery", "implementation", "plan", "review", "state", "verification"] as const) {
			const schema = JSON.parse(
				readFileSync(join(projectRoot, "contract", "schemas", `${name}.schema.json`), "utf8"),
			) as Record<string, unknown>;
			this.schemas.set(name, schema);
			this.validators.set(name, this.ajv.compile(schema));
		}
	}

	validate<T>(name: SchemaName, value: unknown): T {
		const validator = this.validators.get(name);
		if (!validator) throw new Error(`Unknown schema: ${name}`);
		if (!validator(value)) {
			throw new Error(`${name} schema validation failed: ${this.ajv.errorsText(validator.errors, { separator: "; " })}`);
		}
		return value as T;
	}

	inline(name: SchemaName): string {
		const schema = this.schemas.get(name);
		if (!schema) throw new Error(`Unknown schema: ${name}`);
		return JSON.stringify(schema);
	}
}
