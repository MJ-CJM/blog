import { lstat, readFile, readdir } from "node:fs/promises";
import { basename, extname, join, resolve } from "node:path";
import { sha256 } from "./json.ts";
import {
	DYNAMIC_THINKING_LEVELS,
	type DynamicConfig,
	type DynamicLimits,
	type DynamicModelProfile,
	type DynamicParentModel,
	type DynamicThinkingLevel,
	type DynamicWorkflowMeta,
	type ParsedDynamicWorkflow,
	type ResolvedDynamicModel,
} from "./dynamic-types.ts";

const META_PREFIX = "export const meta = ";
const WORKFLOW_ID = /^[a-z0-9][a-z0-9-]{1,63}$/;
const PROFILE_ID = /^[a-z][a-z0-9-]{0,31}$/;

function requireRecord(value: unknown, label: string): Record<string, unknown> {
	if (!value || typeof value !== "object" || Array.isArray(value)) throw new Error(`${label} must be an object`);
	return value as Record<string, unknown>;
}

function requireString(value: unknown, label: string): string {
	if (typeof value !== "string" || value.trim() === "") throw new Error(`${label} must be a non-empty string`);
	return value;
}

function requireInteger(value: unknown, label: string, minimum: number, maximum: number): number {
	if (!Number.isInteger(value) || (value as number) < minimum || (value as number) > maximum) {
		throw new Error(`${label} must be an integer between ${minimum} and ${maximum}`);
	}
	return value as number;
}

function rejectUnknown(record: Record<string, unknown>, allowed: readonly string[], label: string): void {
	for (const key of Object.keys(record)) {
		if (!allowed.includes(key)) throw new Error(`${label}.${key} is not recognized`);
	}
}

function parseMeta(value: unknown, workflowId: string): DynamicWorkflowMeta {
	const record = requireRecord(value, "meta");
	rejectUnknown(record, ["name", "description", "whenToUse", "phases"], "meta");
	const name = requireString(record.name, "meta.name");
	if (name !== workflowId) throw new Error(`meta.name ${name} must match workflow file ${workflowId}`);
	if (!WORKFLOW_ID.test(name)) throw new Error("meta.name must be kebab-case");
	const result: DynamicWorkflowMeta = {
		name,
		description: requireString(record.description, "meta.description"),
	};
	if (record.whenToUse !== undefined) result.whenToUse = requireString(record.whenToUse, "meta.whenToUse");
	if (record.phases !== undefined) {
		if (!Array.isArray(record.phases)) throw new Error("meta.phases must be an array");
		const titles = new Set<string>();
		result.phases = record.phases.map((value, index) => {
			const phase = requireRecord(value, `meta.phases[${index}]`);
			rejectUnknown(phase, ["title", "detail", "provider", "model"], `meta.phases[${index}]`);
			const title = requireString(phase.title, `meta.phases[${index}].title`);
			if (titles.has(title)) throw new Error(`meta.phases contains duplicate title ${title}`);
			titles.add(title);
			const parsed = { title } as { title: string; detail?: string; provider?: string; model?: string };
			if (phase.detail !== undefined) parsed.detail = requireString(phase.detail, `meta.phases[${index}].detail`);
			if (phase.provider !== undefined) parsed.provider = requireString(phase.provider, `meta.phases[${index}].provider`);
			if (phase.model !== undefined) parsed.model = requireString(phase.model, `meta.phases[${index}].model`);
			return parsed;
		});
	}
	return result;
}

export function parseDynamicWorkflowSource(source: string, filePath: string, maxSourceBytes: number): ParsedDynamicWorkflow {
	if (Buffer.byteLength(source) > maxSourceBytes) throw new Error(`Workflow source exceeds ${maxSourceBytes} bytes`);
	const newline = source.indexOf("\n");
	if (newline < 0) throw new Error("Workflow must contain a metadata line and a body");
	const firstLine = source.slice(0, newline).replace(/\r$/, "");
	if (!firstLine.startsWith(META_PREFIX) || !firstLine.endsWith(";")) {
		throw new Error(`First line must be exactly ${META_PREFIX}<JSON literal>;`);
	}
	const jsonLiteral = firstLine.slice(META_PREFIX.length, -1);
	let rawMeta: unknown;
	try {
		rawMeta = JSON.parse(jsonLiteral);
	} catch (error) {
		throw new Error(`Workflow metadata is not a JSON literal: ${error instanceof Error ? error.message : String(error)}`);
	}
	const workflowId = basename(filePath, extname(filePath));
	const body = source.slice(newline + 1);
	if (body.trim() === "") throw new Error("Workflow body must not be empty");
	return { meta: parseMeta(rawMeta, workflowId), body, source, sourceHash: sha256(source), filePath };
}

export async function loadDynamicWorkflow(workflowsRoot: string, workflowId: string, maxSourceBytes: number): Promise<ParsedDynamicWorkflow> {
	if (!WORKFLOW_ID.test(workflowId)) throw new Error(`Invalid workflow id: ${workflowId}`);
	const root = resolve(workflowsRoot);
	const filePath = resolve(root, `${workflowId}.js`);
	if (!filePath.startsWith(`${root}/`)) throw new Error("Workflow path escapes definitions root");
	const info = await lstat(filePath);
	if (!info.isFile() || info.isSymbolicLink()) throw new Error(`Workflow must be a regular file: ${workflowId}`);
	return parseDynamicWorkflowSource(await readFile(filePath, "utf8"), filePath, maxSourceBytes);
}

export async function listDynamicWorkflows(workflowsRoot: string, maxSourceBytes: number): Promise<ParsedDynamicWorkflow[]> {
	const names = (await readdir(workflowsRoot)).filter((name) => name.endsWith(".js")).sort();
	return await Promise.all(names.map((name) => loadDynamicWorkflow(workflowsRoot, basename(name, ".js"), maxSourceBytes)));
}

function parseProfile(value: unknown, label: string): DynamicModelProfile {
	const record = requireRecord(value, label);
	rejectUnknown(record, ["provider", "model", "thinking"], label);
	const hasProvider = record.provider !== undefined;
	const hasModel = record.model !== undefined;
	if (hasProvider !== hasModel) throw new Error(`${label}.provider and ${label}.model must be configured together`);
	const profile: DynamicModelProfile = {};
	if (hasProvider && hasModel) {
		profile.provider = requireString(record.provider, `${label}.provider`);
		profile.model = requireString(record.model, `${label}.model`);
	}
	if (record.thinking !== undefined) {
		const thinking = requireString(record.thinking, `${label}.thinking`);
		if (!DYNAMIC_THINKING_LEVELS.includes(thinking as DynamicThinkingLevel)) throw new Error(`${label}.thinking is invalid`);
		profile.thinking = thinking as DynamicThinkingLevel;
	}
	if (!hasProvider && profile.thinking !== undefined) throw new Error(`${label}.thinking requires provider and model`);
	return profile;
}

export async function loadDynamicConfig(configPath: string): Promise<DynamicConfig> {
	const record = requireRecord(JSON.parse(await readFile(configPath, "utf8")) as unknown, "dynamic config");
	rejectUnknown(record, ["schemaVersion", "limits", "profiles"], "dynamic config");
	if (record.schemaVersion !== 1) throw new Error("dynamic config.schemaVersion must be 1");
	const rawLimits = requireRecord(record.limits, "dynamic config.limits");
	rejectUnknown(
		rawLimits,
		[
			"maxParallel",
			"maxAgents",
			"maxItemsPerCall",
			"syncTimeoutMs",
			"agentIdleTimeoutMs",
			"agentTimeoutMs",
			"runTimeoutMs",
			"maxSourceBytes",
			"maxResultBytes",
		],
		"dynamic config.limits",
	);
	const limits: DynamicLimits = {
		maxParallel: requireInteger(rawLimits.maxParallel, "limits.maxParallel", 1, 16),
		maxAgents: requireInteger(rawLimits.maxAgents, "limits.maxAgents", 1, 1000),
		maxItemsPerCall: requireInteger(rawLimits.maxItemsPerCall, "limits.maxItemsPerCall", 1, 1000),
		syncTimeoutMs: requireInteger(rawLimits.syncTimeoutMs, "limits.syncTimeoutMs", 1, 1000),
		agentIdleTimeoutMs: requireInteger(rawLimits.agentIdleTimeoutMs, "limits.agentIdleTimeoutMs", 100, 3_600_000),
		agentTimeoutMs: requireInteger(rawLimits.agentTimeoutMs, "limits.agentTimeoutMs", 100, 3_600_000),
		runTimeoutMs: requireInteger(rawLimits.runTimeoutMs, "limits.runTimeoutMs", 100, 3_600_000),
		maxSourceBytes: requireInteger(rawLimits.maxSourceBytes, "limits.maxSourceBytes", 1024, 1_048_576),
		maxResultBytes: requireInteger(rawLimits.maxResultBytes, "limits.maxResultBytes", 1024, 16_777_216),
	};
	if (limits.maxParallel > limits.maxAgents) throw new Error("limits.maxParallel cannot exceed limits.maxAgents");
	if (limits.agentIdleTimeoutMs > limits.agentTimeoutMs) {
		throw new Error("limits.agentIdleTimeoutMs cannot exceed limits.agentTimeoutMs");
	}
	if (limits.agentTimeoutMs > limits.runTimeoutMs) throw new Error("limits.agentTimeoutMs cannot exceed limits.runTimeoutMs");
	const rawProfiles = requireRecord(record.profiles, "dynamic config.profiles");
	const profiles: Record<string, DynamicModelProfile> = {};
	for (const [name, value] of Object.entries(rawProfiles)) {
		if (!PROFILE_ID.test(name)) throw new Error(`Invalid profile id: ${name}`);
		profiles[name] = parseProfile(value, `profiles.${name}`);
	}
	for (const required of ["fast", "deep", "review"]) {
		if (!profiles[required]) throw new Error(`Required profile is missing: ${required}`);
	}
	return { schemaVersion: 1, limits, profiles };
}

export function resolveDynamicModels(config: DynamicConfig, parent: DynamicParentModel | undefined): Record<string, ResolvedDynamicModel> {
	const resolved: Record<string, ResolvedDynamicModel> = {};
	for (const [name, profile] of Object.entries(config.profiles)) {
		if (profile.provider && profile.model) {
			resolved[name] = { provider: profile.provider, model: profile.model, ...(profile.thinking ? { thinking: profile.thinking } : {}) };
			continue;
		}
		if (!parent) throw new Error(`Profile ${name} is empty and no parent Pi model is active`);
		resolved[name] = { provider: parent.provider, model: parent.model, ...(parent.thinking ? { thinking: parent.thinking } : {}) };
	}
	return resolved;
}
