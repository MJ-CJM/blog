export const meta = {"name":"multi-model-review","description":"Review one task with fast, deep, and review model profiles, challenge each review, then synthesize a host-contracted final result.","whenToUse":"Use when one task benefits from independent model perspectives and a final reconciled recommendation.","phases":[{"title":"independent-reviews","detail":"Collect three independent reviews in parallel."},{"title":"challenge-reviews","detail":"Challenge each review through a per-item pipeline."},{"title":"synthesis","detail":"Reconcile the reviews and challenges into one result."}]};
phase("independent-reviews");
const reviews = await parallel([
  () => agent(`Review this task independently and return concise plain text with Summary, Risks, and Recommendations sections. Task: ${args.task}`, { ...args.models.fast, label: "fast-review", phase: "independent-reviews" }),
  () => agent(`Review this task independently and return concise plain text with Summary, Risks, and Recommendations sections. Task: ${args.task}`, { ...args.models.deep, label: "deep-review", phase: "independent-reviews" }),
  () => agent(`Review this task independently and return concise plain text with Summary, Risks, and Recommendations sections. Task: ${args.task}`, { ...args.models.review, label: "review-review", phase: "independent-reviews" }),
]);
const reviewRoutes = [args.models.fast, args.models.deep, args.models.review];
const successfulReviewEntries = reviews
  .map((item, index) => ({ item, route: reviewRoutes[index] }))
  .filter((entry) => typeof entry.item === "string" && entry.item.trim() !== "");
const successfulReviews = successfulReviewEntries.map((entry) => entry.item);
if (successfulReviews.length < 2) throw new Error("multi-model-review requires at least two successful independent reviews");
const minDistinctReviewRoutes = args.minDistinctReviewRoutes === undefined ? 1 : args.minDistinctReviewRoutes;
if (!Number.isInteger(minDistinctReviewRoutes) || minDistinctReviewRoutes < 1 || minDistinctReviewRoutes > 3) throw new Error("minDistinctReviewRoutes must be an integer from 1 to 3");
const successfulReviewRouteCount = new Set(successfulReviewEntries.map((entry) => `${entry.route.provider}\u0000${entry.route.model}`)).size;
if (successfulReviewRouteCount < minDistinctReviewRoutes) throw new Error(`multi-model-review requires at least ${minDistinctReviewRoutes} distinct successful independent review routes`);
phase("challenge-reviews");
const challenges = await pipeline(
  successfulReviews,
  async (item) => agent(`Challenge this review and return concise plain text with Valid Points, Blind Spots, and Corrections sections. Review: ${JSON.stringify(item)}`, { ...args.models.deep, label: "challenge-review", phase: "challenge-reviews" }),
);
const successfulChallenges = challenges.filter((item) => typeof item === "string" && item.trim() !== "");
if (successfulChallenges.length < 2) throw new Error("multi-model-review requires at least two successful challenge reviews");
phase("synthesis");
const finalInstruction = typeof args.finalInstruction === "string" && args.finalInstruction.trim() !== "" ? args.finalInstruction : "Return concise plain text with Summary, Agreements, Disagreements, Risks, and Recommendation sections.";
const result = await agent(`Synthesize the task, reviews, and challenges into one final result. Input: ${JSON.stringify({ task: args.task, reviews: successfulReviews, challenges: successfulChallenges })}\nFinal output instruction: ${finalInstruction}`, { ...args.models.review, label: "final-synthesis", phase: "synthesis" });
if (typeof result !== "string" || result.trim() === "") throw new Error("multi-model-review final synthesis failed");
log("workflow-result-ready");
return result;
