# TodoService fixture

`TodoService.createTask({ title, completed? })` creates an in-memory task. `listTasks()` returns defensive copies.

Run the baseline tests with:

```bash
npm test
```
