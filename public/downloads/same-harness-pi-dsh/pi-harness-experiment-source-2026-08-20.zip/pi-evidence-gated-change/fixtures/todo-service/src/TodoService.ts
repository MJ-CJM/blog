export interface Task {
	id: number;
	title: string;
	completed: boolean;
}

export interface CreateTaskInput {
	title: string;
	completed?: boolean;
}

export class TodoService {
	private readonly tasks: Task[] = [];
	private nextId = 1;

	createTask(input: CreateTaskInput): Task {
		if (!input.title.trim()) throw new Error("title is required");
		const task: Task = {
			id: this.nextId++,
			title: input.title,
			completed: input.completed ?? false,
		};
		this.tasks.push(task);
		return { ...task };
	}

	listTasks(): Task[] {
		return this.tasks.map((task) => ({ ...task }));
	}
}
