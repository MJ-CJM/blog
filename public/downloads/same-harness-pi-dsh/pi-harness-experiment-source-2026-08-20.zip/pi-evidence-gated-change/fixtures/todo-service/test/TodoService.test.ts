import assert from "node:assert/strict";
import test from "node:test";
import { TodoService } from "../src/TodoService.ts";

test("createTask stores a task and listTasks returns defensive copies", () => {
	const service = new TodoService();
	const created = service.createTask({ title: "write report" });
	assert.deepEqual(created, { id: 1, title: "write report", completed: false });
	created.title = "mutated outside";
	assert.equal(service.listTasks()[0]?.title, "write report");
});

test("createTask rejects an empty title", () => {
	const service = new TodoService();
	assert.throws(() => service.createTask({ title: "   " }), /title is required/);
});
