# Pi Harness 实验源码附件

- 快照日期：2026-08-20
- 实验版本：Pi Coding Agent / Pi TUI `0.84.2`
- 对应文章：`同样叫 Agent Harness，Pi 和 DeepSeek Harness 把调度权交给了谁？`

## 包含内容

本附件保留 Pi 侧 Extension 源码、测试、Skill、Agent 模板、模型 Profile、saved workflow、结果契约、TodoService fixture、`package-lock.json` 与中文运行手册。核心实现包括前台 Dynamic Workflow、独立 Pi JSON 子进程、超时与取消、状态/事件/结果文件和 TUI 结果展示。

## 已排除内容

为避免泄露本机信息并控制附件体积，压缩包不含：

- `node_modules`、构建输出（`lib`、`dist`、`build`、`coverage`）；
- `.git`、IDE 元数据、`.jbeval`、`.agents`；
- `runs`、Session、运行收据、日志、缓存和环境变量文件；
- 任何凭据或本机生成配置。

源码和文档中的本机绝对路径已统一替换为 `/path/to/...` 示例路径。运行前请按实际目录调整命令。

## 重要边界

这是研究实验快照，不是生产发布，也不保证下载后零配置运行。Extension 自己拥有外层 Workflow 调度、子进程、状态、超时和 UI；每个子进程内部仍使用官方 Pi Agent Loop。Worker、`node:vm` 和 Node Permission 不是敌意代码安全沙箱；已完成结果可重放，但本实验没有实现 active run 的跨进程恢复或取消。

`package-lock.json` 被保留用于锁定公开 npm 依赖版本；`node_modules` 未打包。本附件未包含第三方依赖源码，所有依赖仍遵守各自的上游许可证。本实验目录未附单独的开源许可证，公开复用前应由作者补充或确认授权范围。

测试文件中保留了专门验证脱敏逻辑的无效示例字符串（例如 `sk-do-not-persist-...`、测试用 GitHub/AWS 前缀）；它们只用于断言敏感信息不会进入日志或结果，并非真实凭据。
