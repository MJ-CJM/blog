import { createHash } from "node:crypto";
import { readFile, readdir, writeFile } from "node:fs/promises";
import { dirname, join, relative, resolve, sep } from "node:path";
import { fileURLToPath } from "node:url";

const projectRoot = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const sharedRoot = join(projectRoot, "dynamic-workflow", "shared");
const manifestPath = join(sharedRoot, "manifest.json");

async function walk(current = sharedRoot) {
	const files = [];
	for (const entry of await readdir(current, { withFileTypes: true })) {
		const fullPath = join(current, entry.name);
		if (entry.isSymbolicLink()) throw new Error(`Dynamic Workflow shared files cannot be symlinks: ${fullPath}`);
		if (entry.isDirectory()) files.push(...(await walk(fullPath)));
		else if (entry.isFile() && fullPath !== manifestPath) files.push(fullPath);
	}
	return files;
}

const files = [];
for (const filePath of (await walk()).sort()) {
	files.push({
		path: relative(sharedRoot, filePath).split(sep).join("/"),
		sha256: createHash("sha256").update(await readFile(filePath)).digest("hex"),
	});
}
const aggregateHash = createHash("sha256");
for (const file of files) aggregateHash.update(`${file.path}\0${file.sha256}\0`);
const manifest = { schemaVersion: 1, aggregate: aggregateHash.digest("hex"), files };

if (process.argv.includes("--check")) {
	const existing = JSON.parse(await readFile(manifestPath, "utf8"));
	if (JSON.stringify(existing) !== JSON.stringify(manifest)) {
		throw new Error("Dynamic Workflow shared manifest drift; run npm run hash:dynamic only after an intentional shared-script change");
	}
	console.log(`${manifest.aggregate} (${manifest.files.length} files)`);
} else {
	await writeFile(manifestPath, `${JSON.stringify(manifest, null, 2)}\n`, "utf8");
	console.log(`${manifest.aggregate} (${manifest.files.length} files)`);
}
