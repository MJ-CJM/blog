import assert from "node:assert/strict";
import { readFile, realpath } from "node:fs/promises";
import { pathToFileURL } from "node:url";
import { resolve } from "node:path";

const worktreeArgument = process.argv[2];
if (!worktreeArgument) throw new Error("Usage: verify-fixture.mjs <isolated-worktree>");
const worktree = await realpath(resolve(worktreeArgument));
const moduleUrl = pathToFileURL(resolve(worktree, "src", "TodoService.ts"));
moduleUrl.searchParams.set("run", `${Date.now()}`);
const module = await import(moduleUrl.href);
assert.equal(typeof module.TodoService, "function", "TodoService export is missing");

const service = new module.TodoService();
const first = service.createTask({ title: "draft", requestId: "req-1" });
assert.equal(first.id, 1, "the first task id must start at 1");
const duplicate = service.createTask({ title: "changed title", completed: true, requestId: "req-1" });
assert.deepEqual(duplicate, first, "same requestId must return the original task value");
assert.equal(service.listTasks().length, 1, "same requestId must not create a duplicate task");
duplicate.title = "mutated return value";
assert.deepEqual(
	service.createTask({ title: "ignored again", requestId: "req-1" }),
	first,
	"idempotency lookup must return a defensive copy of the original task",
);

const second = service.createTask({ title: "draft", requestId: "req-2" });
assert.notEqual(second.id, first.id, "different requestId must create a different task");
assert.equal(second.id, 2, "duplicate requestId must not consume the next task id");
assert.equal(service.listTasks().length, 2);
assert.throws(
	() => service.createTask({ title: "invalid", requestId: "" }),
	/requestId/i,
	"empty requestId must throw a requestId-specific error",
);
assert.throws(
	() => service.createTask({ title: "invalid", requestId: "   " }),
	/requestId/i,
	"whitespace-only requestId must throw a requestId-specific error",
);

const testSource = await readFile(resolve(worktree, "test", "TodoService.test.ts"), "utf8");
const readme = await readFile(resolve(worktree, "README.md"), "utf8");
assert.match(testSource, /requestId/, "project tests must cover requestId");
assert.match(readme, /requestId/, "README must document requestId");

process.stdout.write("oracle: requestId idempotency contract passed\n");
