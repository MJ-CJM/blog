import { createHash } from "node:crypto";
import { readdir, readFile, writeFile } from "node:fs/promises";
import { dirname, join, relative, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const projectRoot = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const roots = ["contract", "skills/evidence-gated-change", "agents", "fixtures/todo-service"];
const entries = [];

async function walk(root, current = root) {
	for (const entry of await readdir(current, { withFileTypes: true })) {
		const path = join(current, entry.name);
		if (entry.isDirectory()) await walk(root, path);
		else if (entry.isFile() && entry.name !== "manifest.json") {
			const content = await readFile(path);
			entries.push({
				path: relative(projectRoot, path).split("\\").join("/"),
				sha256: createHash("sha256").update(content).digest("hex"),
			});
		}
	}
}

for (const root of roots) await walk(resolve(projectRoot, root));
entries.sort((left, right) => left.path.localeCompare(right.path));
const aggregate = createHash("sha256");
for (const entry of entries) aggregate.update(`${entry.path}\0${entry.sha256}\0`);
const manifest = { algorithm: "sha256", aggregate: aggregate.digest("hex"), files: entries };
const manifestPath = resolve(projectRoot, "contract", "manifest.json");
if (process.argv.includes("--check")) {
	const stored = JSON.parse(await readFile(manifestPath, "utf8"));
	if (JSON.stringify(stored) !== JSON.stringify(manifest)) {
		throw new Error("Shared contract manifest drift: run npm run hash:contract");
	}
} else {
	await writeFile(manifestPath, `${JSON.stringify(manifest, null, 2)}\n`);
}
process.stdout.write(`${manifest.aggregate}\n`);
