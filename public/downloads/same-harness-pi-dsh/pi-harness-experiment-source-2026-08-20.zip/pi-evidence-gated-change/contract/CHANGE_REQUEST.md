# TodoService requestId idempotency

Add a required, non-empty `requestId` to `TodoService.createTask`.

The acceptance contract is fixed:

1. The first call for a `requestId` creates one task.
2. Repeating the same `requestId`, even with a different title or `completed` value, returns the original task and does not create another task.
3. A different `requestId`, even with the same title, creates a different task.
4. An empty or whitespace-only `requestId` throws.
5. Duplicate calls do not consume task IDs, and returned values are defensive copies.
6. `requestId` is required by the public TypeScript input type.
7. The implementation, project tests, and README are updated.
8. Only these files may change:
   - `src/TodoService.ts`
   - `test/TodoService.test.ts`
   - `README.md`

The verifier runs the project test using the real process exit code, an external oracle, and a compile-time API probe. Agent prose is not verification evidence.
