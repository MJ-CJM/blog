# Pi Evidence-Gated Change

This project implements the fixed `TodoService.createTask` requestId-idempotency workflow and a separate saved-script Dynamic Workflow experiment as one Pi Extension. It does not modify the adjacent `pi/` source clone.

中文安装、验证与真实模型操作步骤见 [RUNBOOK.zh-CN.md](./RUNBOOK.zh-CN.md)。

## What is implemented

- Deterministic reducer: `created → baseline_captured → discovering → planning → awaiting_approval → implementing → reviewing_verifying → completed|blocked`.
- Parallel Code Scout and Test Scout child processes with isolated Pi JSON sessions.
- Approval binds the canonical plan, immutable baseline, shared contract, and local runtime adapter hashes; all four are rechecked before mutation.
- Fixed project-test, external-oracle, and compile-time API receipts. Agent prose cannot override a failed exit code.
- Exactly one Repair attempt.
- Intent/settled event pairs, atomic state snapshots, branch-local Pi custom entries, resume, cancellation, and child-process cleanup.
- Child agents load only the workflow guard Extension; shell is unavailable and path-based tools are confined to the isolated worktree.
- A separate Dynamic Workflow v1 loads trusted local scripts with the native `agent`, `parallel`, `pipeline`, `phase`, `log`, and `args` vocabulary, routes each Agent through a logical model profile, waits in the `/dw-run` command while live progress is rendered, writes durable evidence under `dynamic-workflow/runs/`, and appends the final result as a Pi transcript card.

## Use with Pi

This security-focused lab requires Node `>=25.0.0`: Node 25 adds the `--allow-net` permission scope used here to verify that the experiment's direct `fetch` attempt is rejected under the selected flags. Pi itself supports older Node versions, but this verifier deliberately fails closed on them.

Install this project's pinned dependencies, then run its exact project-local Pi 0.84.2 binary with an already configured model:

```bash
npm install --ignore-scripts
./node_modules/.bin/pi --no-extensions -e /path/to/pi-evidence-gated-change/src/extension.ts
```

The package-local path was also smoke-tested from a separate, trusted Pi project. `-l` records the package in the consumer project's `.pi/settings.json`; it does not write `.pi` configuration into this Extension project:

```bash
cd /path/to/trusted-pi-consumer
PI_CODING_AGENT_DIR=/path/to/isolated-pi-home \
  /path/to/pi-evidence-gated-change/node_modules/.bin/pi \
  install -l /path/to/pi-evidence-gated-change --approve

PI_CODING_AGENT_DIR=/path/to/isolated-pi-home \
  /path/to/pi-evidence-gated-change/node_modules/.bin/pi --approve
```

The isolated smoke test loaded all six `egc-*` commands, all six `dw-*` commands, and `skill:evidence-gated-change` through the package entry. `--approve` is required because loading project-local code is an explicit trust decision.

Commands:

```text
/egc-start
/egc-status [runId]
/egc-approve <runId> <approvalHash>
/egc-reject <runId> <approvalHash> [reason]
/egc-resume <runId>
/egc-cancel <runId>

/dw-run <workflow> <task...>
/dw-result [runId]
/dw-status [runId]
/dw-list
/dw-cancel <runId>
/dw-models
```

`/egc-start` is intentionally fixed to the bundled fixture. It does not accept an arbitrary repository path. All mutable copies and receipts go under `runs/<runId>/`, which is ignored by Git.

## Dynamic Workflow timeout budget

Dynamic Workflow timeout policy is configured in `dynamic-workflow/pi/model-profiles.json`:

```json
{
  "limits": {
    "agentIdleTimeoutMs": 120000,
    "agentTimeoutMs": 240000,
    "runTimeoutMs": 900000
  }
}
```

These limits serve different purposes:

- `agentIdleTimeoutMs` is a two-minute inactivity watchdog for one child Agent. Observable JSON/event data parsed from the Pi child's stdout renews this idle window, so a model that is still producing events is not killed merely because its total elapsed time passed two minutes. Stderr alone does not count as activity and cannot keep a stuck child alive.
- `agentTimeoutMs` is a four-minute hard cap for one child Agent. Activity never renews or extends this cap.
- `runTimeoutMs` is a fifteen-minute hard cap for the whole saved workflow, including all phases, queueing, retries, and synthesis.

The config loader requires `agentIdleTimeoutMs <= agentTimeoutMs <= runTimeoutMs`; all three values are bounded positive integers, so inconsistent budgets fail before any Agent starts.

For the bundled three-stage `multi-model-review`, the first independent reviews run in parallel within one four-minute Agent budget, the successful challenge reviews run in parallel within a second four-minute budget, and synthesis gets a third four-minute budget. The remaining three minutes of the overall cap cover scheduling, persistence, and provider retry delay; they are not an extra Agent allowance. Any stricter limit wins. A timed-out Agent is recorded as failed, and the minimum-success gate may then fail the workflow even though that gate message is only the downstream consequence.

## Verify without model credentials

```bash
npm install --ignore-scripts
npm run check
npm test
```

The original 16 EGC regressions retain the real reducer, isolated fixture copies, path policy, patch generation, project-test command, external oracle, compile-time requestId requirement, cancellation, repair limit, and recovery behavior. Twenty-six additional keyless tests cover the Dynamic Workflow parser, native parallel/pipeline behavior, native Agent defaults, profile routing, foreground TUI/RPC progress, custom result entries and their reload renderer, `/dw-result` replay without model calls, append fallback, Esc cancellation, retry visibility, hard-quota short-circuiting, redacted root causes, idle/hard/run timeout ordering, activity-based idle renewal, cancellation precedence, malformed Pi events, split UTF-8 output, post-`await` termination, terminal-message closure, minimum-success gates, invalid scripts/results, artifacts, and exact Pi child arguments.

Agent-modified source and tests run under Node's permission model with read access to the isolated worktree. The trusted oracle is separately limited to reading its own file plus that worktree. Neither process is granted filesystem-write, network, child-process, or worker permission; tests specifically verify that direct `writeFileSync`, `execFileSync`, and `fetch` attempts are rejected. Verification fails closed unless the runtime exposes all corresponding permission scopes (including `--allow-net`), and non-cooperative timeouts are killed with `SIGKILL`.

This is defense in depth, not a sandbox or security boundary. Node documents its permission model as a “seat belt”: it helps constrain accidental or expected direct API use, but it is not designed to contain hostile same-UID code or defend against bypasses. Do not use this lab to execute deliberately malicious, untrusted code.

No live-model run is performed by the test suite.

## Shared contract

These four trees are byte-for-byte portable to the DeepSeek Harness adapter:

```text
contract/
agents/
skills/evidence-gated-change/
fixtures/todo-service/
```

`contract/manifest.json` excludes itself, hashes every file with SHA-256, sorts project-relative paths, and hashes `path + NUL + fileHash + NUL`. Run `npm run check:contract` to fail on drift or `npm run hash:contract` after an intentional shared-contract change.

The Pi and DSH Dynamic Workflow adapters also share this saved-script tree byte-for-byte:

```text
dynamic-workflow/shared/
```

Its independent manifest aggregate is `db61f13dca3a75662261dd72f21d603c4c85d79bc1b85ddd8baaf6f2cb3f9776`. Use `npm run check:dynamic` for drift detection. Pi-only model profiles and caps remain in `dynamic-workflow/pi/model-profiles.json` and are intentionally excluded from the shared hash.

## Pi-specific boundary

Pi 0.84.2 has no public replaceable Agent Loop or `shouldStopAfterTurn` hook. This implementation therefore keeps Workflow control in an Extension and dispatches role Agents as separate Pi processes. The portable Skill defines method and policy; it is not an executable scheduler.

Dynamic Workflow v1 executes reviewed local scripts inside a dedicated Worker containing a `node:vm` context. The VM applies a synchronous timeout, while the host can terminate the entire Worker on cancellation or the overall deadline, including a loop that starts after an `await`. Each child Agent also has a stdout-JSON/event-renewed idle watchdog and a non-renewable hard cap; stderr does not renew the idle timer, and the workflow deadline remains an independent hard ceiling. The VM receives no direct `require`, `import`, `process`, filesystem, or shell global, but neither Worker nor `node:vm` is a security boundary. Saved workflows are trusted local code. `/dw-run` stays in the foreground in TUI/RPC modes, renders phase/success/failure/retry progress, accepts queued Esc cancellation in TUI mode, and appends a `dynamic-workflow-result` transcript entry containing a bounded, redacted result preview plus the absolute `result.json` path. In TUI this uses a Box/Text result card; RPC receives both the structured `entry_appended` event and a bounded `notify` request. Custom entries do not participate in LLM context. When Pi has already materialized a session file (for example, the session contains an assistant response), the entry survives session reload. Pi 0.84.2 does not create a session file for a fresh slash-command-only session with no assistant response, so that special case cannot persist the card itself; `result.json` remains authoritative and `/dw-result [runId]` rebuilds the card without invoking a model. JSON/print modes fail before a run or Agent is started. New runs persist only redacted diagnostic summaries; historical run evidence is never rewritten or deleted and may still contain legacy raw stderr. V1 has no approval gate, per-Agent `maxTokens` override, cross-session resume, or cross-process cancellation; `/dw-cancel` only converges runs active in the current Pi process.
