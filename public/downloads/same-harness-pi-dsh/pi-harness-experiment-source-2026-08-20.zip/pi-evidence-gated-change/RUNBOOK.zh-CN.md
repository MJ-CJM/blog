# Pi Evidence-Gated Change 中文运行手册

_面向本地验证、人工审批和故障排查 · 最后验证：2026-08-18_

---

## 📋 目标与运行边界

本手册用于运行固定的 `TodoService.createTask` requestId 幂等改造实验。它覆盖两条互相独立的路径：

- **无模型凭据验证**：检查 TypeScript、两套共享 manifest、16 项 EGC 回归和 26 项 Dynamic Workflow fake-agent/stub 测试
- **真实模型人工运行**：由 Pi 启动 Scout、Planner、Implementer、Reviewer 和最多一次 Repair，并在写入前等待人工审批
- **Dynamic Workflow 实验**：运行受信 saved script，以逻辑 profile 编排只读 Agent 的并行、流水线与汇总

工作流只处理项目内置的 `fixtures/todo-service/`，不会接受任意仓库路径。所有可变副本和证据写入本项目的 `runs/{runId}/`；相邻的 `../pi/` 源码仓不应发生变化。

### 状态生命周期

```mermaid
stateDiagram-v2
    accTitle: Evidence-Gated Change 生命周期
    accDescr: 展示固定 TodoService 工作流从基线捕获、并行发现和审批，到实现、验证及四种终态的主路径

    state "created" as Created
    state "baseline_captured" as BaselineCaptured
    state "discovering" as Discovering
    state "planning" as Planning
    state "awaiting_approval" as AwaitingApproval
    state "implementing" as Implementing
    state "reviewing_verifying" as ReviewingVerifying
    state "completed" as Completed
    state "blocked" as Blocked
    state "rejected" as Rejected
    state "cancelled" as Cancelled

    [*] --> Created: ⚡ 启动
    Created --> BaselineCaptured: 📦 捕获基线
    BaselineCaptured --> Discovering: 🔍 并行发现
    Discovering --> Planning: 📋 汇总结果
    Planning --> AwaitingApproval: 🔒 绑定哈希
    AwaitingApproval --> Implementing: ✅ 人工批准
    AwaitingApproval --> Rejected: 🚫 人工拒绝
    Implementing --> ReviewingVerifying: 🔍 实现完成
    ReviewingVerifying --> Implementing: 🔄 单次修复
    ReviewingVerifying --> Completed: ✅ 双门通过
    ReviewingVerifying --> Blocked: ❌ 门禁失败

    Completed --> [*]: 🏁 完成
    Blocked --> [*]: 🏁 阻塞
    Rejected --> [*]: 🏁 拒绝
    Cancelled --> [*]: 🏁 取消

    note right of Cancelled
        任一非终态都可取消
    end note
    note right of Blocked
        任一执行阶段错误都可阻塞
    end note
```

图中只展开主要门禁路径；`blocked` 和 `cancelled` 可由 reducer 允许的多个非终态进入。精确转换以 `src/reducer.ts` 为准。

## 🔧 环境准备

### 前置条件

| 要求 | 固定值或下限 | 验证命令 | 说明 |
| --- | --- | --- | --- |
| Node.js | `>=25.0.0` | `node --version` | Node 25 提供本实验要求的 `--allow-net` 权限作用域 |
| npm | 随 Node 25 提供 | `npm --version` | 使用锁文件安装 |
| Pi | `0.84.2` | `./node_modules/.bin/pi --version` | 必须使用项目本地 binary |
| 模型配置 | 仅真实模型流程需要 | 在 Pi 中确认当前模型 | 无模型测试不读取模型凭据 |

> ⚠️ **不要降级到 Node 22 或 24。** Pi 本身支持更早版本，但本实验需要 Node 25 的网络权限作用域；验证器在作用域不完整时会 fail closed。

### 安装锁定依赖

```bash
cd /path/to/pi-evidence-gated-change
npm ci --ignore-scripts
node --version
./node_modules/.bin/pi --version
```

预期至少满足：

```text
v25.x.x
0.84.2
```

`npm ci` 以 `package-lock.json` 为准。项目不会调用全局 `pi`，`src/pi-runner.ts` 也会在启动子 Agent 前再次校验本地 Pi 必须等于 `0.84.2`。

### 构建含义

该实验没有 `dist/`，也没有 `npm run build`。Pi 直接加载 TypeScript Extension；这里的构建等价检查是：

```bash
npm run check
```

该命令依次执行 `tsc --noEmit`、EGC 共享契约 manifest 和 Dynamic Workflow shared manifest 校验。成功表示类型检查通过且两套共享内容无漂移，不会产出编译后的 JavaScript。

## ✅ 无模型凭据验证

以下检查不会调用真实模型，也不需要模型 API Key。`npm audit` 会访问 npm registry，因此“无模型凭据”不等于“完全离线”。

### 一次性执行

```bash
cd /path/to/pi-evidence-gated-change
npm run check
npm test
npm run check:contract
npm audit --json
```

当前锁文件和代码的预期结果：

| 检查 | 预期结果 |
| --- | --- |
| `npm run check` | `tsc --noEmit` 和 manifest 均通过 |
| `npm test` | `42` 项通过，`0` 项失败，其中原 EGC 回归仍为 `16` 项 |
| `npm run check:contract` | 输出固定共享哈希 |
| `npm run check:dynamic` | 输出 Dynamic Workflow shared 哈希 |
| `npm audit --json` | 漏洞总数为 `0` |

当前共享契约哈希为：

```text
4285706cc55f6c2065552c9a727a472181caa36c7d2e5ef1efb7cfb024421e87
```

Dynamic Workflow shared aggregate 为：

```text
db61f13dca3a75662261dd72f21d603c4c85d79bc1b85ddd8baaf6f2cb3f9776
```

> 📌 **不要把 `npm run hash:contract` 当作普通检查。** 它会重写 `contract/manifest.json`，只应在四棵共享树发生经过批准的有意变更后使用；日常验证使用 `npm run check:contract`。

### 无模型加载检查

可用 RPC 模式确认 Extension 注册，不会触发模型调用：

```bash
./node_modules/.bin/pi \
  --mode rpc \
  --no-session \
  --no-extensions \
  -e /path/to/pi-evidence-gated-change/src/extension.ts \
  --no-skills
```

进程启动后输入：

```json
{"type":"get_commands"}
```

响应应包含：

```text
egc-start
egc-status
egc-approve
egc-reject
egc-resume
egc-cancel
dw-run
dw-result
dw-status
dw-list
dw-cancel
dw-models
skill:evidence-gated-change
```

Pi 自带的 `llama` 命令可能同时出现，它不属于本项目。输入 `Ctrl-D` 退出 RPC。

## 📦 加载 Extension

两种加载方式使用同一个精确的本地 Pi 0.84.2 binary。首次实践建议使用 direct `-e`；需要在另一个可信 Pi 项目中长期注册时，再使用 package-local 方式。

### 方式一：direct `-e`

```bash
cd /path/to/pi-evidence-gated-change
./node_modules/.bin/pi \
  --no-extensions \
  -e /path/to/pi-evidence-gated-change/src/extension.ts
```

`--no-extensions` 先关闭其他外部 Extension，再由 `-e` 显式加载本项目；本项目仍会通过 `resources_discover` 注册 `skill:evidence-gated-change`。

### 方式二：package-local

以下命令要在一个单独的、可信的 Pi consumer 项目中执行：

```bash
cd /absolute/path/to/trusted-pi-consumer

PI_CODING_AGENT_DIR=/absolute/path/to/isolated-pi-home \
  /path/to/pi-evidence-gated-change/node_modules/.bin/pi \
  install -l /path/to/pi-evidence-gated-change --approve

PI_CODING_AGENT_DIR=/absolute/path/to/isolated-pi-home \
  /path/to/pi-evidence-gated-change/node_modules/.bin/pi --approve
```

边界如下：

- `-l` 把包路径记录到 consumer 项目的 `.pi/settings.json`
- `/path/to/pi-evidence-gated-change` 内不会生成 `.pi` 配置
- `--approve` 表示显式信任 project-local 代码，不能对不可信目录盲目使用
- 无论从哪个 consumer 启动，运行产物仍写入 Extension 项目的 `runs/`

该路径已在隔离的 `PI_CODING_AGENT_DIR` 下做过加载 smoke：六个 `egc-*`、六个 `dw-*` 命令和 Skill 均由 package entry 注册成功。

## Dynamic Workflow v1 实践

Dynamic Workflow 与 EGC 是两条独立路径。它不修改 `fixtures/todo-service`，不使用 EGC 的审批、Repair 或 resume 状态机。

默认 saved workflow 是：

```text
dynamic-workflow/shared/workflows/multi-model-review.js
```

脚本第一行必须严格为单行 JSON literal：

```javascript
export const meta = {"name":"...","description":"..."};
```

正文只使用公共能力 `agent`、`parallel`、`pipeline`、`phase`、`log` 和 `args`。`multi-model-review` 先并行运行 fast、deep、review 三个 profile；至少两个独立 Review 成功后才逐项挑战，至少两个 Challenge 成功后才由 review profile 汇总非空纯文本结果，否则整个 run 以 `failed` 收敛。

### 配置模型 profile

Pi 配置位于：

```text
dynamic-workflow/pi/model-profiles.json
```

当前随项目提交的三个 profile 都显式选择 `zai-coding-cn/glm-5.2`，并分别使用 `low`、`high`、`medium` thinking。若把某个 profile 改成空对象 `{}`，它会继承启动 `/dw-run` 时 Pi 的当前 provider、model 和 thinking；要明确使用不同模型，可填写 provider/model 和可选 thinking。不要写入 API Key：

```json
{
  "profiles": {
    "fast": { "provider": "provider-id", "model": "fast-model", "thinking": "low" },
    "deep": { "provider": "provider-id", "model": "deep-model", "thinking": "high" },
    "review": { "provider": "provider-id", "model": "review-model", "thinking": "medium" }
  }
}
```

运行前查看实际解析结果：

```text
/dw-models
/dw-list
```

### 配置超时预算

同一个 `dynamic-workflow/pi/model-profiles.json` 还定义三层互相独立的超时：

```json
{
  "limits": {
    "agentIdleTimeoutMs": 120000,
    "agentTimeoutMs": 240000,
    "runTimeoutMs": 900000
  }
}
```

| 配置项 | 当前值 | 含义 |
| --- | ---: | --- |
| `agentIdleTimeoutMs` | 120,000 ms（2 分钟） | 单个子 Agent 的无活动看门狗；解析到 Pi 子进程 stdout 中的 JSON/event 数据时重新计时，stderr 不会续期 |
| `agentTimeoutMs` | 240,000 ms（4 分钟） | 单个子 Agent 从启动开始计算的硬上限；即使持续活跃也不会续期 |
| `runTimeoutMs` | 900,000 ms（15 分钟） | 整个 Workflow 的硬上限，包含所有阶段、排队、重试、持久化和最终汇总 |

所以“活动会续期”只适用于 idle 窗口：只要 Agent 仍在 stdout 产生可解析的 JSON/event 进展，就不会因为总耗时刚超过两分钟而被误杀；普通 stderr 输出不算活动，不能让卡住的子进程无限存活。Agent 仍必须在四分钟的 Agent hard cap 之前结束，并且所有工作都不能突破十五分钟的 Workflow hard cap。任一时刻总是更严格、先到达的限制生效。

配置加载时强制满足 `agentIdleTimeoutMs <= agentTimeoutMs <= runTimeoutMs`，三者都必须是允许范围内的正整数；预算次序不一致会在任何 Agent 启动之前直接报错。每条 `agent-start` 事件也会记录该 Agent 实际收到的 idle 与 hard timeout，便于事后核对本次 run 是否加载了新版配置。

`multi-model-review` 的三阶段预算可按下面理解：

1. `independent-reviews`：三名 Reviewer 并行，每名最多 4 分钟，因此该阶段的墙钟预算约为 4 分钟，而不是 `3 × 4` 分钟。
2. `challenge-reviews`：对成功初审并行质疑，每名最多 4 分钟，墙钟预算再约 4 分钟。
3. `synthesis`：最终汇总 Agent 最多 4 分钟。

三段 Agent hard cap 合计最多约 12 分钟；十五分钟总预算剩余约 3 分钟，用于阶段切换、落盘和 provider retry 等开销，不会额外增加任何单 Agent 的四分钟上限。若模型在某一阶段持续无输出超过两分钟，idle watchdog 会提前结束它；若某阶段或重试已经消耗过多，总 Workflow deadline 也可能先于后续 Agent hard cap 到达。

### 前台运行、实时进度与查看产物

```text
/dw-run multi-model-review 分析当前项目中最值得优先修复的三个架构风险
```

`/dw-run` 会一直等待本次 Workflow 到达 `completed|failed|cancelled`，不再把任务静默留在后台。执行期间，编辑器上方的 Widget 会实时显示：

- `runId`、`status` 和当前 `phase`
- Agent 的 `started`、`successful`、`failed`、`active` 计数
- 最近五条 Agent start、retry 和 end 事件
- retry 的 attempt、等待秒数和经过脱敏、截断的 provider 错误

TUI 中可按一次 `Esc` 取消当前前台 run；即使在 run 目录初始化、尚未返回 `runId` 的短窗口内按下，取消请求也会被记住，并在拿到 `runId` 后立即执行。命令 handler 等待期间无需再输入另一条 `/dw-cancel`。RPC 模式仍会通过公开的 `setWidget`、`setStatus` 事件发送进度，但没有终端按键取消能力。`json` 和 `print` 模式会在创建 run、启动 Agent 或解析模型前明确拒绝 `/dw-run`，不会退化成不可见的后台任务。所有 Widget、status、working message 和终端监听都会在 `finally` 中清理。

成功时 Extension 会通过 Pi 官方 `appendEntry + registerEntryRenderer` 向主 transcript 追加结果卡，直接显示 `runId`、workflow、`6/7` 一类 Agent 成功/失败计数、`failureCauses`、纯文本结果预览和 `result.json` 绝对路径。TUI 用 Box/Text 渲染结果卡；RPC 同时收到结构化 `entry_appended` 事件和有界 `notify`，通用 RPC 页面无需理解自定义 renderer 也能显示结果。custom entry 不进入 LLM 上下文。若 Pi 已经生成 Session 文件（例如该 Session 已有 assistant 回复），条目会随 Session 保存并在重新加载后恢复；但 Pi 0.84.2 对“全新、只有 slash command、从未产生 assistant 回复”的 Session 不创建 Session 文件，这种特殊情况下结果卡本身不能跨重启保存，需要用 `/dw-result [runId]` 从权威 `result.json` 无模型重建。脱敏后的页面预览最多 12,000 字符；发生截断时卡片会明确提示。若追加 Session 条目失败，Workflow 仍保持 `completed`，界面会回退为有界 warning 通知。失败或取消的 run 不创建结果卡；失败通知仍会同时显示 Workflow 顶层错误和各 Agent 的底层根因。

每个 Pi 子进程都会收到精确的 `provider/model`、可选 thinking，以及固定的只读工具集合 `read,grep,find,ls`。普通临时 429 仍按 Pi 策略重试。只有错误同时包含“使用上限/用量上限/额度用尽/usage limit/quota exceeded”等明确额度语义，并且伴随 `code 1308` 或 HTTP `429` 时，Runner 才会停止该子进程，避免继续等待 2+4+8 秒的无意义退避；单独出现 `code 1308` 或普通临时 429 都不会触发提前终止。

### 超时失败的诊断与重跑

因超时而未满足 Workflow 门禁的 run 会收敛为 `failed`，不会生成 `result.json`，也不能从失败点续跑。单个 Agent 超时不一定让整个 run 失败：如果剩余成功结果仍满足最低成功数，后续阶段可以继续。界面里先出现 Agent 根因、随后出现 `requires at least two...` 时，后者只是最低成功数不足的上层门禁结果；应先处理前面的超时根因。

先复制界面中的 `runId`，在另一个终端检查：

```bash
cd /path/to/pi-evidence-gated-change
DW_RUN_ID='替换为界面中的 dw-...'

jq '{status,currentPhase,agentsStarted,agentsCompleted,activeAgents,error,failureCauses}' \
  "dynamic-workflow/runs/${DW_RUN_ID}/state.json"

tail -n 80 "dynamic-workflow/runs/${DW_RUN_ID}/events.jsonl"
```

按诊断文字区分三类情况：

| 根因 | 表示什么 | 建议 |
| --- | --- | --- |
| `Dynamic agent idle timed out after 120000ms without valid stdout JSON activity` | 单个 Agent 连续 2 分钟没有产生有效 stdout JSON/event 活动 | 先检查 provider 是否卡住；缩小分析文件范围或提示词，再创建新 run |
| `Dynamic agent reached the 240000ms absolute hard timeout` | Agent 虽可能持续工作，但触达不可续期的单 Agent 上限 | 缩小任务范围，减少一次要求的证据量，或选择更快的 profile 后重跑 |
| `Dynamic Workflow timed out` / 整体 deadline | 三阶段、排队与重试合计触达 15 分钟 | 检查是否有 provider retry、阶段膨胀或过多 Agent；不要只提高单 Agent 上限 |

确认原因后，在 Pi 中重新执行一条新的命令；失败的 run 保留为证据，不要删除或手工把状态改回 `running`：

```text
/dw-run multi-model-review 只审查 src/dynamic-engine.ts、src/dynamic-runner.ts 和 src/dynamic-ui.ts，给出三个风险及 file:line 证据
```

重跑会产生新的 `runId`。运行中应看到 Agent 在两分钟之后仍有有效 stdout JSON/event 活动时继续执行，但任何单个 Agent 到四分钟 hard cap 都会收到终止信号；不合作的子进程最多再经过默认五秒 grace 后被强制结束。整个 Workflow 到十五分钟 hard cap 会触发整体终止，随后等待活动子进程清理。成功后界面自动显示结果卡，并生成 `result.json`。如需进一步调整预算，应同时评估三层限制，避免只放宽其中一层而被另一层先截断。

查看状态或取消当前进程内的活动 run：

```text
/dw-status
/dw-status {runId}
/dw-cancel {runId}
```

重新把最近一次或指定的已完成结果显示到主 transcript，不会调用模型，也不会改写 `result.json`：

```text
/dw-result
/dw-result {runId}
```

显式指定 `failed`、`cancelled` 或尚未完成的 run 会直接报错。`/dw-status [runId]` 只显示状态通知，不会覆盖或替换已经持久化的结果卡。

产物位于：

```text
dynamic-workflow/runs/{runId}/
├── workflow.js
├── state.json
├── events.jsonl
└── result.json
```

- `workflow.js` 是本次执行的精确脚本快照。
- `state.json` 包含 `queued|running|completed|failed|cancelled`、当前 phase、Agent 计数和去重后的 `failureCauses`。
- `events.jsonl` 包含单调 sequence 的 phase、log、Agent start/retry/end 和状态事件；持久化诊断会脱敏、去重和截断，不写入原始 stderr。
- `result.json.value` 是最终纯文本 synthesis。

上述“不写入原始 stderr”和新增脱敏规则只适用于加载本版本 Extension 后创建的新 run。历史 `dynamic-workflow/runs/` 是审计证据，不会被自动改写或删除；旧版 `events.jsonl` 可能仍含 `details.stderr`，查看、复制或分享旧产物前应按敏感数据处理。

`/dw-status [runId]` 仍可查看当前或历史状态；`/dw-cancel <runId>` 仍适用于 RPC 调用或同进程中由其他入口控制活动 run。已有 Session 文件中的结果卡可以跨 Session 恢复，但执行状态机不能跨 Session resume；slash-only 新 Session 的 Pi 0.84.2 持久化边界见上文。V1 不支持 approval、跨 Session resume 或跨进程 cancel。关闭当前 Pi 进程会取消其仍在运行的 Agent；新 Session 可以查看已经持久化的结果卡或用 `/dw-result` 从磁盘重新显示旧的 completed 结果，但不能继续旧脚本。

## 🎯 真实模型人工流程

本节会真实调用当前 Pi 模型。自动化测试没有执行这一节；运行前请确认模型、费用和凭据边界符合你的预期。

先确认项目本地 Pi 能看到你准备使用的模型：

```bash
cd /path/to/pi-evidence-gated-change
./node_modules/.bin/pi --list-models
```

凭据继续使用你原有的 Pi provider 配置或当前 shell 的安全注入方式，不要把 API Key 写进本仓库，也不要把密钥直接放进可复制的启动命令。需要固定模型时可这样启动：

```bash
PI_EGC_MODEL='provider/model-id'
./node_modules/.bin/pi \
  --model "$PI_EGC_MODEL" \
  --no-extensions \
  -e /path/to/pi-evidence-gated-change/src/extension.ts
```

把 `provider/model-id` 替换为 `--list-models` 中实际可用的条目；不传 `--model` 时使用 Pi 当前配置的模型。

### 启动并获得审批材料

在已加载 Extension 的 Pi 交互界面输入：

```text
/egc-start
```

命令不接受路径参数。正常情况下，Code Scout 与 Test Scout 并行完成，Planner 随后生成计划，界面返回类似：

```text
run=egc-20260817xxxxxx-1234abcd
phase=awaiting_approval
planHash=<64 位 SHA-256>
approvalHash=<64 位 SHA-256>
repair=0/1
artifacts=/path/to/pi-evidence-gated-change/runs/egc-.../
```

如果 `phase` 不是 `awaiting_approval`，先查看该 run 的 `report.md`、`state.json` 和 `events.jsonl`，不要直接审批。

### 审阅计划和发现证据

将下面的 `EGC_RUN_ID` 替换为界面返回的真实 runId：

```bash
cd /path/to/pi-evidence-gated-change
EGC_RUN_ID=egc-20260817xxxxxx-1234abcd

sed -n '1,240p' "runs/${EGC_RUN_ID}/discovery-code.json"
sed -n '1,240p' "runs/${EGC_RUN_ID}/discovery-tests.json"
sed -n '1,240p' "runs/${EGC_RUN_ID}/plan.json"
sed -n '1,240p' "runs/${EGC_RUN_ID}/baseline.json"
```

批准前至少确认：

- `plan.json.files` 恰好是 `README.md`、`src/TodoService.ts`、`test/TodoService.test.ts`
- `plan.json` 覆盖同 requestId 冲突字段、不同 requestId 同标题、空白值、防御性复制和 ID 序列
- `planHash` 与 Pi 状态提示一致
- 你将使用的是 `approvalHash`，而不是 `planHash`

`approvalHash` 绑定 `planHash`、`baselineHash`、`contractHash` 和 `runtimeHash`。审批时系统会重新计算并检查四者，同时要求 worktree 仍等于基线。

### 批准或拒绝

批准时，在同一 Pi session branch 输入真实值：

```text
/egc-approve {runId} {approvalHash}
```

拒绝时输入：

```text
/egc-reject {runId} {approvalHash} 不接受当前计划
```

不要把花括号原样输入；将它们替换为实际值。`approve` 会进入隔离 worktree 实现、语义审查和固定验证；`reject` 直接进入 `rejected`，不会执行实现阶段。

### 判断完成结果

批准路径的理想终态为：

```text
phase=completed
repair=0/1
```

如果首次门禁失败，系统最多自动授权一次 Repair，此时成功结果可能显示 `repair=1/1`。`completed` 必须同时满足：

- `review.json.verdict` 为 `pass`
- `verification.json.passed` 为 `true`
- 三条固定验证命令的 `exitCode` 全部为 `0`
- `verification.json.policyViolations` 为空
- `verification.json.baselineHashUnchanged` 为 `true`
- 实际变更文件与批准的三个文件完全一致

查看最终摘要和证据：

```bash
sed -n '1,260p' "runs/${EGC_RUN_ID}/report.md"
sed -n '1,320p' "runs/${EGC_RUN_ID}/review.json"
sed -n '1,400p' "runs/${EGC_RUN_ID}/verification.json"
```

门禁在唯一一次 Repair 后仍失败时，终态为 `blocked`，不会被 Reviewer 的文字结论覆盖。

## 🔄 状态、恢复与取消

### 查看状态

```text
/egc-status
/egc-status {runId}
```

不带参数时显示当前 branch 最近的 run；带 runId 时可读取磁盘状态。状态输出包含 `run`、`phase`、`planHash`、`approvalHash`、Repair 次数和产物目录。

### 恢复中断 run

```text
/egc-resume {runId}
```

恢复会先校验共享契约、runtime adapter、基线、计划和已批准回执，再从最后可安全收敛的位置继续。持久化的 settlement 事件比 stale `state.json` 更权威；恢复不会为同一个 operation 重复写 settlement。

`awaiting_approval`、`completed`、`blocked`、`rejected` 和 `cancelled` 不会由 `resume` 自动前进。等待审批时必须明确执行 `approve` 或 `reject`。

### 取消 run

```text
/egc-cancel {runId}
```

同一 Extension 实例中的活动任务会收到 abort；中断后取消会先收敛未完成 intent，再进入 `cancelled`。子 Agent 先收到 `SIGTERM`，五秒后仍不退出则升级为 `SIGKILL`。

### Session branch 约束

`approve`、`reject`、`resume` 和 `cancel` 只允许操作当前 Pi session branch 中出现过的 run。重新打开时应恢复原 Pi session/branch；在全新 session 中即使磁盘文件存在，变更命令也会报：

```text
Run {runId} is not present on the active Pi session branch
```

显式 `/egc-status {runId}` 可用于只读诊断，但不能绕过 branch 变更门禁。

## 💾 产物与预期字段

所有路径均相对于 `runs/{runId}/`。产物是否存在取决于 run 到达的阶段；例如人工拒绝不会产生实现、Patch、审查或验证产物。

| 产物 | 生成阶段 | 关键字段或含义 |
| --- | --- | --- |
| `state.json` | 全程 | `phase`、四类哈希、`repairCount`、`maxRepair`、可选 `pendingOperation`/错误原因 |
| `events.jsonl` | 全程 | 单调 `sequence`；`state`、`intent`、`settled`、`agent`、`gate` 事件；settlement 含 committed state |
| `baseline/`、`worktree/` | 基线捕获 | 不可变基线与唯一允许修改的隔离副本 |
| `baseline.json` | 基线捕获 | `baselineHash`、`contractHash`、`runtimeHash`、`capturedAt` |
| `discovery-code.json`、`discovery-tests.json` | 并行发现 | `summary`、`files[{path,reason}]`、`risks` |
| `plan.json` | 规划 | `summary`、精确三文件、`steps`、`tests`、`risks`、`planHash` |
| `approval.json` | 批准或拒绝 | 四类绑定哈希、`approvalHash`、`decision`、`decidedAt`、可选 `reason` |
| `implementation.json`、可选 `repair.json` | 实现/修复 | `summary`、`filesChanged`；只能声明三个批准文件 |
| `patch.diff` | 实现与复核 | 基线到 worktree 的实际二进制安全 Git diff |
| `review.json` | 语义审查 | `verdict`、`summary`、`findings[{severity,message,path?}]` |
| `verification.json` | 固定验证 | `passed`、三条命令收据、精确变更文件、策略违规、基线完整性 |
| `typecheck-request-id.ts` | 固定验证 | 验证 `requestId` 在公开 TypeScript 输入类型中为必填 |
| `report.md` | 终态 | phase、四类哈希、Repair 次数、错误/终态原因和证据索引 |

`verification.json.commands` 的顺序固定为：

1. 在 permission mode 下直接运行 Agent 修改后的项目测试
2. 在独立 permission mode 下运行可信外部 Oracle
3. 运行 TypeScript compile-time API probe

每条命令收据包含 `command`、`args`、`exitCode`、`stdout`、`stderr` 和 `durationMs`。Agent 的文字说明不是验证证据。

## 📊 能力与验证命令对应表

| 能力 | 最小验证命令 | 成功标准 |
| --- | --- | --- |
| TypeScript 与共享契约 | `npm run check` | `tsc --noEmit` 和 manifest 通过 |
| 确定性 reducer | `node --experimental-strip-types --test test/reducer.test.ts` | 合法转换通过、终态不可继续 |
| JSON Schema 执行 | `node --experimental-strip-types --test test/schema.test.ts` | `additionalProperties`、唯一性、最小项约束生效 |
| Pi 子进程协议 | `node --experimental-strip-types --test test/pi-runner.test.ts` | JSONL、终态和强制终止测试通过 |
| 审批、Repair、验证、恢复 | `node --experimental-strip-types --test test/workflow.test.ts` | 8 项 workflow 测试通过 |
| Dynamic Workflow v1 | `node --experimental-strip-types --test test/dynamic-workflow.test.ts` | 26 项 parser、DSL 默认语义、profile、前台 TUI/RPC 进度、custom 结果卡与重载 renderer、无模型 `/dw-result`、append fallback、Esc cancel、retry/硬配额、脱敏根因、idle/hard/run 三层超时、活动续期、取消优先级、畸形事件、中文 UTF-8 分块、cap、Worker 强制终止、终态入口关闭、最低成功条件、artifact 和 CLI runner 测试通过 |
| 全部无模型测试 | `npm test` | 原 16 项 EGC + 26 项 Dynamic Workflow，共 42 项通过 |
| 共享四树一致性 | `npm run check:contract` | 输出 canonical 哈希且无 drift |
| Dynamic shared script | `npm run check:dynamic` | 输出独立 aggregate 且无 drift |
| 依赖漏洞快照 | `npm audit --json` | 当前锁文件漏洞总数为 `0` |
| Direct Extension 注册 | RPC `get_commands` | 六个 EGC、六个 DW 命令和 Skill 可见 |
| Package-local 注册 | 隔离目录 `pi install -l ... --approve` 后启动 Pi | package entry 注册六个 EGC、六个 DW 命令和 Skill |

## 🧪 故障注入测试

测试套件使用 fake Agent 或真实 stub 子进程，不会调用模型。主要注入点如下：

| 注入场景 | 测试位置 | 预期行为 |
| --- | --- | --- |
| Scout 返回非法 JSON | `test/workflow.test.ts` | 审批前进入 `blocked`，不写实现 |
| 一个 Scout 非法、另一个挂起 | `test/workflow.test.ts` | 立即 abort 并 drain sibling，不等待 120 秒 |
| 规划后 runtime adapter 漂移 | `test/workflow.test.ts` | `approve` 拒绝哈希不一致 |
| Reviewer 声称通过但 Oracle 失败 | `test/workflow.test.ts` | Reviewer 不能覆盖真实失败，最多 Repair 一次后阻塞 |
| Agent 测试尝试写外部文件、启动子进程、联网 | `test/workflow.test.ts` | 直接调用以权限错误失败，外部文件不存在 |
| 并行发现期间取消 | `test/workflow.test.ts` | 两个 sibling 均终止，状态收敛为 `cancelled` |
| settlement 已落盘但 state stale | `test/workflow.test.ts` | 从事件恢复 committed state，不重复 settlement |
| 子进程输出非法 JSON、缺终态、非零或 `length` | `test/pi-runner.test.ts` | 各失败类型被区分且 fail closed |
| 子进程忽略 `SIGTERM` | `test/pi-runner.test.ts` | grace period 后 `SIGKILL` |
| 超时后合作式返回 `stop/0` | `test/pi-runner.test.ts` | 仍按超时失败，不接受迟到成功 |
| Saved script meta 非严格 JSON、静态 import 或非 JSON 可物化结果 | `test/dynamic-workflow.test.ts` | 在调用真实模型前或结果落盘前 fail closed |
| Agent 总量超限 | `test/dynamic-workflow.test.ts` | abort 并 drain 已活动 fake Agent，终态为 `failed` |
| Dynamic Workflow 运行中取消 | `test/dynamic-workflow.test.ts` | 同进程活动 Agent 全部收到 abort，终态为 `cancelled` |
| `/dw-run` 前台执行与 Esc 取消 | `test/dynamic-workflow.test.ts` | TUI/RPC 实时进度可见；TUI 的 Esc 在 command handler 等待期间直接取消；所有 UI 状态最终清理 |
| 临时 429 与 `code 1308` 硬配额 | `test/dynamic-workflow.test.ts` | 临时 429 保留重试；明确硬配额立即停止当前 child；attempt/delay/脱敏诊断可见 |
| 非额度语义的 `code 1308` | `test/dynamic-workflow.test.ts` | 不提前终止 child，允许后续重试恢复成功 |
| `json/print` 调用 `/dw-run` | `test/dynamic-workflow.test.ts` | 在 `engine.start` 前 fail loud，Agent/模型调用数保持 0 |
| Agent 错误包含凭据形态 | `test/dynamic-workflow.test.ts` | 最终通知同时保留 provider 根因和 Workflow gate 错误，但 state/event/页面均不含原始 secret |
| Saved script 在 `await` 后进入死循环 | `test/dynamic-workflow.test.ts` | 宿主 deadline 终止整个 Worker，Pi 主事件循环保持可用，终态为 `failed` |
| Review 未达到最低成功数或最终汇总失败 | `test/dynamic-workflow.test.ts` | 不产出伪成功结果，终态为 `failed` |
| Script 返回后 Promise 链请求迟到 Agent | `test/dynamic-workflow.test.ts` | 终态关闭 Worker 消息入口，迟到 Agent 不会启动，也不会在 `completed` 后改写事件或计数 |

只运行故障注入相关测试：

```bash
node --experimental-strip-types --test test/pi-runner.test.ts test/workflow.test.ts
```

## ⚠️ 排障与已知限制

### 常见错误

| 现象或错误 | 原因 | 处理方式 |
| --- | --- | --- |
| `Required Node permission scopes are unavailable` | Node 版本低于 25 或缺少所需作用域 | 切换到 Node 25，再运行 `npm ci --ignore-scripts` |
| `Expected local Pi 0.84.2` | 本地 Pi 缺失或版本漂移 | 删除手工安装偏差并用锁文件重新执行 `npm ci --ignore-scripts` |
| `Approval hash mismatch` | 使用了 `planHash`、复制错误或状态已变化 | 从 `/egc-status` 重新复制 `approvalHash` |
| `Contract... changed` 或 `Runtime adapter... changed` | 等待审批期间代码或契约发生变化 | 不继续旧审批，重新 `/egc-start` |
| `not present on the active Pi session branch` | 在新的 session/branch 操作旧 run | 恢复原 session branch；新 session 仅做只读诊断 |
| `phase=blocked` | Agent、Schema、门禁、权限或恢复检查失败 | 先读 `report.md`、`state.json`、`verification.json` 和 `events.jsonl` |
| `multi-model-review requires at least two...`，但页面同时出现 `429/code 1308/使用上限` | 三个独立 Review 因 provider 五小时用量上限全部失败，quorum 错误只是上层结果 | 等 provider 提示的重置时间，或在 `model-profiles.json` 切换到仍有额度的 profile；无需修改 Workflow |
| `multi-model-review requires at least two...`，且 `failureCauses` 包含 `idle timed out` 或 `absolute hard timeout` | 独立 Review 因单 Agent 空闲或硬上限失败，quorum 错误只是后果 | 按“超时失败的诊断与重跑”检查事件；缩小任务或调整 profile 后创建新 run |
| `Dynamic Workflow timed out` | 整个 run 的阶段、排队和重试合计达到 15 分钟硬上限 | 查看 `events.jsonl` 的最后阶段和 retry；排除卡住的 provider 或缩小工作流后重跑 |
| `Shared contract manifest drift` | 四棵共享树与 manifest 不一致 | 先确认是否为有意变更；未经批准不要重算 manifest |

### 安全边界

Node Permission Model 在这里是 defense in depth，不是恶意代码 sandbox。Node 官方将其定位为 “seat belt”，并明确它不能作为对抗恶意代码的安全边界。[^1] 本实验只证明测试中列举的直接 `writeFileSync`、`execFileSync` 和 `fetch` 尝试在当前参数下被拒；不要用它执行刻意恶意、与当前用户同 UID 的不可信代码。

Dynamic Workflow 在专用 Worker 内运行 `node:vm`：VM 提供同步执行 timeout，宿主还可在总 deadline 或取消时终止整个 Worker，包括在 `await` 后才出现的死循环。但 Worker 与 `node:vm` 都不是安全边界。虽然脚本上下文不直接提供 `require`、`import`、`process`、文件系统或 Shell global，它仍只适合运行经过审阅、保存在本地的受信脚本，不能用于隔离恶意 JavaScript。

### 运行限制

- **没有自动 live-model E2E**：42 项测试都是 fake Agent 或 stub 子进程；真实模型流程必须由操作者人工执行和验收
- **没有跨进程同 run 锁**：`controllers` 和活动任务表只存在于单个 Extension 进程；不要让两个 Pi 进程同时操作同一个 runId，否则 `state.json`、`events.jsonl` 和序号可能竞争
- **没有通用仓库入口**：`/egc-start` 固定使用 TodoService fixture，传入路径会被拒绝
- **没有可替换 Pi Agent Loop**：Pi 0.84.2 无公开 `shouldStopAfterTurn` 或 Loop 替换 API，本实现由 Extension 编排独立 Pi 子进程
- **没有全局安装回退**：子 Agent 只使用项目本地 Pi 0.84.2；缺失时直接失败
- **变更命令受 branch 限制**：磁盘产物可诊断，但不能从无关的新 Pi branch 批准或恢复旧 run
- **Dynamic Workflow 执行不跨 Session 恢复**：已有 Session 文件时结果卡会持久化；slash-only 新 Session 可用 `/dw-result` 重建，但 V1 没有 approval 或跨 Session resume，`/dw-cancel` 也只控制当前 Pi 进程中的活动 run
- **Dynamic Workflow 不覆盖 maxTokens**：V1 支持逐 Agent provider/model/thinking 与固定只读 tools，但没有逐 Agent `maxTokens` 参数
- **Saved workflow 是受信代码**：Worker 可被强制终止，VM 也有同步 timeout，但二者都不能成为恶意代码 sandbox

---

[^1]: Node.js. “Permissions.” https://nodejs.org/api/permissions.html

_最后验证：2026-08-18 · macOS · Node v25.9.0 · Pi 0.84.2_
