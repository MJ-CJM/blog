# DSH Harness 实验源码附件

- 快照日期：2026-08-20
- 实验版本：DeepSeek Harness `0.1.0-rc.6`，Cordis `4.0.1`
- 对应文章：`同样叫 Agent Harness，Pi 和 DeepSeek Harness 把调度权交给了谁？`

## 包含内容

本附件保留 DSH 侧实验的源码、测试、Skill、模型路由示例、saved workflow、配置补丁与中文运行手册，覆盖 Stock、Adapter、Full Custom Loop 和 Dynamic Workflow 四部分实现。

## 已排除内容

为避免泄露本机信息并控制附件体积，压缩包不含：

- `node_modules`、构建输出（`lib`、`dist`、`build`、`coverage`）和本地锁文件；
- `.git`、IDE 元数据、`.agents` 运行目录；
- `lab-home`、Session、运行收据、Profile dump、日志、缓存和环境变量文件；
- 任何凭据、匿名用户标识或本机生成的 Web 配置。

源码和文档中的本机绝对路径已统一替换为 `/path/to/...` 示例路径。运行前请按实际目录调整配置。

## 重要边界

这是研究实验快照，不是生产发布，也不保证下载后零配置运行。DSH `0.1.0-rc.6` 的插件装载依赖 Cordis/DSH 包实例保持单例身份；若把插件链接到另一份 Runtime 源码树，可能遇到依赖实例不一致。Full Custom Loop 还使用了实验性内部 seam，后续版本可能变化。

`package.json` 中原先指向作者本地 Runtime 的 `link:` 依赖已改成公开版本号：Cordis 使用 `4.0.1`，其他 DSH 包使用 `0.1.0-rc.6`。这只完成公开快照脱敏，不等同于重新验证了全新机器安装流程。

本附件未包含第三方依赖源码；所有依赖仍遵守各自的上游许可证。本实验目录未附单独的开源许可证，公开复用前应由作者补充或确认授权范围。
