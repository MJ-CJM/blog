import { readFile, readdir, rm, mkdtemp } from 'node:fs/promises'
import { createRequire } from 'node:module'
import { tmpdir } from 'node:os'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'

import { Context, type Fiber } from '@deepseek-ai/cordis'
import AgentRegistry, { type Agent, type AgentHandle } from '@deepseek-ai/dsh-agent'
import {
  CallId,
  LlmAdapter,
  LlmRuntime,
  createUserMessage,
  type GenerateOptions,
  type LlmResolvedModelInfo,
  type StreamChunk,
} from '@deepseek-ai/dsh-llm'
import SessionStore, { SessionId, SessionPreparation, type SessionEvent } from '@deepseek-ai/dsh-session'
import JsonlSessionPersistence from '@deepseek-ai/dsh-session-persistence-jsonl'
import SystemPrompt from '@deepseek-ai/dsh-system-prompt'
import ToolRuntime, { defineTool } from '@deepseek-ai/dsh-tools'
import * as ts from 'typescript'
import { afterEach, describe, expect, it } from 'vitest'

import FullCustomLoopService, {
  BudgetedPlanActReflectAgent,
  FULL_CUSTOM_LOOP_ALGORITHM,
  FULL_CUSTOM_LOOP_IMPLEMENTATION,
  assertFullCustomConfig,
  type FullCustomLoopConfig,
} from '../packages/agent-loop-full-custom/src/index.js'
import { FullLoopContextProjection } from '../packages/agent-loop-full-custom/src/context-projection.js'

type ScriptEntry = readonly StreamChunk[] | 'hang'

interface TraceRow {
  event: string
  phase?: string
  tool?: string
  outcome?: string
}

interface Harness {
  ctx: Context
  adapter: ScriptedAdapter
  traceRoot: string
  loopFiber: Fiber
}

const PROJECT_ROOT = fileURLToPath(new URL('../', import.meta.url))
const FULL_CUSTOM_PACKAGE = join(PROJECT_ROOT, 'packages', 'agent-loop-full-custom')
const FULL_CUSTOM_SOURCE = join(FULL_CUSTOM_PACKAGE, 'src')
const require = createRequire(import.meta.url)
const cleanups: Array<() => Promise<void>> = []

function textResponse(text: string): StreamChunk[] {
  return [
    { type: 'block-start', index: 0, blockType: 'text' },
    { type: 'text-delta', index: 0, text },
    { type: 'block-end', index: 0, block: { type: 'text', text } },
    { type: 'usage', usage: { inputTokens: 1, outputTokens: 1 } },
    { type: 'finish', reason: { kind: 'stop' } },
  ]
}

function toolCallResponse(rawCallId: string, name: string, args: object): StreamChunk[] {
  const id = CallId(rawCallId)
  const raw = JSON.stringify(args)
  return [
    { type: 'block-start', index: 0, blockType: 'tool-call' },
    { type: 'tool-call-delta', index: 0, id, name, argumentsDelta: raw },
    { type: 'block-end', index: 0, block: { type: 'tool-call', id, name, arguments: raw } },
    { type: 'usage', usage: { inputTokens: 1, outputTokens: 1 } },
    { type: 'finish', reason: { kind: 'tool-calls' } },
  ]
}

class ScriptedAdapter extends LlmAdapter {
  readonly requests: GenerateOptions[] = []
  readonly firstRequestStarted: Promise<void>
  private readonly markFirstRequestStarted: () => void

  constructor(private readonly script: ScriptEntry[]) {
    super()
    let resolveStarted: (() => void) | undefined
    this.firstRequestStarted = new Promise<void>(resolve => { resolveStarted = resolve })
    this.markFirstRequestStarted = () => resolveStarted?.()
  }

  override resolveModel(provider: string, model: string): Promise<LlmResolvedModelInfo> {
    return Promise.resolve({ provider, id: model, name: model })
  }

  override async *stream(options: GenerateOptions): AsyncIterable<StreamChunk> {
    this.requests.push(options)
    this.markFirstRequestStarted()
    const entry = this.script.shift()
    if (entry === undefined) throw new Error('ScriptedAdapter: script exhausted')
    if (entry === 'hang') {
      await new Promise<never>((_resolve, reject) => {
        const abort = (): void => reject(options.signal?.reason ?? new Error('aborted'))
        if (options.signal?.aborted) abort()
        else options.signal?.addEventListener('abort', abort, { once: true })
      })
      return
    }
    for (const chunk of entry) {
      options.signal?.throwIfAborted()
      yield chunk
    }
  }
}

function config(traceRoot: string, overrides: Partial<FullCustomLoopConfig> = {}): FullCustomLoopConfig {
  return {
    agents: [],
    maxCycles: 3,
    maxModelCalls: 8,
    maxToolCalls: 4,
    subagentMaxModelCalls: 12,
    subagentMaxToolCalls: 8,
    maxTurnMs: 10_000,
    planMaxTokens: 256,
    maxRetriesPerPhase: 1,
    subagentMode: 'direct-budgeted',
    traceRoot,
    ...overrides,
  }
}

async function harness(
  script: ScriptEntry[],
  overrides: Partial<FullCustomLoopConfig> = {},
  persistenceRoot?: string,
): Promise<Harness> {
  const traceRoot = await mkdtemp(join(tmpdir(), 'dsh-full-loop-test-'))
  const ctx = new Context()
  const adapter = new ScriptedAdapter([...script])
  cleanups.push(async () => {
    await ctx.fiber.dispose()
    await rm(traceRoot, { recursive: true, force: true })
  })
  await ctx.plugin(LlmRuntime)
  await ctx.plugin(SessionStore)
  await ctx.plugin(SystemPrompt, { persona: 'Full Custom Loop test harness.' })
  await ctx.plugin(ToolRuntime)
  await ctx.plugin(AgentRegistry)
  ctx.llm.registerAdapter(['mock'], adapter)
  const loopFiber = await ctx.plugin(FullCustomLoopService, config(traceRoot, overrides))
  if (persistenceRoot !== undefined) {
    await ctx.plugin(JsonlSessionPersistence, { root: persistenceRoot })
  }
  return { ctx, adapter, traceRoot, loopFiber }
}

function prompt(text = 'run the test'): ReturnType<typeof createUserMessage> {
  return createUserMessage({ content: [{ type: 'text', text }], source: { kind: 'user' } })
}

async function createAgent(ctx: Context, id: string, meta?: NonNullable<Parameters<Context['agents']['create']>[0]>['meta']): Promise<AgentHandle> {
  return ctx.agents.create({
    sessionId: SessionId(id),
    agentOptions: { provider: 'mock', model: 'scripted' },
    ...meta === undefined ? {} : { meta },
  })
}

function eventKeys(events: readonly SessionEvent[], type: 'step/start' | 'step/end'): string[] {
  return events
    .filter((event): event is Extract<SessionEvent, { type: typeof type }> => event.type === type)
    .map(event => `${event.data.turn}:${event.data.step}`)
}

async function trace(agent: BudgetedPlanActReflectAgent): Promise<TraceRow[]> {
  const source = await readFile(agent.trace.filePath, 'utf8')
  return source.trim().split('\n').filter(Boolean).map(line => JSON.parse(line) as TraceRow)
}

afterEach(async () => {
  await Promise.allSettled(cleanups.splice(0).reverse().map(cleanup => cleanup()))
})

describe('Full Custom Loop capability boundary', () => {
  it('has no package or executable-code dependency on the stock loop, ReactLoopAgent, or its internal scheduler', async () => {
    const packageJson = JSON.parse(await readFile(join(FULL_CUSTOM_PACKAGE, 'package.json'), 'utf8')) as {
      dependencies?: Record<string, string>
      devDependencies?: Record<string, string>
      peerDependencies?: Record<string, string>
      experimentalSeams?: string[]
    }
    const dependencyNames = Object.keys({
      ...packageJson.dependencies,
      ...packageJson.devDependencies,
      ...packageJson.peerDependencies,
    })
    expect(dependencyNames).not.toContain('@deepseek-ai/dsh-agent-loop')
    expect(packageJson.experimentalSeams).toEqual(['@deepseek-ai/dsh-agent:Inbox.claim'])

    const sourceFiles = (await readdir(FULL_CUSTOM_SOURCE))
      .filter(name => name.endsWith('.ts'))
    const imports: string[] = []
    const identifiers = new Set<string>()
    const claimReceivers: string[] = []
    const heritage: string[] = []
    for (const name of sourceFiles) {
      const fileName = join(FULL_CUSTOM_SOURCE, name)
      const source = await readFile(fileName, 'utf8')
      const file = ts.createSourceFile(fileName, source, ts.ScriptTarget.Latest, true, ts.ScriptKind.TS)
      const visit = (node: ts.Node): void => {
        if (ts.isImportDeclaration(node) && ts.isStringLiteral(node.moduleSpecifier)) {
          imports.push(node.moduleSpecifier.text)
        }
        if (ts.isIdentifier(node)) identifiers.add(node.text)
        if (ts.isCallExpression(node)
          && ts.isPropertyAccessExpression(node.expression)
          && node.expression.name.text === 'claim') {
          claimReceivers.push(node.expression.expression.getText(file))
        }
        if (ts.isHeritageClause(node)) heritage.push(node.getText(file))
        ts.forEachChild(node, visit)
      }
      visit(file)
    }

    expect(imports).not.toContain('@deepseek-ai/dsh-agent-loop')
    expect(identifiers.has('ReactLoopAgent')).toBe(false)
    expect(identifiers.has('TOOL_RUNTIME_SCHEDULER')).toBe(false)
    expect(heritage.join('\n')).not.toMatch(/ReactLoopAgent|AgentLoop/u)
    expect(claimReceivers.length).toBeGreaterThan(0)
    expect(new Set(claimReceivers)).toEqual(new Set(['this.inbox']))

    const agentPackageRoot = dirname(require.resolve('@deepseek-ai/dsh-agent/package.json'))
    const inboxTypes = await readFile(join(agentPackageRoot, 'lib', 'types', 'inbox.d.ts'), 'utf8')
    expect(inboxTypes).toMatch(/@internal[^]*?\*\/\s*claim\(target: InboxTarget, turn: number\)/u)
  })

  it('fails fast for every configuration value that would weaken the experiment', () => {
    const valid = config('/tmp/dsh-full-loop-config')
    expect(assertFullCustomConfig(valid)).toMatchObject(valid)
    expect(() => assertFullCustomConfig({ ...valid, agents: [{ id: 'bypass' }] }))
      .toThrow(/agents.*empty/u)
    expect(() => assertFullCustomConfig({ ...valid, maxModelCalls: 1 }))
      .toThrow(/reserve plan, act, reflect, and finalize/u)
    expect(() => assertFullCustomConfig({ ...valid, subagentMaxModelCalls: 3 }))
      .toThrow(/subagentMaxModelCalls must reserve/u)
    expect(() => assertFullCustomConfig({ ...valid, subagentMaxToolCalls: 0 }))
      .toThrow(/subagentMaxToolCalls.*safe integer/u)
    expect(() => assertFullCustomConfig({ ...valid, maxCycles: 1.5 }))
      .toThrow(/safe integer/u)
    expect(() => assertFullCustomConfig({ ...valid, maxRetriesPerPhase: -1 }))
      .toThrow(/safe integer/u)
    expect(() => assertFullCustomConfig({ ...valid, traceRoot: 'relative/trace' }))
      .toThrow(/traceRoot must be absolute/u)
    expect(() => assertFullCustomConfig({ ...valid, subagentMode: 'unbounded' as never }))
      .toThrow(/unsupported subagentMode/u)
  })
})

describe('Full Custom Loop public-service integration with a local fake LLM', () => {
  it('runs root Plan -> Act -> Reflect -> Finalize, serializes tools, pairs Session events, and records diagnostics and trace', async () => {
    const { ctx, adapter } = await harness([
      textResponse('plan ready'),
      toolCallResponse('tool-a', 'serial_probe', { label: 'a' }),
      textResponse('{"decision":"continue","reason":"collect the second observation"}'),
      toolCallResponse('tool-b', 'serial_probe', { label: 'b' }),
      textResponse('{"decision":"finish","reason":"both observations are complete"}'),
      textResponse('final answer from the independent loop'),
    ])
    let activeTools = 0
    let maxActiveTools = 0
    const toolOrder: string[] = []
    let turnStopping = 0
    ctx.on('agent/turn-stopping', () => { turnStopping++ })
    ctx.tools.register(defineTool({
      name: 'serial_probe',
      description: 'Records whether calls overlap.',
      parameters: { label: { type: 'string', required: true } },
      output: {
        schema: {
          type: 'object',
          additionalProperties: false,
          properties: { label: { type: 'string', required: true } },
        },
        render: (_args, value) => [{ type: 'text', text: value.label }],
      },
      isConcurrencySafe: () => true,
      async execute(args) {
        activeTools++
        maxActiveTools = Math.max(maxActiveTools, activeTools)
        toolOrder.push(`start:${args.label}`)
        await new Promise<void>(resolve => setImmediate(resolve))
        toolOrder.push(`end:${args.label}`)
        activeTools--
        return { label: args.label }
      },
    }))

    const handle = await createAgent(ctx, 'full-root')
    const agent = handle.agent as BudgetedPlanActReflectAgent
    agent.followup(prompt())
    await agent.whenIdle()

    expect(adapter.requests).toHaveLength(6)
    expect(adapter.requests.map(request => {
      const system = request.system ?? ''
      if (system.includes('PLAN PHASE')) return 'plan'
      if (system.includes('ACT PHASE')) return 'act'
      if (system.includes('REFLECT PHASE')) return 'reflect'
      if (system.includes('FINALIZE PHASE')) return 'finalize'
      return 'unknown'
    })).toEqual(['plan', 'act', 'reflect', 'act', 'reflect', 'finalize'])
    expect(maxActiveTools).toBe(1)
    expect(toolOrder).toEqual(['start:a', 'end:a', 'start:b', 'end:b'])

    const events = agent.session.events
    expect(events.filter(event => event.type === 'turn/start')).toHaveLength(1)
    expect(events.filter(event => event.type === 'turn/end')).toHaveLength(1)
    expect(eventKeys(events, 'step/start')).toEqual(eventKeys(events, 'step/end'))
    expect(eventKeys(events, 'step/start')).toHaveLength(6)
    expect(turnStopping).toBe(1)
    const turnEnd = events.findLast(event => event.type === 'turn/end')
    expect(turnEnd?.type === 'turn/end' && turnEnd.data.reason).toEqual({ kind: 'completed' })

    const diagnostics = agent.diagnostics()
    expect(diagnostics).toMatchObject({
      implementation: FULL_CUSTOM_LOOP_IMPLEMENTATION,
      algorithm: FULL_CUSTOM_LOOP_ALGORITHM,
      inheritsOfficialAgentLoop: false,
      usesOfficialReactLoopAgent: false,
      toolScheduling: 'strictly-serial',
      experimentalSeams: ['@deepseek-ai/dsh-agent:Inbox.claim'],
      isSubagent: false,
      turns: 1,
      cycles: 2,
      modelCalls: 6,
      toolCalls: 2,
      limits: { maxModelCalls: 8, maxToolCalls: 4 },
    })
    const diagnosticResult = await ctx.tools.execute({
      callId: CallId('diagnostics'),
      name: 'full_loop_diagnostics',
      arguments: {},
      agent,
      signal: new AbortController().signal,
    })
    expect(diagnosticResult.isError).toBe(false)
    const diagnosticText = diagnosticResult.content
      .filter((block): block is Extract<typeof block, { type: 'text' }> => block.type === 'text')
      .map(block => block.text)
      .join('\n')
    expect(JSON.parse(diagnosticText)).toMatchObject({
      implementation: FULL_CUSTOM_LOOP_IMPLEMENTATION,
      experimentalSeams: ['@deepseek-ai/dsh-agent:Inbox.claim'],
      traceFile: agent.trace.filePath,
    })

    const rows = await trace(agent)
    expect(rows.filter(row => row.event === 'phase-start').map(row => row.phase))
      .toEqual(['plan', 'act', 'reflect', 'act', 'reflect', 'finalize'])
    expect(rows.filter(row => row.event === 'tool-start').map(row => row.tool)).toEqual(['serial_probe', 'serial_probe'])
    expect(rows.some(row => row.event === 'turn-end' && row.outcome === 'completed')).toBe(true)
    await handle.dispose()
  })

  it('resets model/cycle/tool budgets at each durable turn boundary', async () => {
    const oneTurn = [
      textResponse('plan'),
      textResponse('act without tools'),
      textResponse('{"decision":"finish","reason":"done"}'),
      textResponse('final'),
    ] as const
    const { ctx, adapter } = await harness([...oneTurn, ...oneTurn], {
      maxCycles: 1,
      maxModelCalls: 4,
      maxToolCalls: 1,
    })
    const handle = await createAgent(ctx, 'two-turn-budget')
    const agent = handle.agent as BudgetedPlanActReflectAgent

    agent.followup(prompt('first turn'))
    await agent.whenIdle()
    agent.followup(prompt('second turn'))
    await agent.whenIdle()

    expect(adapter.requests).toHaveLength(8)
    expect(agent.session.events.filter(event => event.type === 'turn/end')).toHaveLength(2)
    expect(agent.diagnostics()).toMatchObject({
      turns: 2,
      cycles: 2,
      modelCalls: 8,
      currentTurnUsage: { cycles: 1, modelCalls: 4, toolCalls: 0 },
    })
    await handle.dispose()
  })

  it('keeps runtime-context snapshots separate from phase prompts and restores their dedup state', async () => {
    const { ctx } = await harness([])
    const handle = await createAgent(ctx, 'context-projection')
    const agent = handle.agent as BudgetedPlanActReflectAgent
    const projection = new FullLoopContextProjection(agent.ctx, agent.session)

    const first = projection.project('runtime alpha', [])
    if (first === undefined) throw new Error('first runtime snapshot was not produced')
    expect(first.source).toMatchObject({
      kind: 'plugin',
      plugin: '@local/dsh-full-custom-loop/runtime-context',
    })
    agent.session.append('user/message', first, { surfaceOp: 'append' })
    expect(projection.project('runtime alpha', [])).toBeUndefined()

    const cleared = projection.project('', [])
    if (cleared === undefined) throw new Error('runtime-context clear marker was not produced')
    agent.session.append('user/message', cleared, { surfaceOp: 'append' })
    expect(projection.project('', [])).toBeUndefined()

    const restored = new FullLoopContextProjection(agent.ctx, agent.session)
    expect(restored.project('', [])).toBeUndefined()
    expect(restored.project('runtime beta', [])).toMatchObject({
      source: {
        kind: 'plugin',
        plugin: '@local/dsh-full-custom-loop/runtime-context',
      },
    })
    await handle.dispose()
  })

  it('resumes a persisted completed turn in a fresh Context and replans only at the next turn boundary', async () => {
    const persistenceRoot = await mkdtemp(join(tmpdir(), 'dsh-full-loop-resume-'))
    cleanups.push(async () => rm(persistenceRoot, { recursive: true, force: true }))
    const oneTurn = [
      textResponse('plan'),
      textResponse('act without tools'),
      textResponse('{"decision":"finish","reason":"turn complete"}'),
      textResponse('final'),
    ] as const
    const sessionId = SessionId('full-custom-resume')

    const first = await harness([...oneTurn], {}, persistenceRoot)
    const firstHandle = await createAgent(first.ctx, sessionId)
    const firstAgent = firstHandle.agent as BudgetedPlanActReflectAgent
    firstAgent.followup(prompt('first durable turn'))
    await firstAgent.whenIdle()
    await first.ctx.sessions.flush(firstAgent.session)

    expect(first.adapter.requests).toHaveLength(4)
    expect(firstAgent.session.events.at(-1)).toMatchObject({
      type: 'turn/end',
      data: { turn: 1, reason: { kind: 'completed' } },
    })
    const firstEventCount = firstAgent.session.events.length
    await firstHandle.dispose()
    await first.ctx.fiber.dispose()

    const second = await harness([...oneTurn], {}, persistenceRoot)
    const resumedHandle = await second.ctx.agents.resume({
      resumeSessionId: sessionId,
      agentOptions: { provider: 'mock', model: 'scripted' },
    })
    const resumed = resumedHandle.agent as BudgetedPlanActReflectAgent

    // Resume publishes the durable balanced log as-is. It neither calls the
    // model nor fabricates a continuation of an old Plan/Act/Reflect step.
    expect(second.adapter.requests).toHaveLength(0)
    expect(resumed.session.events).toHaveLength(firstEventCount + 1)
    expect(resumed.session.events.at(-2)).toMatchObject({
      type: 'turn/end',
      data: { turn: 1, reason: { kind: 'completed' } },
    })
    expect(resumed.session.events.at(-1)).toMatchObject({ type: 'session/end-seed' })
    expect((await trace(resumed)).some(row => row.event === 'agent-published' && row.outcome === 'resume'))
      .toBe(true)

    resumed.followup(prompt('second turn after restart'))
    await resumed.whenIdle()
    await second.ctx.sessions.flush(resumed.session)

    expect(second.adapter.requests).toHaveLength(4)
    expect(second.adapter.requests.map(request => {
      const system = request.system ?? ''
      if (system.includes('PLAN PHASE')) return 'plan'
      if (system.includes('ACT PHASE')) return 'act'
      if (system.includes('REFLECT PHASE')) return 'reflect'
      if (system.includes('FINALIZE PHASE')) return 'finalize'
      return 'unknown'
    })).toEqual(['plan', 'act', 'reflect', 'finalize'])
    expect(resumed.session.events
      .filter(event => event.type === 'turn/start')
      .map(event => event.data.turn)).toEqual([1, 2])
    expect(resumed.session.events
      .filter(event => event.type === 'turn/end')
      .map(event => event.data.turn)).toEqual([1, 2])
    expect(eventKeys(resumed.session.events, 'step/start'))
      .toEqual(['1:1', '1:2', '1:3', '1:4', '2:1', '2:2', '2:3', '2:4'])
    expect(eventKeys(resumed.session.events, 'step/start'))
      .toEqual(eventKeys(resumed.session.events, 'step/end'))
    expect((await trace(resumed)).filter(row => row.event === 'phase-start').map(row => row.phase))
      .toEqual(['plan', 'act', 'reflect', 'finalize'])
    await resumedHandle.dispose()
  })

  it('aborts a hung persistence load with its owner and disposes a preparation that arrives late', async () => {
    const { ctx } = await harness([])
    const sessionId = SessionId('late-resume-preparation')
    let resolvePrepare!: (preparation: SessionPreparation) => void
    let markPrepareStarted!: () => void
    const prepareStarted = new Promise<void>(resolve => { markPrepareStarted = resolve })
    const pendingPreparation = new Promise<SessionPreparation>(resolve => { resolvePrepare = resolve })
    let releases = 0
    const abandoned = SessionPreparation.create(
      ctx.sessions.prepare(sessionId),
      { release: () => { releases++ } },
    )
    ctx.provide('sessionPersistence', {
      prepare: () => {
        markPrepareStarted()
        return pendingPreparation
      },
    } as never)

    let resumeJob: Promise<AgentHandle> | undefined
    const owner = await ctx.plugin(Object.assign((ownerCtx: Context) => {
      resumeJob = ownerCtx.agents.resume({
        resumeSessionId: sessionId,
        agentOptions: { provider: 'mock', model: 'scripted' },
      })
    }, { inject: ['agents'] }))
    await prepareStarted
    if (resumeJob === undefined) throw new Error('owner fixture did not start resume')

    await owner.dispose()
    await expect(resumeJob).rejects.toThrow(/owner disposed/u)
    expect(ctx.agents.get(sessionId)).toBeUndefined()
    expect(ctx.sessions.get(sessionId)).toBeUndefined()

    resolvePrepare(abandoned)
    await new Promise<void>(resolve => setImmediate(resolve))
    expect(releases).toBe(1)
  })

  it('honors the public pre-step rejection seam as a blocked turn without calling a model', async () => {
    const { ctx, adapter } = await harness([])
    ctx.on('agent/pre-step', async () => ({ kind: 'reject' }))
    const handle = await createAgent(ctx, 'blocked-pre-step')
    const agent = handle.agent

    agent.followup(prompt('this proposal is blocked'))
    await agent.whenIdle()

    expect(adapter.requests).toHaveLength(0)
    expect(agent.session.events.filter(event => event.type === 'step/start')).toHaveLength(0)
    const end = agent.session.events.findLast(event => event.type === 'turn/end')
    expect(end?.type === 'turn/end' && end.data.reason).toEqual({ kind: 'blocked' })
    await handle.dispose()
  })

  it('rejects invalid AgentOptions before publishing either registry identity', async () => {
    const { ctx } = await harness([])
    await expect(ctx.agents.create({
      sessionId: SessionId('invalid-agent-options'),
      agentOptions: { provider: 'mock', model: 'scripted', maxTokens: 0 },
    })).rejects.toThrow(/maxTokens must be a positive safe integer/u)
    expect(ctx.agents.get(SessionId('invalid-agent-options'))).toBeUndefined()
    expect(ctx.sessions.get(SessionId('invalid-agent-options'))).toBeUndefined()
  })

  it('routes a durable subagent session through the direct-budgeted path only', async () => {
    const { ctx, adapter } = await harness([textResponse('direct child answer')], {
      subagentMode: 'direct-budgeted',
    })
    const handle = await createAgent(ctx, 'direct-child', {
      origin: 'subagent',
      parentSession: SessionId('parent'),
      delegationDepth: 1,
    })
    const agent = handle.agent as BudgetedPlanActReflectAgent
    agent.followup(prompt('answer directly within the child budget'))
    await agent.whenIdle()

    expect(adapter.requests).toHaveLength(1)
    expect(adapter.requests[0]?.system).toContain('ACT PHASE')
    expect(adapter.requests[0]?.system).not.toContain('PLAN PHASE')
    expect(agent.session.header).toMatchObject({
      origin: 'subagent',
      parentSession: SessionId('parent'),
      delegationDepth: 1,
    })
    expect(agent.diagnostics()).toMatchObject({
      isSubagent: true,
      subagentMode: 'direct-budgeted',
      cycles: 0,
      modelCalls: 1,
      limits: { maxModelCalls: 12, maxToolCalls: 8 },
    })
    expect((await trace(agent)).filter(row => row.event === 'phase-start').map(row => row.phase))
      .toEqual(['act'])
    await handle.dispose()
  })

  it('gives direct-budgeted subagents a separate tool budget without widening the root budget', async () => {
    const { ctx, adapter } = await harness([
      toolCallResponse('child-tool-1', 'subagent_budget_probe', { step: 1 }),
      toolCallResponse('child-tool-2', 'subagent_budget_probe', { step: 2 }),
      toolCallResponse('child-tool-3', 'subagent_budget_probe', { step: 3 }),
      toolCallResponse('child-tool-4', 'subagent_budget_probe', { step: 4 }),
      toolCallResponse('child-tool-5', 'subagent_budget_probe', { step: 5 }),
      textResponse('child completed after five tool calls'),
    ])
    const executed: number[] = []
    ctx.tools.register(defineTool({
      name: 'subagent_budget_probe',
      description: 'Exercise the isolated subagent tool budget.',
      parameters: { step: { type: 'integer', required: true } },
      output: {
        schema: {
          type: 'object',
          additionalProperties: false,
          properties: { step: { type: 'integer', required: true } },
        },
        render: (_args, value) => [{ type: 'text', text: String(value.step) }],
      },
      isConcurrencySafe: () => true,
      execute(args) {
        executed.push(args.step)
        return Promise.resolve({ step: args.step })
      },
    }))
    const handle = await createAgent(ctx, 'direct-child-expanded-budget', {
      origin: 'subagent',
      parentSession: SessionId('parent'),
      delegationDepth: 1,
    })
    const agent = handle.agent as BudgetedPlanActReflectAgent

    agent.followup(prompt('complete five evidence reads'))
    await agent.whenIdle()

    expect(adapter.requests).toHaveLength(6)
    expect(executed).toEqual([1, 2, 3, 4, 5])
    expect(agent.diagnostics()).toMatchObject({
      isSubagent: true,
      modelCalls: 6,
      toolCalls: 5,
      limits: { maxModelCalls: 12, maxToolCalls: 8 },
    })
    const end = agent.session.events.findLast(event => event.type === 'turn/end')
    expect(end?.type === 'turn/end' && end.data.reason).toEqual({ kind: 'completed' })
    await handle.dispose()
  })

  it('can deliberately route a subagent through the full BPAR algorithm when configured', async () => {
    const { ctx, adapter } = await harness([
      textResponse('child plan'),
      textResponse('child act'),
      textResponse('{"decision":"finish","reason":"child evidence complete"}'),
      textResponse('child final'),
    ], { subagentMode: 'full-bpar', maxCycles: 1, maxModelCalls: 4 })
    const handle = await createAgent(ctx, 'full-bpar-child', {
      origin: 'subagent',
      parentSession: SessionId('parent'),
      delegationDepth: 1,
    })
    const agent = handle.agent as BudgetedPlanActReflectAgent
    agent.followup(prompt('exercise the full child loop'))
    await agent.whenIdle()

    expect(adapter.requests).toHaveLength(4)
    expect((await trace(agent)).filter(row => row.event === 'phase-start').map(row => row.phase))
      .toEqual(['plan', 'act', 'reflect', 'finalize'])
    expect(agent.diagnostics()).toMatchObject({
      isSubagent: true,
      subagentMode: 'full-bpar',
      cycles: 1,
      modelCalls: 4,
    })
    await handle.dispose()
  })

  it('cancels an active fake stream and still closes the standard step and turn event pairs', async () => {
    const { ctx, adapter } = await harness(['hang'])
    const reportedErrors: unknown[] = []
    ctx.on('agent/error', event => { reportedErrors.push(event.error) })
    const handle = await createAgent(ctx, 'cancel-active')
    const agent = handle.agent as BudgetedPlanActReflectAgent
    agent.followup(prompt())
    await adapter.firstRequestStarted

    agent.cancel({ kind: 'user' })
    await agent.whenIdle()

    expect(adapter.requests[0]?.signal?.aborted).toBe(true)
    expect(eventKeys(agent.session.events, 'step/start')).toEqual(eventKeys(agent.session.events, 'step/end'))
    const end = agent.session.events.findLast(event => event.type === 'turn/end')
    expect(end?.type === 'turn/end' && end.data.reason).toEqual({
      kind: 'aborted',
      reason: { kind: 'user' },
    })
    expect(reportedErrors).toEqual([])
    expect((await trace(agent)).some(row => row.event === 'turn-end' && row.outcome === 'aborted')).toBe(true)
    await handle.dispose()
  })

  it('continues registry and owner cleanup when scope teardown rejects', async () => {
    const { ctx } = await harness([])
    const handle = await createAgent(ctx, 'scope-dispose-failure')
    const agent = handle.agent as BudgetedPlanActReflectAgent
    const originalDispose = agent.scope.dispose.bind(agent.scope)
    agent.scope.dispose = () => Promise.reject(new Error('injected scope teardown failure'))

    await expect(handle.dispose()).rejects.toThrow(/injected scope teardown failure/u)
    expect(ctx.agents.get(agent.id)).toBeUndefined()
    expect(ctx.sessions.get(agent.id)).toBeUndefined()

    // The injected failure deliberately skipped the real scope teardown. Clean
    // that test-only resource after proving the Factory continued its own
    // detach/untrack path.
    agent.scope.dispose = originalDispose
    await originalDispose()
  })

  it('service unload cancels and unregisters every active Agent before it settles', async () => {
    const { ctx, adapter, loopFiber } = await harness(['hang', 'hang'])
    const handles = await Promise.all([
      createAgent(ctx, 'service-unload-a'),
      createAgent(ctx, 'service-unload-b'),
    ])
    const agents = handles.map(handle => handle.agent as BudgetedPlanActReflectAgent)
    agents[0]?.followup(prompt('first active turn'))
    agents[1]?.followup(prompt('second active turn'))
    await expect.poll(() => adapter.requests.length).toBe(2)

    await loopFiber.dispose()

    expect(adapter.requests.every(request => request.signal?.aborted === true)).toBe(true)
    for (const agent of agents) {
      expect(ctx.agents.get(agent.id)).toBeUndefined()
      expect(ctx.sessions.get(agent.id)).toBeUndefined()
      expect((await trace(agent)).some(row => row.event === 'agent-disposed')).toBe(true)
    }
  })

  it('binds an unpublished Agent to its owner fiber and removes both registries when that owner unloads', async () => {
    const { ctx, adapter } = await harness([])
    let owned: AgentHandle | undefined
    const owner = await ctx.plugin(Object.assign(async (ownerCtx: Context) => {
      owned = await createAgent(ownerCtx, 'owner-scoped')
    }, { inject: ['agents'] }))
    if (owned === undefined) throw new Error('owner fixture did not create its Agent')
    const agent: Agent = owned.agent

    expect(ctx.agents.get(agent.id)).toBe(agent)
    expect(ctx.sessions.get(agent.id)).toBe(agent.session)
    await owner.dispose()

    expect(ctx.agents.get(agent.id)).toBeUndefined()
    expect(ctx.sessions.get(agent.id)).toBeUndefined()
    expect(() => agent.followup(prompt())).toThrow(/disposed/u)
    expect(adapter.requests).toHaveLength(0)
  })
})
