import { createHash } from 'node:crypto'
import { mkdtemp, mkdir, readFile, realpath, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'

import { Context } from '@deepseek-ai/cordis'
import type { Agent } from '@deepseek-ai/dsh-agent'
import { Session, SessionId } from '@deepseek-ai/dsh-session'
import SubagentRuntime from '@deepseek-ai/dsh-subagent'
import type { SubagentCapabilities, SubagentProvider, SubagentResult, SubagentRun, SubagentStartRequest } from '@deepseek-ai/dsh-subagent'
import WorkerThreadWorkflowEngine from '@deepseek-ai/dsh-workflow-worker-thread'
import { describe, expect, it, vi } from 'vitest'

import { ProfiledDynamicWorkflowRunner, type Config } from '../packages/dynamic-workflow/src/index.js'
import { WorkflowTelemetryRecorder } from '../packages/dynamic-workflow/src/telemetry.js'

vi.setConfig({ testTimeout: 30_000 })

const VALID_RESULT = {
  summary: '总结',
  agreements: ['共识'],
  disagreements: ['异议'],
  findings: [
    { sourceLocations: ['src/a.ts:1'], failureScenario: '失败一', rankingRationale: '第一', fixSuggestion: '修复一' },
    { sourceLocations: ['src/b.ts:2'], failureScenario: '失败二', rankingRationale: '第二', fixSuggestion: '修复二' },
    { sourceLocations: ['src/c.ts:3'], failureScenario: '失败三', rankingRationale: '第三', fixSuggestion: '修复三' },
  ],
  recommendation: '按顺序修复',
} as const

class KeylessProvider implements SubagentProvider {
  readonly name = 'stub'
  readonly capabilities: SubagentCapabilities = {
    outputSchema: true,
    depthLimit: true,
    toolFilter: true,
    persona: false,
  }
  readonly inheritsParentContext = false
  readonly requests: SubagentStartRequest[] = []
  readonly disposeCalls: number[] = []
  readonly sessions = new Map<ReturnType<typeof SessionId>, Session>()

  constructor(
    private readonly reply: (request: SubagentStartRequest, index: number) => SubagentResult
      = (_request, index) => ({
        output: [{ type: 'text', text: index === 6 ? JSON.stringify(VALID_RESULT) : `keyless-answer-${index}` }],
        stopReason: 'completed',
      }),
    private readonly observedRoute: (request: SubagentStartRequest, index: number) => { provider: string; model: string }
      = request => ({
        provider: request.agentOptions?.provider ?? 'missing-provider',
        model: request.agentOptions?.model ?? 'missing-model',
      }),
  ) {}

  async start(request: SubagentStartRequest): Promise<SubagentRun> {
    const index = this.requests.push(request) - 1
    this.disposeCalls[index] = 0
    const id = SessionId(`dynamic-child-${index}`)
    const session = Session.create(id)
    session.append('request/context', this.observedRoute(request, index))
    this.sessions.set(id, session)
    return {
      id,
      localAgent: undefined,
      result: Promise.resolve(this.reply(request, index)),
      dispose: async () => { this.disposeCalls[index] = (this.disposeCalls[index] ?? 0) + 1 },
    }
  }
}

async function setupNative(
  reply?: (request: SubagentStartRequest, index: number) => SubagentResult,
  profileOverrides?: Record<'fast' | 'deep' | 'review', { provider: string; model: string }>,
  observedRoute?: (request: SubagentStartRequest, index: number) => { provider: string; model: string },
) {
  const projectRoot = new URL('..', import.meta.url).pathname.replace(/\/$/, '')
  const sharedWorkflow = join(projectRoot, 'dynamic-workflow', 'shared', 'workflows')
  const temp = await realpath(await mkdtemp(join(tmpdir(), 'dsh-native-workflow-')))
  const profiles = join(temp, 'model-profiles.json')
  await mkdir(temp, { recursive: true })
  await writeFile(profiles, JSON.stringify({
    schemaVersion: 1,
    profiles: profileOverrides ?? {
      fast: { provider: 'fast-provider', model: 'fast-model' },
      deep: { provider: 'deep-provider', model: 'deep-model' },
      review: { provider: 'review-provider', model: 'review-model' },
    },
  }))
  const config: Config = {
    workflowRoot: sharedWorkflow,
    modelProfilesFile: profiles,
    allowedWorkflows: ['multi-model-review'],
    requiredProfiles: ['fast', 'deep', 'review'],
    maxSourceBytes: 262_144,
    maxTaskChars: 20_000,
    maxResultChars: 50_000,
  }
  const ctx = new Context()
  await ctx.plugin(SubagentRuntime)
  const provider = new KeylessProvider(reply, observedRoute)
  ctx.subagents.registerProvider(provider)
  await ctx.plugin(WorkerThreadWorkflowEngine, {
    provider: 'stub',
    maxConcurrentAgents: 4,
    maxTotalAgents: 8,
    maxItemsPerCall: 16,
    syncTimeoutMs: 5_000,
    disposeGraceMs: 5_000,
  })
  return {
    ctx,
    provider,
    runner: new ProfiledDynamicWorkflowRunner(
      ctx.workflowEngine,
      config,
      new WorkflowTelemetryRecorder(ctx, childId => provider.sessions.get(childId)),
    ),
  }
}

function nativeRequest() {
  return {
    workflow: 'multi-model-review',
    task: 'Review the public API boundary.',
    parent: { id: SessionId('dynamic-parent'), options: {} } as unknown as Agent,
    signal: new AbortController().signal,
  }
}

describe('profiled saved workflow over the real rc.6 worker-thread engine', () => {
  it('runs the byte-mirrored native script through fake public Subagents without a model', async () => {
    const projectRoot = new URL('..', import.meta.url).pathname.replace(/\/$/, '')
    const sharedWorkflow = join(projectRoot, 'dynamic-workflow', 'shared', 'workflows')
    const sharedRoot = join(projectRoot, 'dynamic-workflow', 'shared')
    const manifestBytes = await readFile(join(sharedRoot, 'manifest.json'))
    const piManifestBytes = await readFile('/path/to/pi-evidence-gated-change/dynamic-workflow/shared/manifest.json')
    expect(manifestBytes.equals(piManifestBytes)).toBe(true)
    const manifest = JSON.parse(manifestBytes.toString('utf8')) as {
      aggregate: string
      files: Array<{ path: string; sha256: string }>
    }
    const aggregate = createHash('sha256')
    for (const entry of [...manifest.files].sort((left, right) => left.path.localeCompare(right.path))) {
      const bytes = await readFile(join(sharedRoot, entry.path))
      const fileHash = createHash('sha256').update(bytes).digest('hex')
      expect(fileHash).toBe(entry.sha256)
      aggregate.update(`${entry.path}\0${fileHash}\0`)
    }
    expect(aggregate.digest('hex')).toBe(manifest.aggregate)
    expect(manifest.aggregate).toBe('db61f13dca3a75662261dd72f21d603c4c85d79bc1b85ddd8baaf6f2cb3f9776')
    const { ctx, provider, runner } = await setupNative()
    const result = await runner.run(nativeRequest())

    expect(result.runId).toMatch(/^[0-9a-f-]{36}$/)
    expect(result.agentsStarted).toBe(7)
    expect(result.result).toEqual(VALID_RESULT)
    expect(result.resolvedRoutes).toEqual({
      fast: { provider: 'fast-provider', model: 'fast-model' },
      deep: { provider: 'deep-provider', model: 'deep-model' },
      review: { provider: 'review-provider', model: 'review-model' },
    })
    expect(result.timings.phases.map(phase => phase.phase)).toEqual([
      'independent-reviews',
      'challenge-reviews',
      'synthesis',
    ])
    expect(result.timings.runDurationMs).toBeGreaterThanOrEqual(0)
    expect(result.agentOutcomes).toHaveLength(7)
    expect(result.agentOutcomes.map(outcome => outcome.outcome)).toEqual(Array(7).fill('completed'))
    expect(result.agentOutcomes.map(outcome => outcome.seq)).toEqual([1, 2, 3, 4, 5, 6, 7])
    expect(result.retryCount).toBe(0)
    expect(result.retryTelemetryComplete).toBe(true)
    expect(result.routeTelemetryComplete).toBe(true)
    expect(result.outcomeTelemetryComplete).toBe(true)
    expect(result.agentOutcomes.map(outcome => outcome.finalObservedRoute)).toEqual([
      { provider: 'fast-provider', model: 'fast-model' },
      { provider: 'deep-provider', model: 'deep-model' },
      { provider: 'review-provider', model: 'review-model' },
      { provider: 'deep-provider', model: 'deep-model' },
      { provider: 'deep-provider', model: 'deep-model' },
      { provider: 'deep-provider', model: 'deep-model' },
      { provider: 'review-provider', model: 'review-model' },
    ])
    expect(provider.requests).toHaveLength(7)
    expect(provider.requests.map(request => request.agentOptions)).toEqual([
      { provider: 'fast-provider', model: 'fast-model' },
      { provider: 'deep-provider', model: 'deep-model' },
      { provider: 'review-provider', model: 'review-model' },
      { provider: 'deep-provider', model: 'deep-model' },
      { provider: 'deep-provider', model: 'deep-model' },
      { provider: 'deep-provider', model: 'deep-model' },
      { provider: 'review-provider', model: 'review-model' },
    ])
    expect(provider.disposeCalls).toEqual([1, 1, 1, 1, 1, 1, 1])
    await ctx.fiber.dispose()
  })

  it('fails the native run when fewer than two independent reviews succeed', async () => {
    const { ctx, provider, runner } = await setupNative(() => ({ output: [], stopReason: 'error' }))
    try {
      await expect(runner.run(nativeRequest())).rejects.toThrow(/at least two successful independent reviews/)
      expect(provider.requests).toHaveLength(3)
      expect(provider.disposeCalls).toEqual([1, 1, 1])
    } finally {
      await ctx.fiber.dispose()
    }
  })

  it('fails closed when the successful independent reviews collapse to one model route', async () => {
    const { ctx, provider, runner } = await setupNative(
      (_request, index) => index === 0
        ? { output: [], stopReason: 'error' }
        : { output: [{ type: 'text', text: `keyless-answer-${index}` }], stopReason: 'completed' },
      {
        fast: { provider: 'provider', model: 'flash' },
        deep: { provider: 'provider', model: 'pro' },
        review: { provider: 'provider', model: 'pro' },
      },
    )
    try {
      const rejection = runner.run(nativeRequest())
      await expect(rejection).rejects.toThrow(/at least 2 distinct successful independent review routes/)
      await expect(rejection).rejects.toThrow(/partialWorkflowReceipt=.*"agentsStarted":3.*"stopReason":"error".*"result":null/u)
      expect(provider.requests).toHaveLength(3)
      expect(provider.disposeCalls).toEqual([1, 1, 1])
    } finally {
      await ctx.fiber.dispose()
    }
  })

  it('rejects a completed run when the actually observed independent routes collapse', async () => {
    const { ctx, provider, runner } = await setupNative(
      undefined,
      undefined,
      () => ({ provider: 'actual-gateway', model: 'one-collapsed-model' }),
    )
    try {
      const rejection = runner.run(nativeRequest())
      await expect(rejection).rejects.toThrow(/WORKFLOW_ACTUAL_ROUTE_DIVERSITY_INVALID/)
      await expect(rejection).rejects.toThrow(/partialWorkflowReceipt=.*"agentsStarted":7.*"stopReason":"completed".*"result":null/u)
      expect(provider.requests).toHaveLength(7)
      expect(provider.disposeCalls).toEqual([1, 1, 1, 1, 1, 1, 1])
    } finally {
      await ctx.fiber.dispose()
    }
  })

  it('fails the native run when final synthesis is empty or unsuccessful', async () => {
    const { ctx, provider, runner } = await setupNative((_request, index) => index === 6
      ? { output: [], stopReason: 'error' }
      : { output: [{ type: 'text', text: `keyless-answer-${index}` }], stopReason: 'completed' })
    try {
      await expect(runner.run(nativeRequest())).rejects.toThrow(/final synthesis failed/)
      expect(provider.requests).toHaveLength(7)
      expect(provider.disposeCalls).toEqual([1, 1, 1, 1, 1, 1, 1])
    } finally {
      await ctx.fiber.dispose()
    }
  })
})
