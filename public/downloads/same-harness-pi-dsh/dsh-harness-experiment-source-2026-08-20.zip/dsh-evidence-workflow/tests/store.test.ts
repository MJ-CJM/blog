import { mkdir, mkdtemp, readFile, rm, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'

import { afterEach, describe, expect, it } from 'vitest'

import { RunStore } from '../packages/workflow-core/src/index.js'

const temporaryRoots: string[] = []

afterEach(async () => {
  await Promise.all(temporaryRoots.splice(0).map(path => rm(path, { recursive: true, force: true })))
})

async function storeFixture(): Promise<{ store: RunStore; runRoot: string }> {
  const temporary = await mkdtemp(join(tmpdir(), 'dsh-egc-store-'))
  temporaryRoots.push(temporary)
  const fixture = join(temporary, 'fixture')
  await mkdir(fixture)
  await writeFile(join(fixture, 'README.md'), 'baseline')
  const runRoot = join(temporary, 'runs')
  const store = new RunStore(runRoot)
  await store.initialize('crash', fixture, 'contract', 'runtime')
  return { store, runRoot }
}

describe('RunStore crash reconciliation', () => {
  it('pairs and blocks an operation whose side effect outcome is unknown', async () => {
    const { store } = await storeFixture()
    const operation = await store.beginOperation('crash', 'agent_side_effect')
    const recovered = await store.reconcile('crash')
    expect(recovered.phase).toBe('blocked')
    expect(recovered.pendingOperation).toBeUndefined()
    const events = (await readFile(store.artifact('crash', 'events.jsonl'), 'utf8')).trim().split('\n').map(line => JSON.parse(line))
    expect(events.some(event => event.type === 'operation_intent' && event.data.operationId === operation.id)).toBe(true)
    expect(events.some(event => event.type === 'operation_settled' && event.data.operationId === operation.id)).toBe(true)
  })

  it('recovers the state-clear crash after a durable settled event without replaying work', async () => {
    const { store } = await storeFixture()
    const operation = await store.beginOperation('crash', 'artifact_write')
    const pendingState = await store.readState('crash')
    await store.settleOperation('crash', operation.id, 'succeeded')
    await store.writeJson('crash', 'state.json', pendingState)
    const recovered = await store.reconcile('crash')
    expect(recovered.phase).toBe('created')
    expect(recovered.pendingOperation).toBeUndefined()
  })
})
