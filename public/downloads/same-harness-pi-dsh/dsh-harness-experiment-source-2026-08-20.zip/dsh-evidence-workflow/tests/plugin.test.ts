import type { Context } from '@deepseek-ai/cordis'
import type { Agent } from '@deepseek-ai/dsh-agent'
import { describe, expect, it, vi } from 'vitest'

import type { AgentRunRequest } from '../packages/workflow-core/src/index.js'
import { DshSubagentRunner } from '../packages/workflow-plugin/src/index.js'

const request: AgentRunRequest = {
  role: 'code-scout',
  label: 'egc-code-scout',
  prompt: 'inspect',
  persona: 'read only',
  outputSchema: {
    type: 'object',
    additionalProperties: false,
    required: ['summary'],
    properties: { summary: { type: 'string', minLength: 1 } },
  },
  toolNames: ['read', 'glob', 'grep'],
  workspace: '/prepared/run/workspace',
}

describe('DshSubagentRunner rc.6 public API adapter', () => {
  it('passes the public request fields, relies on inherited cwd, and disposes success exactly once', async () => {
    const dispose = vi.fn(async () => undefined)
    const start = vi.fn(async (_provider: string, _options: Record<string, unknown>) => ({
      result: Promise.resolve({ stopReason: 'completed', structured: { summary: 'ok' }, output: [] }),
      dispose,
    }))
    const parent = { id: 'parent' } as Agent
    const signal = new AbortController().signal
    const runner = new DshSubagentRunner({ subagents: { start } } as unknown as Context, parent, 'spawn', 4096)

    await expect(runner.run(request, signal)).resolves.toEqual({ summary: 'ok' })
    expect(start).toHaveBeenCalledTimes(1)
    const [provider, options] = start.mock.calls[0]!
    expect(provider).toBe('spawn')
    expect(options).toMatchObject({
      label: request.label,
      parent,
      signal,
      agentOptions: { maxTokens: 4096 },
      toolFilter: { allow: request.toolNames },
      persona: request.persona,
    })
    expect(options).not.toHaveProperty('cwd')
    expect(JSON.stringify(options.outputSchema)).not.toContain('minLength')
    expect(dispose).toHaveBeenCalledTimes(1)
  })

  it.each([
    { name: 'non-completed result', makeResult: () => Promise.resolve({ stopReason: 'aborted', output: [] }) },
    { name: 'rejected result', makeResult: () => Promise.reject(new Error('subagent failed')) },
  ])('disposes exactly once for $name', async ({ makeResult }) => {
    const dispose = vi.fn(async () => undefined)
    const start = vi.fn(async (_provider: string, _options: Record<string, unknown>) => ({ result: makeResult(), dispose }))
    const runner = new DshSubagentRunner(
      { subagents: { start } } as unknown as Context,
      { id: 'parent' } as Agent,
      'spawn',
      4096,
    )
    await expect(runner.run(request, new AbortController().signal)).rejects.toThrow()
    expect(dispose).toHaveBeenCalledTimes(1)
  })
})
