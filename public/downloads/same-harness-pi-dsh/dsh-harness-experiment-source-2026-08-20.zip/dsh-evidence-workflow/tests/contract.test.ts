import { readFile } from 'node:fs/promises'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'

import { assertObjectJsonSchema } from '@deepseek-ai/dsh-tools'
import { Context } from '@deepseek-ai/cordis'
import SkillRegistry from '@deepseek-ai/dsh-skill'
import * as SkillFileSystem from '@deepseek-ai/dsh-skill-filesystem'
import { describe, expect, it } from 'vitest'

import { assertPortableSchema, portableContractHash } from '../packages/workflow-core/src/index.js'
import { toDshTransportSchema } from '../packages/workflow-plugin/src/index.js'

const root = dirname(dirname(fileURLToPath(import.meta.url)))
const piRoot = '/path/to/pi-evidence-gated-change'

describe('portable v2 contract', () => {
  it('matches the canonical Pi four-tree manifest byte-for-byte', async () => {
    expect(await portableContractHash(root)).toBe('4285706cc55f6c2065552c9a727a472181caa36c7d2e5ef1efb7cfb024421e87')
    const manifest = JSON.parse(await readFile(join(root, 'contract', 'manifest.json'), 'utf8'))
    for (const entry of manifest.files as Array<{ path: string }>) {
      const [dsh, pi] = await Promise.all([
        readFile(join(root, entry.path)),
        readFile(join(piRoot, entry.path)),
      ])
      expect(dsh.equals(pi), entry.path).toBe(true)
    }
  })

  it('uses AJV for full constraints while rc.6 receives only its supported transport subset', async () => {
    const raw = await readFile(join(root, 'contract', 'schemas', 'discovery.schema.json'), 'utf8')
    const schema = JSON.parse(raw)
    expect(() => assertObjectJsonSchema(schema)).toThrow(/unsupported/i)
    expect(() => assertPortableSchema(schema, { summary: '', files: [], risks: [] }, 'discovery')).toThrow()
    expect(() => assertPortableSchema(JSON.parse(raw), {
      summary: 'ok',
      files: [{ path: 'src/TodoService.ts', reason: 'implementation' }],
      risks: [],
    }, 'discovery')).not.toThrow()
    const transport = toDshTransportSchema(schema)
    expect(transport).not.toHaveProperty('$schema')
    expect(JSON.stringify(transport)).not.toContain('minItems')
    expect(() => assertObjectJsonSchema(transport)).not.toThrow()
  })

  it('loads only the two lab Skills through the isolated rc.6 filesystem provider', async () => {
    const ctx = new Context()
    const registryFiber = await ctx.plugin(SkillRegistry)
    const providerFiber = await ctx.plugin(SkillFileSystem, {
      providerName: 'evidence-gated-filesystem-test',
      includeDefaultRoots: false,
      customSkillDirs: [join(root, 'skills')],
      watch: false,
    })
    try {
      const catalog = await ctx.skills.list({ cwd: join(root, 'fixtures', 'todo-service') })
      expect(catalog.map(skill => skill.name).sort()).toEqual(['evidence-gated-change', 'profiled-dynamic-workflow'])
      const loaded = await ctx.skills.get('evidence-gated-change', { cwd: root })
      expect(loaded?.content).toContain('Every side effect has an intent and settled event')
      const dynamic = await ctx.skills.get('profiled-dynamic-workflow', { cwd: root })
      expect(dynamic?.content).toContain('Call `profiled_dynamic_workflow`')
    } finally {
      await providerFiber.dispose()
      await registryFiber.dispose()
    }
  })
})
