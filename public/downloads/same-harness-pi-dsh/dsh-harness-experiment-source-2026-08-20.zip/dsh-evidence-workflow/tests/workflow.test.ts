import { access, mkdtemp, readFile, rm, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'

import { afterEach, describe, expect, it } from 'vitest'

import {
  CommandVerifier,
  EvidenceGatedWorkflow,
  assertPortableSchema,
  hashTree,
  type AgentRunRequest,
  type AgentRunner,
} from '../packages/workflow-core/src/index.js'
import { HappyRunner, SOLUTION_README, SOLUTION_SOURCE, SOLUTION_TEST, copyFixture, writeSolution } from './helpers.js'

const root = dirname(dirname(fileURLToPath(import.meta.url)))
const fixtureRoot = join(root, 'fixtures', 'todo-service')
const oracleScript = join(root, 'scripts', 'verify-fixture.mjs')
const temporaryRoots: string[] = []

afterEach(async () => {
  await Promise.all(temporaryRoots.splice(0).map(path => rm(path, { recursive: true, force: true })))
})

async function testRoot(): Promise<string> {
  const path = await mkdtemp(join(tmpdir(), 'dsh-egc-'))
  temporaryRoots.push(path)
  return path
}

function workflow(runRoot: string): EvidenceGatedWorkflow {
  return new EvidenceGatedWorkflow({
    runRoot,
    fixtureRoot,
    contractRoot: join(root, 'contract'),
    runtimeRoot: root,
    oracleScript,
    maxRepair: 1,
    verificationCommand: ['node', '--experimental-strip-types', 'test/TodoService.test.ts'],
    verificationTimeoutMs: 20_000,
    maxCapturedOutputBytes: 131_072,
  })
}

describe('EvidenceGatedWorkflow', () => {
  it('runs verifier tests under Node 25 or newer', () => {
    expect(Number.parseInt(process.versions.node.split('.')[0] ?? '0', 10)).toBeGreaterThanOrEqual(25)
  })

  it('completes the canonical workflow with three real command receipts and paired operations', async () => {
    const temporary = await testRoot()
    const subject = workflow(join(temporary, 'runs'))
    const signal = new AbortController().signal
    const runner = new HappyRunner()

    expect((await subject.prepare('happy', signal)).stage).toBe('baseline_captured')
    const planned = await subject.plan('happy', runner, signal)
    expect(planned.stage).toBe('awaiting_approval')
    expect(planned.artifacts).toContain('plan.json')
    expect(planned.artifacts).not.toContain('approval.json')
    expect(planned.artifacts).not.toContain('patch.diff')
    const discovery = JSON.parse(await readFile(subject.store.artifact('happy', 'discovery-code.json'), 'utf8'))
    expect(discovery.files).toHaveLength(1)
    expect(discovery.findings).toBeUndefined()
    await subject.approve('happy', planned.approvalHash!, 'local-test-user')

    const result = await subject.execute('happy', runner, signal)
    expect(result.stage).toBe('completed')
    expect(result.repairs).toBe(0)
    const verification = JSON.parse(await readFile(subject.store.artifact('happy', 'verification.json'), 'utf8'))
    expect(verification.passed).toBe(true)
    expect(verification.commands).toHaveLength(3)
    expect(verification.commands.map((receipt: { exitCode: number }) => receipt.exitCode)).toEqual([0, 0, 0])
    expect(verification.changedFiles.sort()).toEqual(['README.md', 'src/TodoService.ts', 'test/TodoService.test.ts'].sort())

    const state = JSON.parse(await readFile(subject.store.artifact('happy', 'state.json'), 'utf8'))
    expect(state).toMatchObject({ schemaVersion: 1, phase: 'completed', repairCount: 0, maxRepair: 1 })
    const stateSchema = JSON.parse(await readFile(join(root, 'contract', 'schemas', 'state.schema.json'), 'utf8'))
    expect(() => assertPortableSchema(stateSchema, state, 'state')).not.toThrow()
    const events = (await readFile(subject.store.artifact('happy', 'events.jsonl'), 'utf8')).trim().split('\n').map(line => JSON.parse(line))
    const intents = events.filter(event => event.type === 'operation_intent').map(event => event.data.operationId).sort()
    const settled = events.filter(event => event.type === 'operation_settled').map(event => event.data.operationId).sort()
    expect(settled).toEqual(intents)
    expect(events.find(event => event.type === 'operation_intent' && event.data.operationType === 'approval_write')?.data)
      .toMatchObject({ approvalHash: state.approvalHash, approvedBy: 'local-test-user' })
    expect(events.find(event => event.type === 'operation_intent' && event.data.operationType === 'implementation_agent')?.data)
      .toMatchObject({ planHash: state.planHash })
  }, 30_000)

  it('aborts and drains the sibling scout when one discovery fails schema validation', async () => {
    const temporary = await testRoot()
    const subject = workflow(join(temporary, 'runs'))
    const signal = new AbortController().signal
    let siblingDrained = false
    const runner: AgentRunner = {
      async run(request: AgentRunRequest, childSignal: AbortSignal): Promise<unknown> {
        if (request.role === 'code-scout') return { summary: '', files: [], risks: [] }
        if (request.role === 'test-scout') {
          return new Promise((_resolve, reject) => {
            childSignal.addEventListener('abort', () => {
              siblingDrained = true
              reject(childSignal.reason)
            }, { once: true })
          })
        }
        throw new Error('unexpected role')
      },
    }
    await subject.prepare('invalid-schema', signal)
    const result = await subject.plan('invalid-schema', runner, signal)
    expect(result.stage).toBe('blocked')
    expect(siblingDrained).toBe(true)
  })

  it('rejects a weak title-keyed implementation even when its project test passes', async () => {
    const temporary = await testRoot()
    const workspace = join(temporary, 'workspace')
    await copyFixture(fixtureRoot, workspace)
    const weakSource = SOLUTION_SOURCE
      .replace('private readonly tasksByRequestId = new Map<string, Task>();', 'private readonly tasksByRequestId = new Map<string, Task>();')
      .replace('this.tasksByRequestId.get(requestId)', 'this.tasksByRequestId.get(input.title)')
      .replace('this.tasksByRequestId.set(requestId, task)', 'this.tasksByRequestId.set(input.title, task)')
    const weakTest = `import assert from "node:assert/strict";
import test from "node:test";
import { TodoService } from "../src/TodoService.ts";

test("createTask appears idempotent when title and requestId are both repeated", () => {
\tconst service = new TodoService();
\tconst first = service.createTask({ title: "write report", requestId: "req-1" });
\tconst duplicate = service.createTask({ title: "write report", requestId: "req-1" });
\tassert.deepEqual(duplicate, first);
\tassert.equal(service.listTasks().length, 1);
});
`
    await Promise.all([
      writeFile(join(workspace, 'src', 'TodoService.ts'), weakSource),
      writeFile(join(workspace, 'test', 'TodoService.test.ts'), weakTest),
      writeFile(join(workspace, 'README.md'), SOLUTION_README),
    ])
    const verifier = new CommandVerifier(
      ['node', '--experimental-strip-types', 'test/TodoService.test.ts'],
      oracleScript,
      fixtureRoot,
      root,
      20_000,
      131_072,
    )
    const receipt = await verifier.verify(workspace, await hashTree(fixtureRoot), new AbortController().signal)
    expect(receipt.commands[0]?.exitCode).toBe(0)
    expect(receipt.commands[1]?.exitCode).not.toBe(0)
    expect(receipt.passed).toBe(false)
  }, 30_000)

  it('denies Agent-authored filesystem escape under the Node permission model', async () => {
    const temporary = await testRoot()
    const workspace = join(temporary, 'workspace')
    const escaped = join(temporary, 'escaped.txt')
    await copyFixture(fixtureRoot, workspace)
    const malicious = `import { writeFileSync } from "node:fs";\nwriteFileSync(${JSON.stringify(escaped)}, "escaped");\n${SOLUTION_TEST}`
    await writeSolution(workspace, malicious)
    const verifier = new CommandVerifier(
      ['node', '--experimental-strip-types', 'test/TodoService.test.ts'],
      oracleScript,
      fixtureRoot,
      root,
      20_000,
      131_072,
    )
    const receipt = await verifier.verify(workspace, await hashTree(fixtureRoot), new AbortController().signal)
    expect(receipt.commands[0]?.exitCode).not.toBe(0)
    expect(receipt.commands[0]?.stderr).toMatch(/permission|ERR_ACCESS_DENIED/i)
    await expect(access(escaped)).rejects.toThrow()
    expect(receipt.passed).toBe(false)
  }, 30_000)

  it.each([
    {
      capability: 'child process',
      prefix: 'import { spawnSync } from "node:child_process";\nspawnSync(process.execPath, ["-e", "process.exit(0)"]);\n',
      permission: /ChildProcess|permission|ERR_ACCESS_DENIED/i,
    },
    {
      capability: 'network',
      prefix: 'import { connect } from "node:net";\nconnect({ host: "127.0.0.1", port: 9 });\n',
      permission: /Network|permission|ERR_ACCESS_DENIED/i,
    },
  ])('denies Agent-authored $capability access under the Node 25 permission model', async ({ prefix, permission }) => {
    const temporary = await testRoot()
    const workspace = join(temporary, 'workspace')
    await copyFixture(fixtureRoot, workspace)
    await writeSolution(workspace, `${prefix}${SOLUTION_TEST}`)
    const verifier = new CommandVerifier(
      ['node', '--experimental-strip-types', 'test/TodoService.test.ts'],
      oracleScript,
      fixtureRoot,
      root,
      20_000,
      131_072,
    )
    const receipt = await verifier.verify(workspace, await hashTree(fixtureRoot), new AbortController().signal)
    expect(receipt.commands[0]?.exitCode).not.toBe(0)
    const output = `${receipt.commands[0]?.stdout ?? ''}\n${receipt.commands[0]?.stderr ?? ''}`
    expect(output).toMatch(permission)
    if (permission.source.includes('Network')) expect(output).not.toMatch(/ECONNREFUSED/)
    expect(receipt.passed).toBe(false)
  }, 30_000)

  it('requires the displayed four-hash approval token and rejects workspace drift', async () => {
    const temporary = await testRoot()
    const subject = workflow(join(temporary, 'runs'))
    const signal = new AbortController().signal
    const runner = new HappyRunner()
    await subject.prepare('approval-gate', signal)
    const planned = await subject.plan('approval-gate', runner, signal)
    await expect(subject.approve('approval-gate', planned.planHash!, 'local-test-user')).rejects.toThrow(/approvalHash/)
    await writeFile(join(subject.store.workspace('approval-gate'), 'README.md'), 'tampered before approval\n')
    await expect(subject.approve('approval-gate', planned.approvalHash!, 'local-test-user')).rejects.toThrow(/workspace changed/)
    await expect(access(subject.store.artifact('approval-gate', 'approval.json'))).rejects.toThrow()
  })

  it('blocks fail-closed when execute is requested without an approval artifact', async () => {
    const temporary = await testRoot()
    const subject = workflow(join(temporary, 'runs'))
    const signal = new AbortController().signal
    const runner = new HappyRunner()
    await subject.prepare('missing-approval', signal)
    await subject.plan('missing-approval', runner, signal)
    const result = await subject.execute('missing-approval', runner, signal)
    expect(result.stage).toBe('blocked')
    expect(result.message).toMatch(/approval\.json|ENOENT/)
    expect(runner.calls).not.toContain('implementer')
  })

  it.each([
    {
      behavior: 'ignores SIGTERM until SIGKILL',
      handler: '',
      expectedExitCode: -1,
      minimumDurationMs: 1_300,
      maximumDurationMs: 3_000,
    },
    {
      behavior: 'exits zero after the deadline',
      handler: 'process.exit(0)',
      expectedExitCode: 0,
      minimumDurationMs: 400,
      maximumDurationMs: 1_500,
    },
  ])('never passes a timed-out project test that $behavior', async ({
    handler,
    expectedExitCode,
    minimumDurationMs,
    maximumDurationMs,
  }) => {
    const temporary = await testRoot()
    const workspace = join(temporary, 'workspace')
    await copyFixture(fixtureRoot, workspace)
    const timedTest = `process.stdout.write("TIMEOUT_READY\\n");
process.on("SIGTERM", () => {
\tprocess.stdout.write("SIGTERM_SEEN\\n");
\t${handler}
});
setInterval(() => {}, 1000);
${SOLUTION_TEST}`
    await writeSolution(workspace, timedTest)
    const verifier = new CommandVerifier(
      ['node', '--experimental-strip-types', 'test/TodoService.test.ts'],
      oracleScript,
      fixtureRoot,
      root,
      500,
      131_072,
    )
    const receipt = await verifier.verify(workspace, await hashTree(fixtureRoot), new AbortController().signal)
    expect(receipt.commands[0]?.exitCode).toBe(expectedExitCode)
    expect(receipt.commands[0]?.stdout).toContain('TIMEOUT_READY')
    expect(receipt.commands[0]?.stdout).toContain('SIGTERM_SEEN')
    expect(receipt.commands[0]?.durationMs).toBeGreaterThanOrEqual(minimumDurationMs)
    expect(receipt.commands[0]?.durationMs).toBeLessThan(maximumDurationMs)
    expect(receipt.passed).toBe(false)
  }, 30_000)
})
