import type { Context } from '@deepseek-ai/cordis'
import AgentLoop from '@deepseek-ai/dsh-agent-loop'
import { afterEach, describe, expect, it, vi } from 'vitest'

import {
  WorkflowAwareAgentLoop,
  assertAdapterConfig,
  composeSetup,
} from '../packages/agent-loop-adapter/src/index.js'

const base = {
  maxParallelToolCalls: 10,
  agents: [],
  runRoot: '/tmp/dsh-egc-runs',
  mutationTools: ['write', 'edit'],
}

afterEach(() => vi.restoreAllMocks())

describe('WorkflowAwareAgentLoop public seam', () => {
  it('fails before super for declarative agents and rejects widened mutation tools', () => {
    expect(() => assertAdapterConfig({ ...base, agents: [{ id: 'bypass' }] })).toThrow(/agents.*empty/)
    expect(() => assertAdapterConfig({ ...base, mutationTools: ['write', 'edit', 'bash'] })).toThrow(/exactly write and edit/)
  })

  it('runs prior setup first and returns its unpublished commit unchanged', async () => {
    const order: string[] = []
    const commit = { commit: vi.fn(() => order.push('commit')) }
    const prior = vi.fn(async () => {
      order.push('prior')
      return commit
    })
    const setup = composeSetup(prior, () => order.push('supervisor'))
    const returned = await setup({} as Context)
    expect(order).toEqual(['prior', 'supervisor'])
    expect(returned).toBe(commit)
    expect(commit.commit).not.toHaveBeenCalled()
  })

  it('fails loud on the public direct create bypass', () => {
    expect(() => WorkflowAwareAgentLoop.prototype.create.call({}, 'id' as never)).toThrow(/ctx\.agents\.create\/resume/)
  })

  it('overrides both registry factory entrypoints', () => {
    expect(Object.hasOwn(WorkflowAwareAgentLoop.prototype, 'createAgent')).toBe(true)
    expect(Object.hasOwn(WorkflowAwareAgentLoop.prototype, 'resume')).toBe(true)
  })

  it('composes the supervisor into both registry factory setup paths', async () => {
    const handle = { id: 'handle' }
    const create = vi.spyOn(AgentLoop.prototype, 'createAgent').mockResolvedValue(handle as never)
    const resume = vi.spyOn(AgentLoop.prototype, 'resume').mockResolvedValue(handle as never)
    const installSupervisor = vi.fn()
    const receiver = { installSupervisor }
    const ownerCtx = {} as Context
    const agentCtx = {} as Context
    const commit = { commit: vi.fn() }
    const prior = vi.fn(async () => commit)

    await WorkflowAwareAgentLoop.prototype.createAgent.call(receiver, ownerCtx, { setup: prior } as never)
    await WorkflowAwareAgentLoop.prototype.resume.call(receiver, ownerCtx, { setup: prior } as never)
    const createOptions = create.mock.calls[0]?.[1]
    const resumeOptions = resume.mock.calls[0]?.[1]
    expect(await createOptions?.setup?.(agentCtx)).toBe(commit)
    expect(await resumeOptions?.setup?.(agentCtx)).toBe(commit)
    expect(prior).toHaveBeenCalledTimes(2)
    expect(installSupervisor).toHaveBeenCalledTimes(2)
    expect(commit.commit).not.toHaveBeenCalled()
  })

  it('does not install or publish when prior setup fails', async () => {
    const install = vi.fn()
    const setup = composeSetup(async () => {
      throw new Error('prior setup failed')
    }, install)
    await expect(setup({} as Context)).rejects.toThrow('prior setup failed')
    expect(install).not.toHaveBeenCalled()
  })
})
