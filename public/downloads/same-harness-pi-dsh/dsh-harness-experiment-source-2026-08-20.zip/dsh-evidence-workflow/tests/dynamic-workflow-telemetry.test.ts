import { Context } from '@deepseek-ai/cordis'
import { Session, SessionId } from '@deepseek-ai/dsh-session'
import { WorkflowRunId } from '@deepseek-ai/dsh-workflow'
import { describe, expect, it } from 'vitest'

import { WorkflowTelemetryRecorder } from '../packages/dynamic-workflow/src/telemetry.js'

describe('WorkflowTelemetryRecorder public event folding', () => {
  it('isolates runs and returns phase timing, child outcomes, observed routes, and actual started retries', () => {
    const ctx = new Context()
    const childId = SessionId('child-1')
    const child = Session.create(childId)
    const sessions = new Map([[childId, child]])
    let clock = 0
    const recorder = new WorkflowTelemetryRecorder(ctx, id => sessions.get(id), () => clock)
    const runId = WorkflowRunId('run-1')
    const otherId = WorkflowRunId('run-other')
    const info = { id: runId, meta: { name: 'multi-model-review', description: 'review' } }
    const other = { id: otherId, meta: { name: 'other', description: 'other' } }

    ctx.emit('workflow/start', info)
    recorder.claim(runId)
    ctx.emit('workflow/start', other)
    clock = 10
    ctx.emit('workflow/phase', info, 'independent-reviews')
    ctx.emit('workflow/phase', other, 'unrelated')
    clock = 20
    ctx.emit('workflow/agent-start', info, {
      seq: 1,
      label: 'fast-review',
      phase: 'independent-reviews',
      childId,
    })
    child.append('request/context', { provider: 'deepseek-official', model: 'deepseek-v4-flash' })
    const appendLoose = child.append.bind(child) as (type: string, data: Record<string, unknown>) => void
    appendLoose('llm/retry', { retryId: 'retry-1' })
    appendLoose('llm/retry-started', { retryId: 'retry-1' })
    appendLoose('llm/retry', { retryId: 'retry-2' })
    appendLoose('llm/retry-started', { retryId: 'retry-2' })
    clock = 55
    ctx.emit('workflow/agent-end', info, {
      seq: 1,
      label: 'fast-review',
      phase: 'independent-reviews',
      childId,
      outcome: 'completed',
    })
    clock = 60
    ctx.emit('workflow/phase', info, 'synthesis')
    clock = 100
    ctx.emit('workflow/end', info, { stopReason: 'completed', agentsStarted: 1 })
    ctx.emit('workflow/end', other, { stopReason: 'completed', agentsStarted: 0 })

    expect(recorder.snapshot(runId, 1)).toEqual({
      timings: {
        runDurationMs: 100,
        phases: [
          { phase: 'independent-reviews', startedOffsetMs: 10, durationMs: 50 },
          { phase: 'synthesis', startedOffsetMs: 60, durationMs: 40 },
        ],
      },
      retryCount: 2,
      retryTelemetryComplete: true,
      agentOutcomes: [{
        seq: 1,
        label: 'fast-review',
        phase: 'independent-reviews',
        childId: 'child-1',
        outcome: 'completed',
        durationMs: 35,
        retryCount: 2,
        observedRoutes: [{ provider: 'deepseek-official', model: 'deepseek-v4-flash' }],
        finalObservedRoute: { provider: 'deepseek-official', model: 'deepseek-v4-flash' },
        telemetryStatus: 'complete',
      }],
      routeTelemetryComplete: true,
      outcomeTelemetryComplete: true,
    })
  })

  it('does not invent route or retry evidence for a provider without a local Session', () => {
    const ctx = new Context()
    let clock = 0
    const recorder = new WorkflowTelemetryRecorder(ctx, undefined, () => clock)
    const runId = WorkflowRunId('remote-run')
    const info = { id: runId, meta: { name: 'multi-model-review', description: 'review' } }
    const childId = SessionId('remote-child')
    ctx.emit('workflow/start', info)
    recorder.claim(runId)
    clock = 5
    ctx.emit('workflow/agent-start', info, { seq: 1, label: 'remote', childId })
    clock = 8
    ctx.emit('workflow/agent-end', info, { seq: 1, label: 'remote', childId, outcome: 'failed' })
    clock = 10
    ctx.emit('workflow/end', info, { stopReason: 'completed', agentsStarted: 1 })

    const receipt = recorder.snapshot(runId, 1)
    expect(receipt.retryCount).toBe(0)
    expect(receipt.retryTelemetryComplete).toBe(false)
    expect(receipt.agentOutcomes[0]).toMatchObject({
      outcome: 'failed',
      retryCount: null,
      observedRoutes: [],
      finalObservedRoute: null,
      telemetryStatus: 'no-local-session',
    })
    expect(receipt.routeTelemetryComplete).toBe(false)
  })

  it('keeps two claimed concurrent runs isolated when lifecycle events interleave', () => {
    const ctx = new Context()
    let clock = 0
    const recorder = new WorkflowTelemetryRecorder(ctx, undefined, () => clock)
    const runA = WorkflowRunId('run-a')
    const runB = WorkflowRunId('run-b')
    const infoA = { id: runA, meta: { name: 'multi-model-review', description: 'A' } }
    const infoB = { id: runB, meta: { name: 'multi-model-review', description: 'B' } }
    ctx.emit('workflow/start', infoA)
    recorder.claim(runA)
    clock = 1
    ctx.emit('workflow/start', infoB)
    recorder.claim(runB)
    clock = 5
    ctx.emit('workflow/phase', infoA, 'A-phase')
    clock = 7
    ctx.emit('workflow/phase', infoB, 'B-phase')
    clock = 15
    ctx.emit('workflow/end', infoB, { stopReason: 'completed', agentsStarted: 0 })
    clock = 20
    ctx.emit('workflow/end', infoA, { stopReason: 'completed', agentsStarted: 0 })

    expect(recorder.snapshot(runA, 0).timings).toEqual({
      runDurationMs: 20,
      phases: [{ phase: 'A-phase', startedOffsetMs: 5, durationMs: 15 }],
    })
    expect(recorder.snapshot(runB, 0).timings).toEqual({
      runDurationMs: 14,
      phases: [{ phase: 'B-phase', startedOffsetMs: 6, durationMs: 8 }],
    })
  })

  it('marks a started Agent without an observed end as unknown and incomplete', () => {
    const ctx = new Context()
    let clock = 0
    const recorder = new WorkflowTelemetryRecorder(ctx, undefined, () => clock)
    const runId = WorkflowRunId('missing-end-run')
    const info = { id: runId, meta: { name: 'multi-model-review', description: 'review' } }
    const childId = SessionId('missing-end-child')
    ctx.emit('workflow/start', info)
    recorder.claim(runId)
    clock = 5
    ctx.emit('workflow/agent-start', info, { seq: 1, label: 'unfinished', childId })
    clock = 10
    ctx.emit('workflow/end', info, { stopReason: 'cancelled', agentsStarted: 1 })

    const receipt = recorder.snapshot(runId, 1)
    expect(receipt.outcomeTelemetryComplete).toBe(false)
    expect(receipt.agentOutcomes[0]).toMatchObject({ outcome: 'unknown', durationMs: 5 })
  })
})
