import { mkdtemp, rm, symlink, unlink, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'

import { afterEach, describe, expect, it } from 'vitest'

import {
  RunStore,
  canonicalApprovalHash,
  canonicalPlanHash,
  workflowToolDecision,
  type ApprovalReceipt,
  type BaselineReceipt,
  type ChangePlan,
} from '../packages/workflow-core/src/index.js'

const temporaryRoots: string[] = []

afterEach(async () => {
  await Promise.all(temporaryRoots.splice(0).map(path => rm(path, { recursive: true, force: true })))
})

describe('workflow tool policy', () => {
  it('locks root tools and allows only approved child file_path mutations in implementing', async () => {
    const temporary = await mkdtemp(join(tmpdir(), 'dsh-egc-policy-'))
    temporaryRoots.push(temporary)
    const fixture = join(temporary, 'fixture')
    await writeFile(join(temporary, 'placeholder'), '')
    await import('node:fs/promises').then(async fs => {
      await fs.mkdir(join(fixture, 'src'), { recursive: true })
      await fs.mkdir(join(fixture, 'test'), { recursive: true })
      await Promise.all([
        fs.writeFile(join(fixture, 'README.md'), 'baseline'),
        fs.writeFile(join(fixture, 'src', 'TodoService.ts'), 'baseline'),
        fs.writeFile(join(fixture, 'test', 'TodoService.test.ts'), 'baseline'),
      ])
    })
    const runRoot = join(temporary, 'runs')
    const store = new RunStore(runRoot)
    await store.initialize('guard', fixture, 'contract-hash', 'runtime-hash')
    const workspace = store.workspace('guard')
    const rootAgent = { session: { header: { cwd: workspace } } }
    const childAgent = { session: { header: { cwd: workspace, origin: 'subagent' as const } } }
    const decide = (name: string, args: unknown, agent = rootAgent) => workflowToolDecision(runRoot, {
      name,
      arguments: args,
      agent,
    })

    expect(decide('evidence_gated_change', { action: 'plan', runId: 'guard' })).toBeUndefined()
    expect(decide('skill', { name: 'evidence-gated-change' })).toBeUndefined()
    expect(decide('bash', { command: 'touch forged' })).toMatch(/locked/)
    expect(decide('subagent', { prompt: 'forge approval' })).toMatch(/locked/)
    expect(decide('write', { file_path: 'README.md', content: 'x' })).toMatch(/locked/)
    expect(decide('write', { file_path: 'README.md', content: 'x' }, childAgent)).toMatch(/denied mutation/)
    expect(decide('read', { file_path: 'README.md' }, childAgent)).toBeUndefined()

    const baseline: BaselineReceipt = {
      runId: 'guard',
      capturedAt: new Date().toISOString(),
      fixtureHash: 'fixture-hash',
      workspaceHash: 'baseline-hash',
      contractHash: 'contract-hash',
      runtimeHash: 'runtime-hash',
      task: 'fixed',
      expectedInitialVerification: 'failing',
    }
    await store.writeJson('guard', 'baseline.json', baseline)
    await store.transition('guard', 'baseline_captured', 'baseline', {}, { baselineHash: baseline.workspaceHash })
    await store.transition('guard', 'discovering', 'discovering')
    await store.transition('guard', 'planning', 'planning')
    const plan: ChangePlan = {
      summary: 'fixed',
      files: ['README.md', 'src/TodoService.ts', 'test/TodoService.test.ts'],
      steps: ['implement'],
      tests: ['verify'],
      risks: [],
    }
    const planHash = canonicalPlanHash(plan)
    const approvalHash = canonicalApprovalHash({
      planHash,
      baselineHash: baseline.workspaceHash,
      contractHash: baseline.contractHash,
      runtimeHash: baseline.runtimeHash,
    })
    await store.writeJson('guard', 'plan.json', { ...plan, planHash })
    await store.transition('guard', 'awaiting_approval', 'plan_ready', {}, { planHash, approvalHash })
    const approval: ApprovalReceipt = {
      runId: 'guard',
      planHash,
      baselineHash: baseline.workspaceHash,
      contractHash: baseline.contractHash,
      runtimeHash: baseline.runtimeHash,
      approvalHash,
      decision: 'approved',
      decidedAt: new Date().toISOString(),
    }
    await store.writeJson('guard', 'approval.json', approval)
    await store.transition('guard', 'implementing', 'implementation_started')

    expect(decide('write', { file_path: 'README.md', content: 'x' }, childAgent)).toBeUndefined()
    expect(decide('edit', { path: 'README.md' }, childAgent)).toMatch(/file_path/)
    expect(decide('write', { file_path: '../approval.json', content: '{}' }, childAgent)).toMatch(/not contract-approved/)
    expect(decide('bash', { command: 'touch x' }, childAgent)).toMatch(/outside.*allowlist/)

    const outside = join(temporary, 'outside.ts')
    await writeFile(outside, 'outside')
    await unlink(join(workspace, 'src', 'TodoService.ts'))
    await symlink(outside, join(workspace, 'src', 'TodoService.ts'))
    expect(decide('write', { file_path: 'src/TodoService.ts', content: 'x' }, childAgent)).toMatch(/symbolic link/)
  })
})
