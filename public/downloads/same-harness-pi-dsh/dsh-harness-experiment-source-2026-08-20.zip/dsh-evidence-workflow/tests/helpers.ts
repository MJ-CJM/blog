import { cp, mkdir, writeFile } from 'node:fs/promises'
import { join } from 'node:path'

import type { AgentRunRequest, AgentRunner } from '../packages/workflow-core/src/index.js'

export const SOLUTION_SOURCE = `export interface Task {
\tid: number;
\ttitle: string;
\tcompleted: boolean;
}

export interface CreateTaskInput {
\ttitle: string;
\trequestId: string;
\tcompleted?: boolean;
}

export class TodoService {
\tprivate readonly tasks: Task[] = [];
\tprivate readonly tasksByRequestId = new Map<string, Task>();
\tprivate nextId = 1;

\tcreateTask(input: CreateTaskInput): Task {
\t\tconst requestId = input.requestId?.trim();
\t\tif (!requestId) throw new Error("requestId is required");
\t\tconst existing = this.tasksByRequestId.get(requestId);
\t\tif (existing) return { ...existing };
\t\tif (!input.title.trim()) throw new Error("title is required");
\t\tconst task: Task = {
\t\t\tid: this.nextId++,
\t\t\ttitle: input.title,
\t\t\tcompleted: input.completed ?? false,
\t\t};
\t\tthis.tasks.push(task);
\t\tthis.tasksByRequestId.set(requestId, task);
\t\treturn { ...task };
\t}

\tlistTasks(): Task[] {
\t\treturn this.tasks.map((task) => ({ ...task }));
\t}
}
`

export const SOLUTION_TEST = `import assert from "node:assert/strict";
import test from "node:test";
import { TodoService } from "../src/TodoService.ts";

test("createTask is idempotent by requestId", () => {
\tconst service = new TodoService();
\tconst first = service.createTask({ title: "write report", requestId: "req-1" });
\tconst duplicate = service.createTask({ title: "changed", requestId: "req-1" });
\tassert.deepEqual(duplicate, first);
\tassert.equal(service.listTasks().length, 1);
\tconst second = service.createTask({ title: "write report", requestId: "req-2" });
\tassert.equal(second.id, first.id + 1);
});

test("createTask rejects blank requestId and keeps defensive copies", () => {
\tconst service = new TodoService();
\tassert.throws(() => service.createTask({ title: "x", requestId: "   " }), /requestId/);
\tconst task = service.createTask({ title: "x", requestId: "req-1" });
\ttask.title = "outside";
\tassert.equal(service.listTasks()[0]?.title, "x");
});
`

export const SOLUTION_README = `# TodoService fixture

\`TodoService.createTask({ title, requestId, completed? })\` requires a non-empty \`requestId\`. Repeating a requestId returns the original task without creating a duplicate. \`listTasks()\` returns defensive copies.

Run the project tests with \`npm test\`.
`

export async function writeSolution(workspace: string, testSource = SOLUTION_TEST): Promise<void> {
  await Promise.all([
    writeFile(join(workspace, 'src', 'TodoService.ts'), SOLUTION_SOURCE),
    writeFile(join(workspace, 'test', 'TodoService.test.ts'), testSource),
    writeFile(join(workspace, 'README.md'), SOLUTION_README),
  ])
}

export async function copyFixture(fixtureRoot: string, destination: string): Promise<void> {
  await mkdir(destination, { recursive: true })
  await cp(fixtureRoot, destination, { recursive: true })
}

export class HappyRunner implements AgentRunner {
  readonly calls: string[] = []

  async run(request: AgentRunRequest, signal: AbortSignal): Promise<unknown> {
    signal.throwIfAborted()
    this.calls.push(request.role)
    switch (request.role) {
      case 'code-scout':
        return {
          summary: 'TodoService owns in-memory task creation.',
          files: [{ path: 'src/TodoService.ts', reason: 'Implementation and idempotency state live here.' }],
          risks: ['Duplicate calls must return defensive copies.'],
        }
      case 'test-scout':
        return {
          summary: 'Tests and README need requestId coverage.',
          files: [
            { path: 'test/TodoService.test.ts', reason: 'Project-level behavior tests.' },
            { path: 'README.md', reason: 'Public createTask contract.' },
          ],
          risks: ['A weak test can accidentally key on title.'],
        }
      case 'planner':
        return {
          summary: 'Add a requestId index, tests, and docs.',
          files: ['README.md', 'src/TodoService.ts', 'test/TodoService.test.ts'],
          steps: ['Validate requestId.', 'Reuse tasks by requestId.', 'Update tests and README.'],
          tests: ['Project tests and external oracle.'],
          risks: ['Do not consume ids for invalid or duplicate calls.'],
        }
      case 'implementer':
      case 'repair':
        await writeSolution(request.workspace)
        return {
          summary: 'Implemented the approved requestId behavior.',
          filesChanged: ['README.md', 'src/TodoService.ts', 'test/TodoService.test.ts'],
        }
      case 'reviewer':
        return { verdict: 'pass', summary: 'Patch matches the approved contract.', findings: [] }
    }
  }
}
