import { mkdtemp, mkdir, realpath, symlink, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'

import { Context } from '@deepseek-ai/cordis'
import type { Agent } from '@deepseek-ai/dsh-agent'
import type { WorkflowEngine, WorkflowRun, WorkflowStartRequest } from '@deepseek-ai/dsh-workflow'
import { describe, expect, it, vi } from 'vitest'

import {
  ProfiledDynamicWorkflowRunner,
  loadModelProfiles,
  loadSavedWorkflow,
  parseSavedWorkflowSource,
  resolveModelRoutes,
  type Config,
} from '../packages/dynamic-workflow/src/index.js'
import { WorkflowTelemetryRecorder } from '../packages/dynamic-workflow/src/telemetry.js'

const HEADER = 'export const meta = {"name":"multi-model-review","description":"review","phases":[{"title":"scan"}]};'
const BODY = 'phase("scan");\nreturn { task: args.task, models: args.models };\n'
const VALID_RESULT = {
  summary: '总结',
  agreements: ['共识'],
  disagreements: ['异议'],
  findings: [
    { sourceLocations: ['src/a.ts:1'], failureScenario: '失败一', rankingRationale: '第一', fixSuggestion: '修复一' },
    { sourceLocations: ['src/b.ts:2-3'], failureScenario: '失败二', rankingRationale: '第二', fixSuggestion: '修复二' },
    { sourceLocations: ['src/c.ts:4'], failureScenario: '失败三', rankingRationale: '第三', fixSuggestion: '修复三' },
  ],
  recommendation: '按顺序修复',
} as const

interface LabFiles {
  readonly root: string
  readonly workflows: string
  readonly profiles: string
  readonly config: Config
}

async function makeLab(options?: { source?: string; catalog?: unknown }): Promise<LabFiles> {
  const root = await realpath(await mkdtemp(join(tmpdir(), 'dsh-dynamic-workflow-')))
  const workflows = join(root, 'workflows')
  const profiles = join(root, 'model-profiles.json')
  await mkdir(workflows)
  await Promise.all([
    writeFile(join(workflows, 'multi-model-review.js'), options?.source ?? `${HEADER}\n${BODY}`),
    writeFile(profiles, JSON.stringify(options?.catalog ?? {
      schemaVersion: 1,
      profiles: {
        fast: { provider: 'provider-fast', model: 'model-fast' },
        deep: { provider: 'provider-deep', model: 'model-deep' },
        review: {},
      },
    })),
  ])
  return {
    root,
    workflows,
    profiles,
    config: {
      workflowRoot: workflows,
      modelProfilesFile: profiles,
      allowedWorkflows: ['multi-model-review'],
      requiredProfiles: ['fast', 'deep', 'review'],
      maxSourceBytes: 262_144,
      maxTaskChars: 20_000,
      maxResultChars: 50_000,
    },
  }
}

class FakeEngine {
  readonly requests: WorkflowStartRequest[] = []
  readonly cancel = vi.fn((_reason?: string) => undefined)
  readonly dispose = vi.fn(async () => undefined)
  result: Promise<{ value: unknown; stopReason: 'completed' | 'cancelled' | 'error'; error?: string; agentsStarted: number }>
    = Promise.resolve({ value: JSON.stringify(VALID_RESULT), stopReason: 'completed', agentsStarted: 2 })

  start(request: WorkflowStartRequest): WorkflowRun {
    this.requests.push(request)
    return {
      id: 'fake-run-1' as WorkflowRun['id'],
      meta: request.meta,
      result: this.result,
      cancel: this.cancel,
      dispose: this.dispose,
    }
  }
}

function fakeRecorder(): WorkflowTelemetryRecorder {
  return {
    claim: () => undefined,
    abandon: () => undefined,
    snapshot: () => ({
      timings: { runDurationMs: 1, phases: [] },
      retryCount: 0,
      retryTelemetryComplete: true,
      routeTelemetryComplete: true,
      agentOutcomes: [
        {
          seq: 1,
          label: 'fast-review',
          phase: 'independent-reviews',
          childId: 'fake-fast',
          outcome: 'completed',
          durationMs: 1,
          retryCount: 0,
          observedRoutes: [{ provider: 'provider-fast', model: 'model-fast' }],
          finalObservedRoute: { provider: 'provider-fast', model: 'model-fast' },
          telemetryStatus: 'complete',
        },
        {
          seq: 2,
          label: 'deep-review',
          phase: 'independent-reviews',
          childId: 'fake-deep',
          outcome: 'completed',
          durationMs: 1,
          retryCount: 0,
          observedRoutes: [{ provider: 'provider-deep', model: 'model-deep' }],
          finalObservedRoute: { provider: 'provider-deep', model: 'model-deep' },
          telemetryStatus: 'complete',
        },
        {
          seq: 3,
          label: 'review-review',
          phase: 'independent-reviews',
          childId: 'fake-review',
          outcome: 'completed',
          durationMs: 1,
          retryCount: 0,
          observedRoutes: [{ provider: 'parent-provider', model: 'parent-model' }],
          finalObservedRoute: { provider: 'parent-provider', model: 'parent-model' },
          telemetryStatus: 'complete',
        },
      ],
      outcomeTelemetryComplete: true,
    }),
  } as unknown as WorkflowTelemetryRecorder
}

describe('saved workflow source and platform profiles', () => {
  it('parses only the strict one-line JSON meta envelope and preserves the native body bytes', () => {
    const parsed = parseSavedWorkflowSource(`${HEADER}\n${BODY}`, 'multi-model-review')
    expect(parsed.meta).toEqual({
      name: 'multi-model-review',
      description: 'review',
      phases: [{ title: 'scan' }],
    })
    expect(parsed.body).toBe(BODY)
  })

  it.each([
    [` ${HEADER}\n${BODY}`, 'first line'],
    ['export const meta = {name:"bad"};\nreturn 1;', 'strict JSON'],
    ['export const meta = {"name":"multi-model-review","description":"ok","thinking":"high"};\nreturn 1;', 'not supported'],
    [`${HEADER}`, 'followed by a JavaScript body'],
  ])('rejects a malformed saved source envelope', (source, expected) => {
    expect(() => parseSavedWorkflowSource(source)).toThrow(expected)
  })

  it('loads only provider/model and keeps an empty profile as explicit inheritance', async () => {
    const lab = await makeLab()
    await expect(loadModelProfiles(lab.config)).resolves.toEqual({
      fast: { provider: 'provider-fast', model: 'model-fast' },
      deep: { provider: 'provider-deep', model: 'model-deep' },
      review: {},
    })
  })

  it('resolves every profile field against the parent route and rejects an incomplete route', () => {
    expect(resolveModelRoutes({
      fast: { provider: 'fast-provider', model: 'fast-model' },
      deep: { provider: 'deep-provider' },
      review: {},
    }, { provider: 'parent-provider', model: 'parent-model' })).toEqual({
      fast: { provider: 'fast-provider', model: 'fast-model' },
      deep: { provider: 'deep-provider', model: 'parent-model' },
      review: { provider: 'parent-provider', model: 'parent-model' },
    })
    expect(() => resolveModelRoutes({ review: {} }, {})).toThrow(/cannot resolve provider/)
  })

  it.each(['thinking', 'tools', 'maxTokens', 'apiKey'])('fails loudly for unsupported profile field %s', async (field) => {
    const lab = await makeLab({
      catalog: {
        schemaVersion: 1,
        profiles: { fast: { [field]: 'forbidden' }, deep: {}, review: {} },
      },
    })
    await expect(loadModelProfiles(lab.config)).rejects.toThrow(/unsupported by the rc\.6 native WorkflowEngine/)
  })

  it('rejects traversal, non-allowlisted names, and symlinked workflow files', async () => {
    const lab = await makeLab()
    await expect(loadSavedWorkflow(lab.config, '../escape')).rejects.toThrow(/kebab-case/)
    await expect(loadSavedWorkflow(lab.config, 'other')).rejects.toThrow(/not allowlisted/)
    const external = join(lab.root, 'external.js')
    await writeFile(external, `${HEADER.replace('multi-model-review', 'linked')}\nreturn 1;\n`)
    await symlink(external, join(lab.workflows, 'linked.js'))
    await expect(loadSavedWorkflow({
      ...lab.config,
      allowedWorkflows: ['linked'],
    }, 'linked')).rejects.toThrow(/not a symlink/)
  })
})

describe('ProfiledDynamicWorkflowRunner public WorkflowEngine delegation', () => {
  it('forwards the unchanged body/meta, resolved args, parent, and signal, then disposes exactly once', async () => {
    const lab = await makeLab()
    const engine = new FakeEngine()
    const runner = new ProfiledDynamicWorkflowRunner(engine as unknown as WorkflowEngine, lab.config, fakeRecorder())
    const parent = {
      id: 'parent',
      options: { provider: 'parent-provider', model: 'parent-model' },
    } as Agent
    const signal = new AbortController().signal

    const value = await runner.run({ workflow: 'multi-model-review', task: 'review this', parent, signal })
    expect(value).toMatchObject({
      runId: 'fake-run-1',
      agentsStarted: 2,
      result: VALID_RESULT,
      profiles: {
        fast: { provider: 'provider-fast', model: 'model-fast' },
        deep: { provider: 'provider-deep', model: 'model-deep' },
        review: {},
      },
      resolvedRoutes: {
        fast: { provider: 'provider-fast', model: 'model-fast' },
        deep: { provider: 'provider-deep', model: 'model-deep' },
        review: { provider: 'parent-provider', model: 'parent-model' },
      },
      timings: { phases: [] },
      retryCount: 0,
      retryTelemetryComplete: true,
      routeTelemetryComplete: true,
      outcomeTelemetryComplete: true,
    })
    expect(value.timings.runDurationMs).toBe(1)
    expect(value.agentOutcomes).toHaveLength(3)
    expect(engine.requests).toHaveLength(1)
    expect(engine.requests[0]).toMatchObject({
      script: BODY,
      meta: { name: 'multi-model-review', description: 'review', phases: [{ title: 'scan' }] },
      args: {
        task: 'review this',
        models: {
          fast: { provider: 'provider-fast', model: 'model-fast' },
          deep: { provider: 'provider-deep', model: 'model-deep' },
          review: { provider: 'parent-provider', model: 'parent-model' },
        },
        minDistinctReviewRoutes: 2,
        finalInstruction: expect.stringMatching(/^DSH FINAL-SYNTHESIS OUTPUT CONTRACT/),
      },
      parent,
      signal,
    })
    expect(engine.dispose).toHaveBeenCalledTimes(1)
  })

  it('cancels an in-flight native run when the parent signal aborts and still disposes', async () => {
    const lab = await makeLab()
    const engine = new FakeEngine()
    let settle!: (value: { value: null; stopReason: 'cancelled'; error: string; agentsStarted: number }) => void
    const settlement = new Promise<{ value: null; stopReason: 'cancelled'; error: string; agentsStarted: number }>((resolve) => {
      settle = resolve
    })
    engine.result = settlement
    engine.cancel.mockImplementation(() => {
      settle({ value: null, stopReason: 'cancelled', error: 'parent step aborted', agentsStarted: 1 })
    })
    const runner = new ProfiledDynamicWorkflowRunner(engine as unknown as WorkflowEngine, lab.config, fakeRecorder())
    const controller = new AbortController()
    const pending = runner.run({
      workflow: 'multi-model-review',
      task: 'review this',
      parent: { id: 'parent', options: { provider: 'parent', model: 'parent' } } as Agent,
      signal: controller.signal,
    })
    await vi.waitFor(() => { expect(engine.requests).toHaveLength(1) })
    controller.abort('test cancellation')
    await expect(pending).rejects.toThrow(/cancelled/)
    expect(engine.cancel).toHaveBeenCalledExactlyOnceWith('parent step aborted')
    expect(engine.dispose).toHaveBeenCalledTimes(1)
  })

  it('fails before engine start when the logical profiles collapse to one resolved route', async () => {
    const lab = await makeLab({
      catalog: {
        schemaVersion: 1,
        profiles: {
          fast: { provider: 'same', model: 'same' },
          deep: { provider: 'same', model: 'same' },
          review: { provider: 'same', model: 'same' },
        },
      },
    })
    const engine = new FakeEngine()
    const runner = new ProfiledDynamicWorkflowRunner(engine as unknown as WorkflowEngine, lab.config, fakeRecorder())
    await expect(runner.run({
      workflow: 'multi-model-review',
      task: 'review this',
      parent: { id: 'parent', options: { provider: 'parent', model: 'parent' } } as Agent,
      signal: new AbortController().signal,
    })).rejects.toThrow(/at least two distinct resolved/)
    expect(engine.requests).toHaveLength(0)
  })

  it('rejects a multi-model-review config whose profile keys do not match the saved script', async () => {
    const lab = await makeLab()
    expect(() => new ProfiledDynamicWorkflowRunner(
      new FakeEngine() as unknown as WorkflowEngine,
      { ...lab.config, requiredProfiles: ['fast', 'deep', 'review', 'unused'] },
      fakeRecorder(),
    )).toThrow(/requires exactly the fast, deep, and review profiles/)
  })

  it('rejects allowlisted workflows without a package-owned result contract', async () => {
    const lab = await makeLab()
    expect(() => new ProfiledDynamicWorkflowRunner(
      new FakeEngine() as unknown as WorkflowEngine,
      { ...lab.config, allowedWorkflows: ['multi-model-review', 'other'] },
      fakeRecorder(),
    )).toThrow(/result contract only for the multi-model-review/)
  })

  it('accepts one complete json fence but no surrounding prose', async () => {
    const lab = await makeLab()
    const engine = new FakeEngine()
    engine.result = Promise.resolve({
      value: `\`\`\`json\n${JSON.stringify(VALID_RESULT)}\n\`\`\``,
      stopReason: 'completed',
      agentsStarted: 7,
    })
    const runner = new ProfiledDynamicWorkflowRunner(engine as unknown as WorkflowEngine, lab.config, fakeRecorder())
    const result = await runner.run({
      workflow: 'multi-model-review',
      task: 'review this',
      parent: { id: 'parent', options: { provider: 'parent', model: 'parent' } } as Agent,
      signal: new AbortController().signal,
    })
    expect(result.result).toEqual(VALID_RESULT)
  })

  it.each([
    {
      name: 'engine error result',
      makeResult: () => Promise.resolve({ value: null, stopReason: 'error' as const, error: 'script failed', agentsStarted: 1 }),
      expected: 'script failed',
      hasPartialReceipt: true,
      disposeError: undefined,
    },
    {
      name: 'engine and disposal error',
      makeResult: () => Promise.resolve({ value: null, stopReason: 'error' as const, error: 'script failed', agentsStarted: 1 }),
      expected: 'script failed; workflow dispose failed: cleanup failed',
      hasPartialReceipt: true,
      disposeError: 'cleanup failed',
    },
    {
      name: 'defensive result rejection',
      makeResult: () => {
        const result = Promise.reject(new Error('engine contract violation'))
        void result.catch(() => undefined)
        return result
      },
      expected: 'engine contract violation',
      hasPartialReceipt: false,
      disposeError: undefined,
    },
  ])('disposes exactly once for $name', async ({ makeResult, expected, hasPartialReceipt, disposeError }) => {
    const lab = await makeLab()
    const engine = new FakeEngine()
    engine.result = makeResult()
    if (disposeError !== undefined) engine.dispose.mockRejectedValueOnce(new Error(disposeError))
    const telemetry = fakeRecorder()
    const abandon = vi.spyOn(telemetry, 'abandon')
    const runner = new ProfiledDynamicWorkflowRunner(engine as unknown as WorkflowEngine, lab.config, telemetry)
    const rejection = runner.run({
      workflow: 'multi-model-review',
      task: 'review this',
      parent: { id: 'parent', options: { provider: 'parent', model: 'parent' } } as Agent,
      signal: new AbortController().signal,
    })
    await expect(rejection).rejects.toThrow(expected)
    if (hasPartialReceipt) {
      await expect(rejection).rejects.toThrow(/partialWorkflowReceipt=.*"runId":"fake-run-1".*"agentsStarted":1.*"result":null/u)
    } else {
      await expect(rejection).rejects.not.toThrow(/partialWorkflowReceipt/u)
    }
    expect(engine.dispose).toHaveBeenCalledTimes(1)
    expect(abandon).toHaveBeenCalledExactlyOnceWith('fake-run-1')
  })

  it.each([
    {
      name: 'only two findings',
      value: { ...VALID_RESULT, findings: VALID_RESULT.findings.slice(0, 2) },
      expected: /must NOT have fewer than 3 items/,
    },
    {
      name: 'four findings',
      value: { ...VALID_RESULT, findings: [...VALID_RESULT.findings, VALID_RESULT.findings[0]] },
      expected: /must NOT have more than 3 items/,
    },
    {
      name: 'missing one required field',
      value: {
        ...VALID_RESULT,
        findings: [
          { sourceLocations: ['src/a.ts:1'], failureScenario: '失败', rankingRationale: '理由' },
          VALID_RESULT.findings[1],
          VALID_RESULT.findings[2],
        ],
      },
      expected: /must have required property 'fixSuggestion'/,
    },
    {
      name: 'additional finding field',
      value: {
        ...VALID_RESULT,
        findings: [
          { ...VALID_RESULT.findings[0], severity: 'high' },
          VALID_RESULT.findings[1],
          VALID_RESULT.findings[2],
        ],
      },
      expected: /must NOT have additional properties/,
    },
    {
      name: 'blank rationale',
      value: {
        ...VALID_RESULT,
        findings: [
          { ...VALID_RESULT.findings[0], rankingRationale: '   ' },
          VALID_RESULT.findings[1],
          VALID_RESULT.findings[2],
        ],
      },
      expected: /must match pattern/,
    },
    {
      name: 'invalid source location',
      value: {
        ...VALID_RESULT,
        findings: [
          { ...VALID_RESULT.findings[0], sourceLocations: ['src/a.ts'] },
          VALID_RESULT.findings[1],
          VALID_RESULT.findings[2],
        ],
      },
      expected: /must match pattern/,
    },
    {
      name: 'blank source path',
      value: {
        ...VALID_RESULT,
        findings: [
          { ...VALID_RESULT.findings[0], sourceLocations: ['   :1'] },
          VALID_RESULT.findings[1],
          VALID_RESULT.findings[2],
        ],
      },
      expected: /must match pattern/,
    },
    {
      name: 'URI instead of file path',
      value: {
        ...VALID_RESULT,
        findings: [
          { ...VALID_RESULT.findings[0], sourceLocations: ['https://example.test/a.ts:1'] },
          VALID_RESULT.findings[1],
          VALID_RESULT.findings[2],
        ],
      },
      expected: /must match pattern/,
    },
    {
      name: 'reversed source range',
      value: {
        ...VALID_RESULT,
        findings: [
          { ...VALID_RESULT.findings[0], sourceLocations: ['src/a.ts:9-2'] },
          VALID_RESULT.findings[1],
          VALID_RESULT.findings[2],
        ],
      },
      expected: /range ends before it starts/,
    },
    {
      name: 'prose wrapped JSON',
      value: `Here is the result: ${JSON.stringify(VALID_RESULT)}`,
      expected: /not one complete JSON document/,
    },
  ])('fails loudly for schema-invalid completed output: $name', async ({ value, expected }) => {
    const lab = await makeLab()
    const engine = new FakeEngine()
    engine.result = Promise.resolve({
      value: typeof value === 'string' ? value : JSON.stringify(value),
      stopReason: 'completed',
      agentsStarted: 7,
    })
    const runner = new ProfiledDynamicWorkflowRunner(engine as unknown as WorkflowEngine, lab.config, fakeRecorder())
    await expect(runner.run({
      workflow: 'multi-model-review',
      task: 'review this',
      parent: { id: 'parent', options: { provider: 'parent', model: 'parent' } } as Agent,
      signal: new AbortController().signal,
    })).rejects.toThrow(expected)
    expect(engine.dispose).toHaveBeenCalledTimes(1)
  })

  it('rejects an oversized synthesis before JSON parsing', async () => {
    const lab = await makeLab()
    const engine = new FakeEngine()
    engine.result = Promise.resolve({
      value: JSON.stringify({ ...VALID_RESULT, summary: 'x'.repeat(50_000) }),
      stopReason: 'completed',
      agentsStarted: 7,
    })
    const runner = new ProfiledDynamicWorkflowRunner(engine as unknown as WorkflowEngine, lab.config, fakeRecorder())
    await expect(runner.run({
      workflow: 'multi-model-review',
      task: 'review this',
      parent: { id: 'parent', options: { provider: 'parent', model: 'parent' } } as Agent,
      signal: new AbortController().signal,
    })).rejects.toThrow(/exceeds maxResultChars/)
    expect(engine.dispose).toHaveBeenCalledTimes(1)
  })
})
