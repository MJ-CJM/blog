# DeepSeek Harness Evidence-Gated Workflow 中文运行与验收手册

本文档用于在不调用模型、不读取或复制凭据的前提下完成本地验收，并在用户自行配置模型提供方后分别运行 Stock AgentLoop、继承式 Adapter 与完全独立的 Full Custom Loop 三条实验路径。

实验根目录为：

```text
/path/to/dsh-evidence-workflow
```

四棵共享树 `contract/`、`agents/`、`skills/evidence-gated-change/`、`fixtures/todo-service/` 是与 Pi 对照实验共用的 portable contract，不应在 DSH 平台调试时单独修改。当前聚合 SHA-256 为：

```text
4285706cc55f6c2065552c9a727a472181caa36c7d2e5ef1efb7cfb024421e87
```

## 1. 环境与无模型验收

### 1.1 Node 与依赖

验证器要求 Node 25 或更高版本。Node 24 的 permission model 没有本实验需要的网络权限范围，验证器会直接失败，而不是降级运行。

```sh
cd /path/to/dsh-evidence-workflow
node -v
npx --yes pnpm@11.19.0 install
```

`node -v` 应显示 `v25.x` 或更新版本。如果本机依赖缓存完整，也可以用 `pnpm install --offline`。Codex 内置的 `pnpm` 启动器可能打印它自身运行在 Node 24 的 engine warning；真正验收的是 `node`、Vitest 和验证子进程看到的版本，测试中有显式 Node 25 断言。

如果终端提示 `pnpm: command not found`，不需要全局安装 pnpm；把下文任何 `pnpm ...` 改写为 `npx --yes pnpm@11.19.0 ...` 即可。本手册的 Web 命令均使用这一形式。

### 1.2 构建、测试与 Profile 验收

完整验收命令为：

```sh
cd /path/to/dsh-evidence-workflow
npx --yes pnpm@11.19.0 run check
```

它依次执行：

```sh
pnpm run build
pnpm run test:typecheck
pnpm run test
pnpm run profile:dump
```

当前预期结果：

- 五个本地包编译成功。
- 测试类型检查成功。
- 10 个测试文件、83 个测试全部通过；其中原 EGC 的 6 个文件、26 个测试保持不变，Dynamic Workflow 的 3 个文件、41 个测试覆盖真实 rc.6 worker、Schema、telemetry、失败回执与执行/清理双故障，Full Custom Loop 的 1 个文件、16 个测试覆盖独立性、公共服务组合、根/子 Agent 两种算法路径、根与子 Agent 的独立预算、生命周期、取消、严格串行工具、运行时上下文首次快照/去重/清空/恢复、跨全新 Context 的 JSONL Turn 边界恢复、Owner 卸载时放弃迟到的 persistence preparation、局部清理失败后的 Registry/Owner 解绑，以及 Service 卸载多个活跃 Agent 的收敛。
- `egc-stock`、`egc-loop-adapter`、`egc-loop-full-custom`、`egc-web-stock`、`egc-web-adapter`、`egc-web-full-custom` 六份有效配置均通过硬断言并写入 `profile-dumps/`。
- 全程不启动模型、不读取凭据。

构建产物位于五个本地 package 的 `lib/` 下，可用下面的命令快速确认：

```sh
test -f packages/workflow-core/lib/index.js
test -f packages/workflow-plugin/lib/index.js
test -f packages/agent-loop-adapter/lib/index.js
test -f packages/dynamic-workflow/lib/index.js
test -f packages/agent-loop-full-custom/lib/index.js
echo 'five DSH packages built'
```

### 1.3 Profile 组合应满足的条件

`pnpm run profile:dump` 不只是保存配置，还会直接断言以下条件：

| Profile | 官方 `@deepseek-ai/dsh-agent-loop` | 继承式 Adapter | Full Custom Factory | 有效 AgentFactory 数量 |
| --- | --- | --- | --- | --- |
| `egc-stock` | 启用 | 不存在 | 不存在 | 1 |
| `egc-loop-adapter` | 禁用 | 启用 | 不存在 | 1 |
| `egc-loop-full-custom` | 禁用 | 不存在 | 启用 | 1 |

第三条会额外断言 `@local/dsh-full-custom-loop` 不依赖、不继承官方 AgentLoop；完整边界矩阵见 [`packages/agent-loop-full-custom/README.md`](./packages/agent-loop-full-custom/README.md)。

三套 Profile 还必须同时包含：

- `@local/dsh-egc-workflow` 固定 Workflow/Tool 插件。
- `@local/dsh-dynamic-workflow` saved-workflow wrapper。
- 恰好一个启用的官方 `@deepseek-ai/dsh-workflow-worker-thread`，没有替换 WorkflowEngine。
- `@deepseek-ai/dsh-skill-filesystem`，且 `includeDefaultRoots: false`。
- 唯一 custom Skill 根 `/path/to/dsh-evidence-workflow/skills`。

因此 Skill 不是仅供静态对照的 Markdown：真实 rc.6 Skill registry 与 filesystem provider 会发现 `evidence-gated-change` 和 `profiled-dynamic-workflow`，同时不会混入项目或用户的其他 Skill。

Web 三套 Profile 的 Host 层还会额外断言：

- Web server、Web runtime、client modules、connection 与 Agent Preset roster 各有且只有一个有效实例。
- Stock/Adapter 默认 Agent Preset 为用户级 `egc-web`，页面显示 `EGC Web 实验`；Full Custom 使用 `egc-web-full-custom`，页面显示 `EGC Full Custom Loop 实验`。
- Host 层的 WorkflowEngine、Skill provider 和两个本地 Tool 都不启用；它们只在 `egc-web` 会话作用域挂载。
- `egc-web-stock` 使用官方 AgentLoop；`egc-web-adapter` 只使用本地 AgentLoop adapter；`egc-web-full-custom` 只使用完全独立的 Full Custom Loop。

### 1.4 Dynamic Workflow 无模型验收

下面两条测试分别覆盖 wrapper policy 与真实原生 engine；都不调用模型：

```sh
pnpm exec vitest run tests/dynamic-workflow.test.ts
pnpm exec vitest run tests/dynamic-workflow-native.test.ts
pnpm exec vitest run tests/dynamic-workflow-telemetry.test.ts
```

三者依次验证：严格首行 meta、profile/Schema fail-loud、path fence 与 fake engine 生命周期；与 Pi 字节一致的脚本在真实 rc.6 worker-thread WorkflowEngine 上以 7 个 fake Subagent 完成 happy path，并对单路退化、review/final 失败 fail-closed；以及公开 workflow/Session 事件折叠、并发 run 隔离、缺失 end 与不可观测 retry 的诚实标记。

冻结脚本 SHA-256 为：

```text
03f7a6ae63a3f0b17060e03cf2fa7f972a564a77691a099d992b65b6695edada
```

`dynamic-workflow/shared/manifest.json` 使用相同的 `path\0fileSha256\0` 聚合规则；自身不参与聚合，冻结 aggregate 为：

```text
db61f13dca3a75662261dd72f21d603c4c85d79bc1b85ddd8baaf6f2cb3f9776
```

### 1.5 通过网页验证插件

这里不需要“先启动 DSH，再单独启动插件”。Web Profile、`egc-web` Agent Preset 与两个本地插件是一份组合；页面启动后，新建实验会话时插件会自动挂载。

首次或依赖有变化时执行：

```sh
cd /path/to/dsh-evidence-workflow
npx --yes pnpm@11.19.0 install
npx --yes pnpm@11.19.0 run build
```

启动 Stock Web：

```sh
npx --yes pnpm@11.19.0 run web:stock
```

看到终端输出类似下面一行后再打开浏览器：

```text
dsh web: http://127.0.0.1:3080
```

页面验收顺序：

1. 新建会话，确认 Agent Preset 是 `EGC Web 实验`；旧会话不会自动切换 Preset。
2. 打开 Skill 选择/输入触发器，确认只出现 `evidence-gated-change` 与 `profiled-dynamic-workflow`。
3. 在 Settings → Plugins 中，创建会话后应能看到 `@local/dsh-egc-workflow` 与 `@local/dsh-dynamic-workflow` 为 active。
4. 不调用模型的验收到这里已经完成；仅打开页面、创建空白会话和查看插件不会消耗模型额度。
5. 如需真实验证 Dynamic Workflow，在实验根目录会话中发送：

```text
加载 profiled-dynamic-workflow Skill，然后调用 profiled_dynamic_workflow，workflow 使用 multi-model-review，task 使用：“只审查 packages/dynamic-workflow/src/index.ts，严格输出三个最值得优先修复的架构风险，每项包含 file:line、失败场景、排序理由和修复建议，最终用中文。”最后完整报告 runId、agentsStarted、profiles、resolvedRoutes、timings、retryCount、retryTelemetryComplete、routeTelemetryComplete、agentOutcomes、outcomeTelemetryComplete 和 result。
```

成功标准：happy path 的 `agentsStarted` 为 7；若一个 Pro-profile 独立评审失败但 Flash 与另一个 Pro 均成功，允许以 6 个 Agent 收敛。若唯一 Flash 审查失败，工具必须 fail-closed，不能把只由 Pro 产生的结果称作多模型。成功时 `result.findings` 严格三项，并同时报告两个 telemetry completeness 字段。当前 wrapper 会在普通 Tool 卡中显示执行状态和最终结果，但不会生成官方 `ui-workflow-run` 的专用进度图；这是因为实验有意不向模型暴露可执行任意 JavaScript 的官方 raw workflow tool，也尚未复制它的 recorder 协议。

Stock 验收完按 `Ctrl+C` 停止。验证 AgentLoop Adapter：

```sh
npx --yes pnpm@11.19.0 run web:adapter
```

再次新建 `EGC Web 实验` 会话并重复上面步骤。Settings → Plugins 还应显示 `@local/dsh-egc-agent-loop` active。若要同时运行两套页面，Adapter 改用另一个端口：

```sh
npx --yes pnpm@11.19.0 run web:adapter -- --port 3081
```

验证完全独立的 Loop 时，先停止 Stock/Adapter，再运行：

```sh
npx --yes pnpm@11.19.0 run web:full-custom
```

新建会话并确认 Preset 为 `EGC Full Custom Loop 实验`。先发送：

```text
调用 full_loop_diagnostics，只报告 implementation、algorithm、inheritsOfficialAgentLoop、usesOfficialReactLoopAgent、toolScheduling、experimentalSeams、limits、currentTurnUsage 和 traceFile。
```

成功证据不是“回答必须和 Stock 不同”，而是以下证据同时成立：

- `profile-dumps/egc-web-full-custom.yml` 中官方 `agent-loop` 禁用，且 `full-custom-agent-loop` 是唯一有效 Factory；
- 诊断返回 `implementation=@local/dsh-full-custom-loop`、`inheritsOfficialAgentLoop=false`、`usesOfficialReactLoopAgent=false` 与 `toolScheduling=strictly-serial`；
- 根 Agent 的 Session 中出现本地 Plan、Act、Reflect、Finalize 驱动的标准 Turn/Step/assistant/tool 事件；
- `lab-home/full-custom-loop/<sessionId>/loop-trace.jsonl` 记录相同阶段与预算；
- 相同 Dynamic Workflow 仍能复用官方 WorkflowEngine、Subagent、模型 route、Tools 和 Web。

三套 Web Profile 均使用实验目录内的 `lab-home`，不会修改已有的 `/path/to/.dsh/profiles/web`。服务只应监听本机；不要把 developer-preview Web 服务暴露到不可信网络。

## 2. Stock AgentLoop 完整实践

### 2.0 确认模型与凭据边界

当前隔离 Profile 的默认 route/model 是 `deepseek-official/deepseek-v4-flash`。它可以从启动进程继承 `DEEPSEEK_API_KEY`，但本实验不会复制现有 `.dsh`、`.env` 或凭据文件。启动真实模型前可只检查“是否已注入”，不要打印密钥值：

```sh
test -n "${DEEPSEEK_API_KEY:-}" \
  && echo 'DEEPSEEK_API_KEY is configured for this shell' \
  || echo 'DEEPSEEK_API_KEY is missing'
```

建议通过现有密码管理器、shell 会话或 CI secret 注入密钥；不要把真实值写入本仓库、Runbook、命令脚本或 Git。若你改用其他 provider/model，需要先为隔离 Profile 增加经过审查的配置层，并重新执行 `pnpm run profile:dump`，不能只改 Prompt。

### 2.1 准备隔离运行目录

准备动作必须发生在启动 DSH 之前：

```sh
cd /path/to/dsh-evidence-workflow
pnpm run build
pnpm prepare-run -- stock-001
```

预期阶段为 `baseline_captured`，并创建：

```text
runs/stock-001/workspace
```

每次实验都使用全新的 runId。不要复用已完成、blocked、cancelled 或卡在中间阶段的目录。

### 2.2 必须从精确 workspace cwd 启动 plan

rc.6 的 Subagent 没有独立 cwd 参数，而是继承父 Agent 的 cwd。因此 plan、status、execute 都必须从精确路径 `runs/<runId>/workspace` 启动；从实验根目录启动会被插件 fail-closed 拒绝。

```sh
export DSH_HOME=/path/to/dsh-evidence-workflow/lab-home
export DSH_AGENTS_HOME=/path/to/dsh-evidence-workflow/.agents
cd /path/to/dsh-evidence-workflow/runs/stock-001/workspace
/path/to/dsh-runtime/node_modules/.bin/dsh --profile egc-stock \
  'Load the evidence-gated-change Skill, then call evidence_gated_change with action plan and runId stock-001. Stop after the tool returns.'
```

正常情况下会经历：

```text
baseline_captured → discovering → planning → awaiting_approval
```

Code Scout 与 Test Scout 并行运行，Planner 随后生成 `plan.json`。返回结果和 `state.json` 都会显示 `planHash` 与 `approvalHash`。

### 2.3 人工审查与外部批准

回到实验根目录，至少审查以下文件：

```text
runs/stock-001/baseline.json
runs/stock-001/discovery-code.json
runs/stock-001/discovery-tests.json
runs/stock-001/plan.json
runs/stock-001/state.json
runs/stock-001/report.md
```

`approvalHash` 是对 `{planHash, baselineHash, contractHash, runtimeHash}` 的 canonical SHA-256。批准命令要求输入返回结果或 `state.json` 中显示的准确 `approvalHash`，不能输入 `planHash`：

```sh
cd /path/to/dsh-evidence-workflow
DSH_EGC_APPROVAL_HASH='把 state.json 中的 approvalHash 粘贴到这里'
pnpm approve -- stock-001 "$DSH_EGC_APPROVAL_HASH"
```

批准由实验根目录中的外部命令执行；模型工具没有 approve action。批准后会生成 `approval.json`，阶段仍为 `awaiting_approval`，等待下一次 execute。审批记录中的操作者名称只是本地审计标签，不是加密身份凭证。

### 2.4 使用新进程执行 execute

不要继续使用 plan 的模型进程。重新从同一个精确 workspace cwd 启动一个 DSH 进程：

```sh
cd /path/to/dsh-evidence-workflow/runs/stock-001/workspace
/path/to/dsh-runtime/node_modules/.bin/dsh --profile egc-stock \
  'Load the evidence-gated-change Skill, then call evidence_gated_change with action execute and runId stock-001. Report the final stage.'
```

正常路径为：

```text
awaiting_approval → implementing → reviewing_verifying → completed
```

Reviewer 与固定 verifier 并行运行。任何确定性验证失败都会进入最多一次 Repair；修复后仍失败、审批证据缺失、哈希漂移或异常都会收敛到 `blocked` 或 `cancelled`，不会由 Reviewer 文本覆盖。

## 3. AgentLoop Adapter 完整实践

Adapter 必须使用另一个 fresh runId：

```sh
cd /path/to/dsh-evidence-workflow
pnpm run build
pnpm prepare-run -- adapter-001

export DSH_HOME=/path/to/dsh-evidence-workflow/lab-home
export DSH_AGENTS_HOME=/path/to/dsh-evidence-workflow/.agents
cd /path/to/dsh-evidence-workflow/runs/adapter-001/workspace
/path/to/dsh-runtime/node_modules/.bin/dsh --profile egc-loop-adapter \
  'Load the evidence-gated-change Skill, then call evidence_gated_change with action plan and runId adapter-001. Stop after the tool returns.'
```

随后回到实验根目录审查 `adapter-001` 的证据并批准：

```sh
cd /path/to/dsh-evidence-workflow
DSH_EGC_APPROVAL_HASH='把 adapter-001/state.json 中的 approvalHash 粘贴到这里'
pnpm approve -- adapter-001 "$DSH_EGC_APPROVAL_HASH"
```

再启动一个新进程执行：

```sh
cd /path/to/dsh-evidence-workflow/runs/adapter-001/workspace
/path/to/dsh-runtime/node_modules/.bin/dsh --profile egc-loop-adapter \
  'Load the evidence-gated-change Skill, then call evidence_gated_change with action execute and runId adapter-001. Report the final stage.'
```

Stock 与 Adapter 应完成同一 portable contract。区别只在 AgentFactory 组合：Adapter 在公开 `createAgent()` 与 `resume()` setup 中安装 supervisor，并继续使用官方私有 driver；它不会复制或替换 ReAct step 算法。

## 3.5 Full Custom Loop 能力边界实践

这条实践与 Adapter 不同：`@local/dsh-full-custom-loop` 直接实现公共 `AgentFactory` 与 `Agent`，不导入、不继承官方 `@deepseek-ai/dsh-agent-loop`。它自己承担 Inbox 驱动、Turn/Step 状态、模型调用、严格串行工具、取消、Owner 绑定与卸载；同时有意复用 DSH 的 Registry、Scope、Session、LLM、System Prompt、Tools/Guard/Approval、Web、Subagent 与 WorkflowEngine。

先跑不调用外部模型的定向证据：

```sh
cd /path/to/dsh-evidence-workflow
npx --yes pnpm@11.19.0 exec vitest run tests/full-custom-loop.test.ts
npx --yes pnpm@11.19.0 run profile:dump
```

这会证明：源码/manifest 没有官方 AgentLoop、ReactLoopAgent 或内部 tool scheduler；根 Agent 以及显式配置的子 Agent 可经本地 fake LLM 完成 Plan→Act→Reflect→Finalize，默认子 Agent 则走 `direct-budgeted`；根 Agent 保持 `8` 次模型调用 / `4` 次工具调用，子 Agent 单独使用 `12` / `8`，并有回归测试证明子 Agent 可完成第 5 次工具调用而没有放宽根预算；工具不会重叠；两次 Turn 预算独立；运行时上下文快照与阶段提示分源且可去重/恢复；`agent/pre-step` reject 会成为 blocked turn；正常取消不误报 `agent/error` 且仍闭合标准事件；仅声明 `agents` 注入的真实 owner 能在卸载时清理 Agent/Session；Service 卸载也会取消并移除所有活跃 Agent。

如需真实模型，可从实验根目录运行 Headless Full Custom Profile：

```sh
cd /path/to/dsh-evidence-workflow
export DSH_HOME=/path/to/dsh-evidence-workflow/lab-home
export DSH_AGENTS_HOME=/path/to/dsh-evidence-workflow/.agents
/path/to/dsh-runtime/node_modules/.bin/dsh --profile egc-loop-full-custom \
  '先调用 full_loop_diagnostics，再加载 profiled-dynamic-workflow Skill，调用 profiled_dynamic_workflow 运行 multi-model-review；最后报告 Loop 诊断和 Workflow 回执。'
```

Dynamic Workflow 子 Agent 默认使用本包的 `direct-budgeted` 路径，仍由自研 Agent 驱动，但不为每个子 Agent 再展开完整 Plan/Reflect，以免七个子 Agent 造成不必要的调用放大。子 Agent 的 `12/8` 预算与根 Agent 的 `8/4` 预算分离；这次边界修复针对代码审查的多次只读取证，不改变多模型路由门禁。Resume 只承诺在新 Turn 边界恢复后重新规划，不声称从 Plan/Act/Reflect 中点继续。

最重要的负面结论也必须保留：正确消费 Inbox 只能调用根包导出的 `Inbox.claim()`，而 rc.6 类型声明把它标为 `@internal`。因此 rc.6 已经足以替换 Loop 算法，但“完全建立在稳定公开接缝上”仍差这一块。

## 4. Profiled Dynamic Workflow 实践

这条实践与 EGC run 并列，不使用 `prepare-run`、`approvalHash` 或 EGC 状态机。必须从实验根目录启动；不要从 `runs/<runId>/workspace` 调用，因为 EGC guard 会有意拒绝这个非 EGC 编排工具。

平台配置位于：

```text
dynamic-workflow/dsh/model-profiles.json
```

固定逻辑 profile 为 `fast`、`deep`、`review`。缺失的 `provider` 或 `model` 字段会逐字段继承父 Agent route；最终三个 profile 仍必须解析成至少两个不同组合。不得写入 API key 等凭据；`thinking`、`tools`、`maxTokens` 以及其他未知字段会 fail-loud，不会静默降级。填写真实 provider/model 前应先确认用户已在外部环境自行配置相应凭据。

当前静态配置是三个逻辑 profile、两个真实 route：`fast → deepseek-official/deepseek-v4-flash`，`deep → deepseek-official/deepseek-v4-pro`，`review → deepseek-official/deepseek-v4-pro`。

`multi-model-review` 会在启动前把 profile 与父 Agent route 逐字段合并，返回 `resolvedRoutes`，并要求至少两个不同的 provider/model 组合。独立评审后还会检查成功的请求路由；整轮结束后再用各子 Session 的 `finalObservedRoute` 验证实际请求未塌缩成一个模型。无法观察实际路由时不会冒充“已验证多模型”。运行回执还包含：

- `timings.runDurationMs` 与三个 `phase()` 区间；
- `retryCount`（实际观察到的 `llm/retry-started` 次数）；当 `retryTelemetryComplete=false` 时，它只是已观测到的下界，单项 `retryCount:null` 表示未知而不是 0；
- `agentOutcomes`（seq、label、phase、childId、outcome、耗时、子 Agent 路由与重试）；其中 `observedRoutes` 是子 Session 中的实际请求证据，区别于配置合并得到的预期 `resolvedRoutes`；
- `retryTelemetryComplete` / `routeTelemetryComplete` / `outcomeTelemetryComplete`：依次表示所有 child retry 可观察、所有 child 最终请求路由可观察、workflow agent-start/end 配对覆盖完整；都不表示所有 Agent 成功。

最终 `result` 不再接受任意散文。DSH 门面会用 `packages/dynamic-workflow/schemas/multi-model-review.schema.json` 做 Ajv 2020 权威校验：`findings` 必须严格三项，每项恰好包含 `sourceLocations`、`failureScenario`、`rankingRationale`、`fixSuggestion` 四个字段。少项、多项、空白、额外字段或不合法 `file:line` 均以 `WORKFLOW_RESULT_SCHEMA_INVALID` 失败；不会返回部分结果或偷偷再起第八个修复 Agent。

若工作流在 Schema 验证前失败，工具仍返回错误，但错误正文会附带 `partialWorkflowReceipt`：其中保留 runId、已启动 Agent 数、resolved routes、阶段耗时、重试和已观察到的 child outcomes，`result` 明确为 `null`。因此不要再把“外层 Turn completed”或页面生成的解释当作工作流成功证据。

Stock Profile 实际调用：

```sh
cd /path/to/dsh-evidence-workflow
export DSH_HOME=/path/to/dsh-evidence-workflow/lab-home
export DSH_AGENTS_HOME=/path/to/dsh-evidence-workflow/.agents
/path/to/dsh-runtime/node_modules/.bin/dsh --profile egc-stock \
  'Load the profiled-dynamic-workflow Skill, then call profiled_dynamic_workflow with workflow multi-model-review and task "Review the public API boundary of this harness". Report runId, agentsStarted, profiles, resolvedRoutes, timings, retryCount, retryTelemetryComplete, routeTelemetryComplete, agentOutcomes, outcomeTelemetryComplete, and result.'
```

Adapter Profile 使用新的 DSH 进程，从同一实验根目录启动并把 `--profile egc-stock` 改为 `--profile egc-loop-adapter`。完整 happy path 依次执行三个并行独立审查、三个 pipeline challenge 和一个 synthesis，预期 `agentsStarted=7`、`routeTelemetryComplete=true`、`outcomeTelemetryComplete=true`、`result.findings.length=3`；允许的降级成功路径为 6 个 Agent，但仍必须有两个不同的成功独立审查 route。两次真实调用都会消耗模型额度；本手册不读取、复制或写入凭据。

wrapper 只负责 allowlisted source、profile policy 和 run 生命周期；实际 `agent/parallel/pipeline/phase/log/args` 都由官方 `ctx.workflowEngine` 执行。共享脚本是可信本地代码，worker/vm 是执行隔离与强制终止机制，不是恶意代码 sandbox。

## 5. 查询 status

`status` 在正常路径上只读取工作流状态，但仍要求精确 workspace cwd；如果发现崩溃遗留的 journal/state 不一致，底层 reconciliation 会写入 fail-closed 收敛记录。例如查询 stock run：

```sh
cd /path/to/dsh-evidence-workflow/runs/stock-001/workspace
/path/to/dsh-runtime/node_modules/.bin/dsh --profile egc-stock \
  'Load the evidence-gated-change Skill, then call evidence_gated_change with action status and runId stock-001.'
```

查询 adapter run 时改用对应 runId 与 `--profile egc-loop-adapter`。同一 runId 不要同时启动多个 plan、approve、execute 或 status 进程。

## 6. 产物与验收含义

一个完成的 run 至少包含：

| 产物 | 含义 |
| --- | --- |
| `events.jsonl` | 阶段事实以及 operation intent/settled 证据 |
| `state.json` | 当前阶段、四类哈希、Repair 次数和 pending operation |
| `baseline.json` | fixture/workspace、portable contract 与 runtime 初始哈希 |
| `discovery-code.json` | Code Scout 的 schema-valid 发现 |
| `discovery-tests.json` | Test Scout 的 schema-valid 发现 |
| `plan.json` | 仅允许修改三个文件的 canonical 计划与 `planHash` |
| `approval.json` | 绑定四类哈希的外部批准回执 |
| `implementation.json` | Implementer 修改摘要；Repair 时另有 repair receipt |
| `patch.diff` | fixture 与隔离 workspace 的真实差异 |
| `review.json` | Reviewer 的语义判断 |
| `verification.json` | 三个真实进程回执与文件策略结果 |
| `report.md` | 当前阶段与最终结论 |

`verification.json.commands` 必须有三个回执：

1. 隔离 workspace 内的项目测试。
2. workspace 外、与 Pi 字节一致的 parent-owned external oracle。
3. 证明 `CreateTaskInput.requestId` 在类型层必填的 TypeScript probe。

只有三个批准文件可以变化：

```text
README.md
src/TodoService.ts
test/TodoService.test.ts
```

最终成功要求 `review.verdict == "pass"`、三个命令回执全部成功、文件集合精确匹配且 fixture baseline 未变化。最终阶段应为 `completed`；任何 gate 未满足时应为 `blocked`，而不是“部分成功”。

## 7. 能力与验证命令映射

以下命令都不调用模型：

| 能力或结论 | 验证命令 |
| --- | --- |
| 全部 package 编译、测试类型检查、EGC 26 项 + Dynamic Workflow 41 项 + Full Custom Loop 16 项 = 83 tests、Profile 组合 | `npx --yes pnpm@11.19.0 run check` |
| Portable manifest、Pi 字节一致性、完整 AJV、rc.6 transport schema、真实 Skill provider | `pnpm exec vitest run tests/contract.test.ts` |
| Happy path、三回执 verifier、审批与 workspace drift、缺审批、权限与 timeout 故障注入 | `pnpm exec vitest run tests/workflow.test.ts` |
| Root/Child 工具策略、真实 `file_path`、symlink 与未批准路径拒绝 | `pnpm exec vitest run tests/policy.test.ts` |
| operation intent/settled 与 crash reconciliation | `pnpm exec vitest run tests/store.test.ts` |
| Adapter pre-super fail-fast、setup commit 保留、direct create fail-loud、create/resume 注入 | `pnpm exec vitest run tests/adapter.test.ts` |
| Full Custom 无官方 Loop 依赖、公共服务组合、BPAR、串行工具、预算、blocked、cancel、owner teardown、JSONL Turn 边界 resume | `pnpm exec vitest run tests/full-custom-loop.test.ts` |
| public `ctx.subagents.start()` 请求字段、无独立 cwd、所有结果路径 exactly-once dispose | `pnpm exec vitest run tests/plugin.test.ts` |
| Saved source、profile fail-loud、path fence、fake engine forwarding/cancel/dispose/error | `pnpm exec vitest run tests/dynamic-workflow.test.ts` |
| 与 Pi 字节一致脚本、真实 rc.6 WorkflowEngine、7 个 fake Subagent、逐节点 provider/model | `pnpm exec vitest run tests/dynamic-workflow-native.test.ts` |
| phase/run 耗时、Session route/retry 证据、并发 run 隔离、缺失 end/remote Session 的不完整标记 | `pnpm exec vitest run tests/dynamic-workflow-telemetry.test.ts` |
| Stock/Adapter/Full-Custom 各恰好一个启用 AgentFactory、一个官方 WorkflowEngine、两个 wrapper 与 Skill 配置 | `pnpm run profile:dump` |
| 仅做包级 TypeScript 编译 | `pnpm run build` |
| 仅做测试源码类型检查 | `pnpm run test:typecheck` |

关键故障注入覆盖包括：

- 一个 Scout schema 失败、另一个挂起时，立即 abort 并 drain sibling。
- 弱实现可以骗过项目测试，但会被外部 oracle 拒绝。
- Agent 测试尝试写出 workspace、创建子进程或访问网络时得到 `ERR_ACCESS_DENIED`。
- 测试进程确认已安装 SIGTERM handler 后仍挂起，最终由 SIGKILL 收敛。
- 测试进程在 deadline 后响应 SIGTERM 并 `exit(0)`，整体仍判定失败。
- 错误 approval token、pre-approval workspace drift、缺失 approval artifact 均 fail-closed。
- 未结算 operation 在恢复时配对 crash-unknown settlement 并进入 blocked；settled event 已落但 state 尚未清除时可安全清除 pending。

## 8. 凭据与安全边界

- Keyless build/test/profile dump 不需要任何模型凭据，也不会读取、复制或迁移现有凭据。
- 真正的 stock/adapter 模型运行需要用户自行在隔离环境中配置可用 provider。本文档不要求粘贴密钥，也不会把现有 `.dsh`、环境文件或用户 Profile 复制进实验目录。
- Adapter 证明的是 L1 AgentFactory/Profile 替换和 setup composition，不是 L2 ReAct/step 算法替换。rc.6 的私有 driver 仍由官方实现拥有。
- Full Custom 证明的是 L2 AgentFactory/Agent/Turn/Step/模型与工具调度算法可被第三方重写；它仍复用 DSH 的 Registry、Session、LLM、Tools、Web 等 Harness 能力。它唯一主动使用的灰色 rc.6 seam 是标为 `@internal` 的 `Inbox.claim()`，因此属于明确固定版本的边界实验，不应包装成稳定生产扩展 API。
- Dynamic Workflow wrapper 复用官方 WorkflowEngine，只增加 saved source 与逻辑 profile policy；它不是另一个 DAG engine。rc.6 v1 只能逐节点传 `provider`/`model`，不能传 `thinking`、`tools` 或 `maxTokens`。
- Journal 能对 pending operation、settled/state-clear 和 event/state 不一致做安全收敛；但 operation 已完全 settled、下一阶段 transition 尚未提交的窗口没有语义续跑，run 可能安全卡住，应使用 fresh runId 重做。
- Node permission model 与 DSH tool guard 是针对已验证 escape 的纵深防御，不是恶意代码的操作系统 sandbox，也不证明审批者的真实身份。
- RunStore 使用原子文件替换，但没有跨进程锁。一个 runId 只允许一个操作者按顺序执行 prepare、plan、approve、execute/status；并发进程可能竞争，因此不属于本实验支持范围。
- Adapter 的 loop receipt 是 best-effort 观察证据，不参与状态机原子提交。

这些限制是博客对比的重要结论：DSH 的插件与 AgentFactory seam 足以实现受控工作流，但 durable workflow resume、跨进程协调和全新推理循环仍属于不同层级的问题。
