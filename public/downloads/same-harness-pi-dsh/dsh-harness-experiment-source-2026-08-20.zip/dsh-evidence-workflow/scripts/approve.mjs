import { EvidenceGatedWorkflow } from '@local/dsh-egc-core'

const [runId, approvalHash, approvedByArg] = process.argv.slice(2)
if (runId === undefined || approvalHash === undefined) {
  process.stderr.write('usage: pnpm approve -- <runId> <approvalHash> [approvedBy]\n')
  process.exitCode = 2
} else {
  const root = new URL('..', import.meta.url).pathname.replace(/\/$/, '')
  const workflow = new EvidenceGatedWorkflow({
    runRoot: `${root}/runs`,
    fixtureRoot: `${root}/fixtures/todo-service`,
    contractRoot: `${root}/contract`,
    runtimeRoot: root,
    oracleScript: `${root}/scripts/verify-fixture.mjs`,
    maxRepair: 1,
    verificationCommand: ['node', '--experimental-strip-types', 'test/TodoService.test.ts'],
    verificationTimeoutMs: 30_000,
    maxCapturedOutputBytes: 131_072,
  })
  const approvedBy = approvedByArg ?? process.env.USER ?? 'local-user'
  const receipt = await workflow.approve(runId, approvalHash, approvedBy)
  process.stdout.write(`${JSON.stringify(receipt, undefined, 2)}\n`)
}
