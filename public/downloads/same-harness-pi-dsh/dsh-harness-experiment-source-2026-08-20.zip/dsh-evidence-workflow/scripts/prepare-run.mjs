import { EvidenceGatedWorkflow } from '@local/dsh-egc-core'

const [runId] = process.argv.slice(2)
if (runId === undefined) {
  process.stderr.write('usage: pnpm prepare-run -- <runId>\n')
  process.exitCode = 2
} else {
  const root = new URL('..', import.meta.url).pathname.replace(/\/$/, '')
  const workflow = new EvidenceGatedWorkflow({
    runRoot: `${root}/runs`,
    fixtureRoot: `${root}/fixtures/todo-service`,
    contractRoot: `${root}/contract`,
    runtimeRoot: root,
    oracleScript: `${root}/scripts/verify-fixture.mjs`,
    maxRepair: 1,
    verificationCommand: ['node', '--experimental-strip-types', 'test/TodoService.test.ts'],
    verificationTimeoutMs: 30_000,
    maxCapturedOutputBytes: 131_072,
  })
  const summary = await workflow.prepare(runId, new AbortController().signal)
  process.stdout.write(`${JSON.stringify(summary, undefined, 2)}\n`)
  if (summary.stage !== 'baseline_captured') process.exitCode = 1
}
