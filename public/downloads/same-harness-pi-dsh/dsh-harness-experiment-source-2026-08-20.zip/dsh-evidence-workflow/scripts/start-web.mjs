import { spawnSync } from 'node:child_process'
import { existsSync } from 'node:fs'
import { fileURLToPath } from 'node:url'

const root = fileURLToPath(new URL('..', import.meta.url)).replace(/\/$/, '')
const dsh = '/path/to/dsh-runtime/node_modules/.bin/dsh'
const profile = process.argv[2]
const appArgs = process.argv.slice(3)
const allowedProfiles = new Set(['egc-web-stock', 'egc-web-adapter', 'egc-web-full-custom'])

function optionValue(name, fallback) {
  const index = appArgs.lastIndexOf(name)
  return index >= 0 && appArgs[index + 1] !== undefined ? appArgs[index + 1] : fallback
}

if (!allowedProfiles.has(profile)) {
  throw new Error(`unsupported Web profile ${JSON.stringify(profile)}`)
}
if (!existsSync(dsh)) {
  throw new Error(`DeepSeek Harness launcher not found: ${dsh}`)
}

process.stdout.write([
  `Starting isolated DeepSeek Harness Web profile: ${profile}`,
  `Requested URL: http://${optionValue('--host', '127.0.0.1')}:${optionValue('--port', '3080')}`,
  'Use the final "dsh web:" URL printed by DeepSeek Harness as the authoritative address.',
  'The local EGC and Dynamic Workflow plugins load with the profile; there is no second plugin-start command.',
  '',
].join('\n'))

const result = spawnSync(dsh, ['--profile', profile, ...appArgs], {
  cwd: root,
  env: {
    ...process.env,
    DSH_HOME: `${root}/lab-home`,
    DSH_AGENTS_HOME: `${root}/.agents`,
    DSH_TELEMETRY_DISABLED: '1',
  },
  stdio: 'inherit',
})

if (result.error !== undefined) throw result.error
if (result.signal !== null) {
  process.kill(process.pid, result.signal)
}
process.exit(result.status ?? 1)
