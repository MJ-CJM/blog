import { execFileSync } from 'node:child_process'
import assert from 'node:assert/strict'
import { mkdirSync, readFileSync, writeFileSync } from 'node:fs'

const root = new URL('..', import.meta.url).pathname.replace(/\/$/, '')
const dsh = '/path/to/dsh-runtime/node_modules/.bin/dsh'
const environment = {
  ...process.env,
  DSH_HOME: `${root}/lab-home`,
  DSH_AGENTS_HOME: `${root}/.agents`,
  DSH_TELEMETRY_DISABLED: '1',
}

mkdirSync(`${root}/profile-dumps`, { recursive: true })
const profiles = [
  { name: 'egc-stock', surface: 'headless', loop: 'stock' },
  { name: 'egc-loop-adapter', surface: 'headless', loop: 'adapter' },
  { name: 'egc-loop-full-custom', surface: 'headless', loop: 'full-custom' },
  { name: 'egc-web-stock', surface: 'web', loop: 'stock', preset: 'egc-web' },
  { name: 'egc-web-adapter', surface: 'web', loop: 'adapter', preset: 'egc-web' },
  { name: 'egc-web-full-custom', surface: 'web', loop: 'full-custom', preset: 'egc-web-full-custom' },
]

assert.equal(profiles.filter(profile => profile.loop === 'stock').length, 2, 'expected exactly two Stock profiles')
assert.equal(profiles.filter(profile => profile.loop === 'adapter').length, 2, 'expected exactly two Adapter profiles')
assert.equal(profiles.filter(profile => profile.loop === 'full-custom').length, 2, 'expected exactly two Full Custom profiles')
assert.equal(
  readFileSync(`${root}/lab-home/.agent-presets/egc-web-full-custom/agent.cordis.yml`, 'utf8'),
  readFileSync(`${root}/lab-home/.agent-presets/egc-web/agent.cordis.yml`, 'utf8'),
  'Full Custom Web preset must reuse the exact Stock/Adapter EGC and Dynamic Workflow composition',
)

for (const profile of profiles) {
  const output = execFileSync(dsh, ['--profile', profile.name, '--dump-config'], {
    cwd: root,
    env: environment,
    encoding: 'utf8',
  })
  assertProfile(profile, output)
  writeFileSync(`${root}/profile-dumps/${profile.name}.yml`, output)
  process.stdout.write(`validated and dumped ${profile.name}\n`)
}

function assertProfile(profile, output) {
  const { name, surface, loop, preset } = profile
  const rows = output.split(/(?=^- id: )/m).filter(row => row.startsWith('- id: '))
  const row = id => rows.find(value => value.startsWith(`- id: ${id}\n`))
  const rowsFor = id => rows.filter(value => value.startsWith(`- id: ${id}\n`))
  const official = row('agent-loop')
  const adapter = row('evidence-gated-agent-loop')
  const fullCustom = row('full-custom-agent-loop')
  const workflowEngine = row('workflow-worker-thread')
  const savedWorkflow = row('profiled-dynamic-workflow')
  assert.equal(rowsFor('agent-loop').length, 1, `${name}: expected exactly one official AgentLoop row`)
  assert.ok(rowsFor('evidence-gated-agent-loop').length <= 1, `${name}: duplicate adapter AgentLoop rows`)
  assert.ok(rowsFor('full-custom-agent-loop').length <= 1, `${name}: duplicate Full Custom Loop rows`)
  assert.ok(official?.includes("name: '@deepseek-ai/dsh-agent-loop'"), `${name}: official AgentLoop row missing`)

  if (surface === 'headless') {
    assert.ok(output.includes('- id: evidence-gated-change-workflow'), `${name}: workflow plugin row missing`)
    assert.ok(output.includes('providerName: evidence-gated-filesystem'), `${name}: isolated Skill provider missing`)
    assert.ok(output.includes('includeDefaultRoots: false'), `${name}: default Skill roots were not disabled`)
    assert.ok(output.includes('/dsh-evidence-workflow/skills'), `${name}: portable Skill root missing`)
    assert.equal(rowsFor('workflow-worker-thread').length, 1, `${name}: expected exactly one official WorkflowEngine row`)
    assert.ok(workflowEngine?.includes("name: '@deepseek-ai/dsh-workflow-worker-thread'"), `${name}: official WorkflowEngine row missing`)
    assert.ok(!workflowEngine.includes('disabled: true'), `${name}: official WorkflowEngine must be enabled`)
    assert.equal(rowsFor('profiled-dynamic-workflow').length, 1, `${name}: expected exactly one saved-workflow wrapper row`)
    assert.ok(savedWorkflow?.includes("name: '@local/dsh-dynamic-workflow'"), `${name}: saved-workflow wrapper missing`)
    assert.ok(!savedWorkflow.includes('disabled: true'), `${name}: saved-workflow wrapper must be enabled`)
    assert.ok(savedWorkflow.includes('/dynamic-workflow/shared/workflows'), `${name}: shared workflow root missing`)
    assert.ok(savedWorkflow.includes('/dynamic-workflow/dsh/model-profiles.json'), `${name}: DSH model profile catalog missing`)
    assert.ok(savedWorkflow.includes('- fast') && savedWorkflow.includes('- deep') && savedWorkflow.includes('- review'), `${name}: logical model profiles missing`)
    assert.equal(row('webserver'), undefined, `${name}: Headless profile unexpectedly contains a Web server`)
  } else {
    const webserver = row('webserver')
    const webRuntime = row('web-runtime')
    const modules = row('modules')
    const connection = row('connection')
    const presets = row('agent-presets')
    assert.ok(webserver?.includes("name: '@deepseek-ai/dsh-host-webserver'"), `${name}: Web server row missing`)
    assert.ok(!webserver.includes('disabled: true'), `${name}: Web server must be enabled`)
    assert.ok(webRuntime?.includes("name: '@deepseek-ai/dsh-web-app'"), `${name}: Web runtime row missing`)
    assert.ok(!webRuntime.includes('disabled: true'), `${name}: Web runtime must be enabled`)
    assert.ok(modules?.includes("name: '@deepseek-ai/dsh-client-modules'"), `${name}: Web client modules row missing`)
    assert.ok(!modules.includes('disabled: true'), `${name}: Web client modules must be enabled`)
    assert.ok(connection?.includes("name: '@deepseek-ai/dsh-client-connection'"), `${name}: Web connection row missing`)
    assert.ok(!connection.includes('disabled: true'), `${name}: Web connection must be enabled`)
    assert.ok(presets?.includes("name: '@deepseek-ai/dsh-agent-presets'"), `${name}: Agent Preset roster missing`)
    assert.ok(presets.includes(`default: ${preset}`), `${name}: ${preset} must be the default Agent Preset`)
    assert.ok(workflowEngine?.includes('disabled: true'), `${name}: Host WorkflowEngine must remain disabled`)
    assert.ok(row('tool-workflow')?.includes('disabled: true'), `${name}: raw Host workflow tool must remain disabled`)
    assert.ok(row('skill-filesystem')?.includes('disabled: true'), `${name}: Host Skill provider must remain disabled`)
    assert.ok(row('tool-skill')?.includes('disabled: true'), `${name}: Host Skill tool must remain disabled`)
    assert.equal(row('evidence-gated-change-workflow'), undefined, `${name}: EGC tool leaked from the Agent Preset into Host`)
    assert.equal(savedWorkflow, undefined, `${name}: Dynamic Workflow tool leaked from the Agent Preset into Host`)
    assert.equal(row('headless-startup'), undefined, `${name}: Web profile unexpectedly contains Headless startup`)
  }
  if (loop === 'stock') {
    assert.ok(!official.includes('disabled: true'), `${name}: official AgentLoop must be enabled`)
    assert.equal(adapter, undefined, `${name}: Adapter AgentLoop must be absent`)
    assert.equal(fullCustom, undefined, `${name}: Full Custom Loop must be absent`)
  } else if (loop === 'adapter') {
    assert.ok(official.includes('disabled: true'), `${name}: official AgentLoop must be disabled`)
    assert.ok(adapter?.includes("name: '@local/dsh-egc-agent-loop'"), `${name}: Adapter AgentLoop row missing`)
    assert.ok(!adapter.includes('disabled: true'), `${name}: Adapter AgentLoop must be enabled`)
    assert.equal(fullCustom, undefined, `${name}: Full Custom Loop must be absent`)
  } else {
    assert.equal(loop, 'full-custom', `${name}: unsupported loop mode ${loop}`)
    assert.ok(official.includes('disabled: true'), `${name}: official AgentLoop must be disabled`)
    assert.equal(adapter, undefined, `${name}: Adapter AgentLoop must be absent`)
    assert.ok(fullCustom?.includes("name: '@local/dsh-full-custom-loop'"), `${name}: Full Custom Loop row missing`)
    assert.ok(!fullCustom.includes('disabled: true'), `${name}: Full Custom Loop must be enabled`)
  }
  const activeFactories = [official, adapter, fullCustom].filter(value => value !== undefined && !value.includes('disabled: true'))
  assert.equal(activeFactories.length, 1, `${name}: expected exactly one enabled AgentLoop factory`)
}
