import { lstat, readFile, realpath } from 'node:fs/promises'
import { isAbsolute, relative, resolve } from 'node:path'

import type { Context } from '@deepseek-ai/cordis'
import Schema from '@deepseek-ai/schemastery'
import type { Agent, AgentOptions } from '@deepseek-ai/dsh-agent'
import { defineTool } from '@deepseek-ai/dsh-tools'
import type { WorkflowEngine, WorkflowMeta, WorkflowResult } from '@deepseek-ai/dsh-workflow'

import {
  loadResultContract,
  validateWorkflowResult,
  type ValidatedWorkflowResult,
} from './result-contract.js'
import {
  WorkflowTelemetryRecorder,
  type ModelRoute,
  type WorkflowExecutionTelemetry,
} from './telemetry.js'

export type {
  MultiModelReviewFinding,
  MultiModelReviewResult,
  ValidatedWorkflowResult,
} from './result-contract.js'
export type {
  AgentOutcomeReceipt,
  ModelRoute,
  PhaseTiming,
  WorkflowExecutionTelemetry,
} from './telemetry.js'

export const name = 'profiled-dynamic-workflow'
export const inject = ['tools', 'workflowEngine', 'sessions']

const WORKFLOW_NAME = /^[a-z][a-z0-9]*(?:-[a-z0-9]+)*$/
const PROFILE_NAME = /^[a-z][a-z0-9]*(?:-[a-z0-9]+)*$/
const META_PREFIX = 'export const meta = '
const SUPPORTED_PROFILE_FIELDS = new Set(['provider', 'model'])

export interface Config {
  workflowRoot: string
  modelProfilesFile: string
  allowedWorkflows: string[]
  requiredProfiles: string[]
  maxSourceBytes: number
  maxTaskChars: number
  maxResultChars: number
}

export const Config: Schema<Config> = Schema.object({
  workflowRoot: Schema.string().required(),
  modelProfilesFile: Schema.string().required(),
  allowedWorkflows: Schema.array(Schema.string()).default(['multi-model-review']),
  requiredProfiles: Schema.array(Schema.string()).default(['fast', 'deep', 'review']),
  maxSourceBytes: Schema.number().default(262_144),
  maxTaskChars: Schema.number().default(20_000),
  maxResultChars: Schema.number().default(50_000),
}) as Schema<Config>

export interface ModelTarget {
  readonly provider?: string
  readonly model?: string
}

export type ResolvedModelProfiles = Readonly<Record<string, ModelTarget>>
export type ResolvedModelRoutes = Readonly<Record<string, ModelRoute>>

export interface SavedWorkflowSource {
  readonly meta: WorkflowMeta
  readonly body: string
}

export interface ProfiledWorkflowRequest {
  readonly workflow: string
  readonly task: string
  readonly parent: Agent
  readonly signal: AbortSignal
}

export interface ProfiledWorkflowResult {
  readonly runId: string
  readonly agentsStarted: number
  readonly result: ValidatedWorkflowResult
  readonly profiles: ResolvedModelProfiles
  readonly resolvedRoutes: ResolvedModelRoutes
  readonly timings: WorkflowExecutionTelemetry['timings']
  readonly retryCount: number
  readonly retryTelemetryComplete: boolean
  readonly routeTelemetryComplete: boolean
  readonly agentOutcomes: WorkflowExecutionTelemetry['agentOutcomes']
  readonly outcomeTelemetryComplete: boolean
}

type ToolJsonValue = null | boolean | number | string | ToolJsonValue[] | { [key: string]: ToolJsonValue }

/** Validate synchronous deployment invariants before a model-facing tool is registered. */
export function assertConfig(config: Config): Config {
  if (!isAbsolute(config.workflowRoot)) throw new Error('workflowRoot must be absolute')
  if (!isAbsolute(config.modelProfilesFile)) throw new Error('modelProfilesFile must be absolute')
  assertPositiveInteger(config.maxSourceBytes, 'maxSourceBytes')
  assertPositiveInteger(config.maxTaskChars, 'maxTaskChars')
  assertPositiveInteger(config.maxResultChars, 'maxResultChars')
  assertUniqueNames(config.allowedWorkflows, 'allowedWorkflows', WORKFLOW_NAME)
  assertUniqueNames(config.requiredProfiles, 'requiredProfiles', PROFILE_NAME)
  if (config.allowedWorkflows.length !== 1 || config.allowedWorkflows[0] !== 'multi-model-review') {
    throw new Error('this package has a result contract only for the multi-model-review workflow')
  }
  if (config.allowedWorkflows.includes('multi-model-review')) {
    const expected = ['deep', 'fast', 'review']
    const actual = [...config.requiredProfiles].sort()
    if (actual.join('\0') !== expected.join('\0')) {
      throw new Error('multi-model-review requires exactly the fast, deep, and review profiles')
    }
  }
  return config
}

/** Parse the exact portable source envelope; the body remains native DSH JavaScript. */
export function parseSavedWorkflowSource(source: string, expectedName?: string): SavedWorkflowSource {
  const newline = source.indexOf('\n')
  if (newline < 0) throw new Error('saved workflow must have a single-line meta header followed by a JavaScript body')
  const header = source.slice(0, newline)
  if (!header.startsWith(META_PREFIX) || !header.endsWith(';')) {
    throw new Error('saved workflow first line must be exactly `export const meta = <JSON literal>;`')
  }
  const encoded = header.slice(META_PREFIX.length, -1)
  if (!encoded.startsWith('{') || !encoded.endsWith('}')) {
    throw new Error('saved workflow meta must be a single JSON object literal')
  }
  let decoded: unknown
  try {
    decoded = JSON.parse(encoded) as unknown
  } catch (error) {
    throw new Error('saved workflow meta is not strict JSON', { cause: error })
  }
  const meta = parseMeta(decoded)
  if (expectedName !== undefined && meta.name !== expectedName) {
    throw new Error(`saved workflow meta.name ${JSON.stringify(meta.name)} does not match allowlisted workflow ${JSON.stringify(expectedName)}`)
  }
  const body = source.slice(newline + 1)
  if (body.trim().length === 0) throw new Error('saved workflow body must not be empty')
  return { meta, body }
}

/** Load the platform-only model catalog and reject every unsupported execution field. */
export async function loadModelProfiles(config: Config): Promise<ResolvedModelProfiles> {
  const source = await readCanonicalRegularFile(config.modelProfilesFile, config.maxSourceBytes, 'modelProfilesFile')
  let decoded: unknown
  try {
    decoded = JSON.parse(source) as unknown
  } catch (error) {
    throw new Error('modelProfilesFile is not valid JSON', { cause: error })
  }
  const root = asRecord(decoded, 'model profile catalog')
  assertExactKeys(root, new Set(['schemaVersion', 'profiles']), 'model profile catalog')
  if (root.schemaVersion !== 1) throw new Error('model profile catalog schemaVersion must be 1')
  const profiles = asRecord(root.profiles, 'model profile catalog profiles')
  const expected = [...config.requiredProfiles].sort()
  const actual = Object.keys(profiles).sort()
  if (actual.join('\0') !== expected.join('\0')) {
    throw new Error(`model profile catalog must define exactly: ${expected.join(', ')}`)
  }
  const resolved: Record<string, ModelTarget> = {}
  for (const profile of config.requiredProfiles) {
    const entry = asRecord(profiles[profile], `model profile ${profile}`)
    for (const field of Object.keys(entry)) {
      if (!SUPPORTED_PROFILE_FIELDS.has(field)) {
        throw new Error(`model profile ${profile} field ${JSON.stringify(field)} is unsupported by the rc.6 native WorkflowEngine; supported fields: provider, model`)
      }
    }
    const provider = optionalNonEmptyString(entry.provider, `model profile ${profile}.provider`)
    const model = optionalNonEmptyString(entry.model, `model profile ${profile}.model`)
    resolved[profile] = {
      ...(provider === undefined ? {} : { provider }),
      ...(model === undefined ? {} : { model }),
    }
  }
  return resolved
}

/** Resolve every logical profile to an explicit provider/model route before execution. */
export function resolveModelRoutes(
  profiles: ResolvedModelProfiles,
  parent: Pick<AgentOptions, 'provider' | 'model'>,
): ResolvedModelRoutes {
  const routes: Record<string, ModelRoute> = {}
  for (const [profile, target] of Object.entries(profiles)) {
    const provider = target.provider ?? parent.provider
    const model = target.model ?? parent.model
    if (provider === undefined || provider.length === 0) {
      throw new Error(`model profile ${profile} cannot resolve provider from profile or parent Agent`)
    }
    if (model === undefined || model.length === 0) {
      throw new Error(`model profile ${profile} cannot resolve model from profile or parent Agent`)
    }
    routes[profile] = { provider, model }
  }
  return routes
}

/** Resolve one allowlisted source file without accepting traversal or symlink indirection. */
export async function loadSavedWorkflow(config: Config, workflow: string): Promise<SavedWorkflowSource> {
  if (!WORKFLOW_NAME.test(workflow)) throw new Error('workflow must be a lowercase kebab-case name')
  if (!config.allowedWorkflows.includes(workflow)) throw new Error(`workflow ${JSON.stringify(workflow)} is not allowlisted`)
  const root = resolve(config.workflowRoot)
  await assertCanonicalDirectory(root, 'workflowRoot')
  const candidate = resolve(root, `${workflow}.js`)
  const escaped = relative(root, candidate)
  if (escaped.startsWith('..') || isAbsolute(escaped)) throw new Error('workflow path escapes workflowRoot')
  const source = await readCanonicalRegularFile(candidate, config.maxSourceBytes, `workflow ${workflow}`)
  return parseSavedWorkflowSource(source, workflow)
}

/** A thin saved-script facade over the public rc.6 WorkflowEngine seam. */
export class ProfiledDynamicWorkflowRunner {
  readonly config: Config

  constructor(
    private readonly engine: WorkflowEngine,
    config: Config,
    private readonly telemetry: WorkflowTelemetryRecorder,
  ) {
    this.config = assertConfig(config)
  }

  async run(request: ProfiledWorkflowRequest): Promise<ProfiledWorkflowResult> {
    request.signal.throwIfAborted()
    if (request.task.trim().length === 0) throw new Error('task must be a non-empty string')
    if (request.task.length > this.config.maxTaskChars) throw new Error(`task exceeds maxTaskChars (${this.config.maxTaskChars})`)
    const [source, profiles, resultContract] = await Promise.all([
      loadSavedWorkflow(this.config, request.workflow),
      loadModelProfiles(this.config),
      loadResultContract(request.workflow),
    ])
    const resolvedRoutes = resolveModelRoutes(profiles, request.parent.options)
    assertMultiModelRoutes(request.workflow, resolvedRoutes)
    request.signal.throwIfAborted()
    const run = this.engine.start({
      script: source.body,
      meta: source.meta,
      args: {
        task: request.task,
        models: resolvedRoutes,
        minDistinctReviewRoutes: 2,
        finalInstruction: resultContract.instruction,
      },
      parent: request.parent,
      signal: request.signal,
    })
    this.telemetry.claim(run.id)
    const onAbort = (): void => { run.cancel('parent step aborted') }
    request.signal.addEventListener('abort', onAbort, { once: true })
    if (request.signal.aborted) onAbort()
    let result: WorkflowResult | undefined
    let validated: ValidatedWorkflowResult | undefined
    let failure: unknown
    let failed = false
    try {
      result = await run.result
      const error = workflowResultError(result)
      if (error !== undefined) throw new Error(error)
      validated = validateWorkflowResult(
        request.workflow,
        run.id,
        result.value,
        resultContract,
        this.config.maxResultChars,
      )
    } catch (error) {
      failure = error
      failed = true
    } finally {
      request.signal.removeEventListener('abort', onAbort)
    }
    try {
      await run.dispose()
    } catch (disposeError) {
      failure = failed ? combineWorkflowFailures(failure, disposeError) : disposeError
      failed = true
    }
    if (failed) {
      let partialReceipt: WorkflowExecutionTelemetry | undefined
      try {
        if (result !== undefined) {
          partialReceipt = this.telemetry.snapshot(run.id, result.agentsStarted)
        }
      } finally {
        this.telemetry.abandon(run.id)
      }
      if (result !== undefined && partialReceipt !== undefined) {
        throw workflowFailureWithReceipt(failure, run.id, result, resolvedRoutes, partialReceipt)
      }
      throw failure
    }
    if (result === undefined || validated === undefined) {
      this.telemetry.abandon(run.id)
      throw new Error('workflow run settled without a result or validated payload')
    }
    const receipt = this.telemetry.snapshot(run.id, result.agentsStarted)
    try {
      assertObservedMultiModelRoutes(request.workflow, receipt)
    } catch (error) {
      this.telemetry.abandon(run.id)
      throw workflowFailureWithReceipt(error, run.id, result, resolvedRoutes, receipt)
    }
    return {
      runId: run.id,
      agentsStarted: result.agentsStarted,
      result: validated,
      profiles,
      resolvedRoutes,
      timings: receipt.timings,
      retryCount: receipt.retryCount,
      retryTelemetryComplete: receipt.retryTelemetryComplete,
      routeTelemetryComplete: receipt.routeTelemetryComplete,
      agentOutcomes: receipt.agentOutcomes,
      outcomeTelemetryComplete: receipt.outcomeTelemetryComplete,
    }
  }
}

/** Register a model-facing selector with no raw-script or raw-model parameters. */
export function apply(ctx: Context, rawConfig: Config): void {
  const config = assertConfig(rawConfig)
  const telemetry = new WorkflowTelemetryRecorder(ctx, childId => ctx.sessions.get(childId))
  const runner = new ProfiledDynamicWorkflowRunner(ctx.workflowEngine, config, telemetry)
  ctx.tools.register(defineTool({
    name: 'profiled_dynamic_workflow',
    description: 'Run one allowlisted saved workflow with deployment-owned logical model profiles. Returns resolved routes, phase timing, observed retries, child outcomes, and a JSON-Schema-validated result. The caller supplies only a workflow name and task; raw scripts and model overrides are not accepted.',
    parameters: {
      workflow: {
        type: 'string',
        required: true,
        description: `Allowlisted saved workflow name (${config.allowedWorkflows.join(', ')}).`,
      },
      task: {
        type: 'string',
        required: true,
        description: `Task text, at most ${config.maxTaskChars} characters.`,
      },
    },
    output: {
      schema: {
        type: 'object',
        additionalProperties: false,
        properties: {
          runId: { type: 'string', required: true },
          agentsStarted: { type: 'integer', required: true },
          result: { type: 'json', required: true },
          profiles: { type: 'json', required: true },
          resolvedRoutes: { type: 'json', required: true },
          timings: { type: 'json', required: true },
          retryCount: { type: 'integer', required: true },
          retryTelemetryComplete: { type: 'boolean', required: true },
          routeTelemetryComplete: { type: 'boolean', required: true },
          agentOutcomes: { type: 'json', required: true },
          outcomeTelemetryComplete: { type: 'boolean', required: true },
        },
      },
      render: (args, value) => [{
        type: 'text',
        text: renderResult(args.workflow, value, config.maxResultChars),
      }],
    },
    isConcurrencySafe: () => true,
    async execute(args, exec) {
      if (exec.agent === undefined) throw new Error('profiled_dynamic_workflow requires a calling Agent')
      const value = await runner.run({
        workflow: args.workflow,
        task: args.task,
        parent: exec.agent,
        signal: exec.signal,
      })
      return {
        runId: value.runId,
        agentsStarted: value.agentsStarted,
        result: value.result as unknown as ToolJsonValue,
        profiles: value.profiles as unknown as ToolJsonValue,
        resolvedRoutes: value.resolvedRoutes as unknown as ToolJsonValue,
        timings: value.timings as unknown as ToolJsonValue,
        retryCount: value.retryCount,
        retryTelemetryComplete: value.retryTelemetryComplete,
        routeTelemetryComplete: value.routeTelemetryComplete,
        agentOutcomes: value.agentOutcomes as unknown as ToolJsonValue,
        outcomeTelemetryComplete: value.outcomeTelemetryComplete,
      }
    },
    presentCall: args => ({
      card: 'generic',
      title: `Saved workflow: ${args.workflow}`,
      kind: 'other',
      rawInput: args.task,
    }),
    presentResult: (_args, result) => ({
      card: 'generic',
      title: result.isError ? 'Saved workflow failed' : 'Saved workflow completed',
      content: result.content,
    }),
  }))
}

function workflowResultError(result: WorkflowResult): string | undefined {
  if (result.stopReason === 'completed') return undefined
  if (result.stopReason === 'cancelled') return `workflow run was cancelled${result.error === undefined ? '' : ` (${result.error})`}`
  return `workflow run failed: ${result.error ?? 'unknown error'}`
}

function combineWorkflowFailures(primary: unknown, disposal: unknown): AggregateError {
  const primaryMessage = primary instanceof Error ? primary.message : String(primary)
  const disposalMessage = disposal instanceof Error ? disposal.message : String(disposal)
  return new AggregateError(
    [primary, disposal],
    `${primaryMessage}; workflow dispose failed: ${disposalMessage}`,
  )
}

/** Keep a failed run fail-closed while preserving bounded, non-prompt execution evidence. */
function workflowFailureWithReceipt(
  cause: unknown,
  runId: string,
  result: WorkflowResult,
  resolvedRoutes: ResolvedModelRoutes,
  telemetry: WorkflowExecutionTelemetry,
): Error {
  const message = cause instanceof Error ? cause.message : String(cause)
  const receipt = {
    runId,
    agentsStarted: result.agentsStarted,
    stopReason: result.stopReason,
    resolvedRoutes,
    timings: telemetry.timings,
    retryCount: telemetry.retryCount,
    retryTelemetryComplete: telemetry.retryTelemetryComplete,
    routeTelemetryComplete: telemetry.routeTelemetryComplete,
    agentOutcomes: telemetry.agentOutcomes,
    outcomeTelemetryComplete: telemetry.outcomeTelemetryComplete,
    result: null,
  }
  return new Error(`${message}\npartialWorkflowReceipt=${JSON.stringify(receipt)}`, { cause })
}

function renderResult(workflow: string, value: {
  readonly runId: string
  readonly agentsStarted: number
  readonly result: ToolJsonValue
  readonly profiles: ToolJsonValue
  readonly resolvedRoutes: ToolJsonValue
  readonly timings: ToolJsonValue
  readonly retryCount: number
  readonly retryTelemetryComplete: boolean
  readonly routeTelemetryComplete: boolean
  readonly agentOutcomes: ToolJsonValue
  readonly outcomeTelemetryComplete: boolean
}, maxChars: number): string {
  const payload = JSON.stringify(value.result, null, 2)
  const clipped = payload.length > maxChars
    ? `${payload.slice(0, maxChars)}\n… [truncated: ${payload.length - maxChars} more characters]`
    : payload
  return [
    `saved workflow ${JSON.stringify(workflow)} completed (${value.agentsStarted} agents)`,
    `runId: ${value.runId}`,
    `profiles: ${JSON.stringify(value.profiles)}`,
    `resolvedRoutes: ${JSON.stringify(value.resolvedRoutes)}`,
    `timings: ${JSON.stringify(value.timings)}`,
    `retryCount: ${value.retryCount} (complete=${value.retryTelemetryComplete})`,
    `routeTelemetryComplete: ${value.routeTelemetryComplete}`,
    `agentOutcomes: ${JSON.stringify(value.agentOutcomes)}`,
    `outcomeTelemetryComplete: ${value.outcomeTelemetryComplete}`,
    `result:\n${clipped}`,
  ].join('\n')
}

function assertMultiModelRoutes(workflow: string, routes: ResolvedModelRoutes): void {
  if (workflow !== 'multi-model-review') return
  const required = ['fast', 'deep', 'review'] as const
  for (const profile of required) {
    if (routes[profile] === undefined) {
      throw new Error(`multi-model-review is missing resolved route ${profile}`)
    }
  }
  const unique = new Set(required.map(profile => {
    const route = routes[profile]
    if (route === undefined) throw new Error(`multi-model-review is missing resolved route ${profile}`)
    return `${route.provider}\0${route.model}`
  }))
  if (unique.size < 2) {
    throw new Error('multi-model-review requires at least two distinct resolved provider/model routes')
  }
}

function assertObservedMultiModelRoutes(
  workflow: string,
  receipt: WorkflowExecutionTelemetry,
): void {
  if (workflow !== 'multi-model-review') return
  const independentReviews = receipt.agentOutcomes.filter(agent => agent.phase === 'independent-reviews')
  if (independentReviews.length !== 3 || independentReviews.some(agent => agent.outcome === 'unknown')) {
    throw new Error('WORKFLOW_ROUTE_TELEMETRY_INCOMPLETE: independent review outcomes are incomplete')
  }
  const successfulReviews = independentReviews.filter(agent => agent.outcome === 'completed')
  if (successfulReviews.length < 2) {
    throw new Error('WORKFLOW_ACTUAL_ROUTE_DIVERSITY_INVALID: fewer than two independent reviews completed')
  }
  if (successfulReviews.some(agent => agent.finalObservedRoute === null)) {
    throw new Error('WORKFLOW_ROUTE_TELEMETRY_INCOMPLETE: final request route is unavailable for a successful independent review')
  }
  const unique = new Set(successfulReviews.map(agent => {
    const route = agent.finalObservedRoute
    if (route === null) throw new Error('WORKFLOW_ROUTE_TELEMETRY_INCOMPLETE')
    return `${route.provider}\0${route.model}`
  }))
  if (unique.size < 2) {
    throw new Error('WORKFLOW_ACTUAL_ROUTE_DIVERSITY_INVALID: successful independent reviews used fewer than two observed provider/model routes')
  }
}

function parseMeta(value: unknown): WorkflowMeta {
  const root = asRecord(value, 'saved workflow meta')
  assertExactKeys(root, new Set(['name', 'description', 'whenToUse', 'phases']), 'saved workflow meta', true)
  const nameValue = requiredNonEmptyString(root.name, 'saved workflow meta.name')
  if (!WORKFLOW_NAME.test(nameValue)) throw new Error('saved workflow meta.name must be lowercase kebab-case')
  const description = requiredNonEmptyString(root.description, 'saved workflow meta.description')
  const whenToUse = optionalString(root.whenToUse, 'saved workflow meta.whenToUse')
  let phases: WorkflowMeta['phases']
  if (root.phases !== undefined) {
    if (!Array.isArray(root.phases)) throw new Error('saved workflow meta.phases must be an array')
    phases = root.phases.map((rawPhase, index) => {
      const phase = asRecord(rawPhase, `saved workflow meta.phases[${index}]`)
      assertExactKeys(phase, new Set(['title', 'detail', 'provider', 'model']), `saved workflow meta.phases[${index}]`, true)
      const title = requiredNonEmptyString(phase.title, `saved workflow meta.phases[${index}].title`)
      const detail = optionalString(phase.detail, `saved workflow meta.phases[${index}].detail`)
      const provider = optionalString(phase.provider, `saved workflow meta.phases[${index}].provider`)
      const model = optionalString(phase.model, `saved workflow meta.phases[${index}].model`)
      return {
        title,
        ...(detail === undefined ? {} : { detail }),
        ...(provider === undefined ? {} : { provider }),
        ...(model === undefined ? {} : { model }),
      }
    })
  }
  return {
    name: nameValue,
    description,
    ...(whenToUse === undefined ? {} : { whenToUse }),
    ...(phases === undefined ? {} : { phases }),
  }
}

async function assertCanonicalDirectory(path: string, label: string): Promise<void> {
  const stats = await lstat(path)
  if (stats.isSymbolicLink() || !stats.isDirectory()) throw new Error(`${label} must be a real directory, not a symlink`)
  const actual = await realpath(path)
  if (actual !== path) throw new Error(`${label} must not resolve through symlinked ancestors`)
}

async function readCanonicalRegularFile(path: string, maxBytes: number, label: string): Promise<string> {
  const normalized = resolve(path)
  const stats = await lstat(normalized)
  if (stats.isSymbolicLink() || !stats.isFile()) throw new Error(`${label} must be a real regular file, not a symlink`)
  if (stats.size > maxBytes) throw new Error(`${label} exceeds maxSourceBytes (${maxBytes})`)
  const actual = await realpath(normalized)
  if (actual !== normalized) throw new Error(`${label} must not resolve through symlinked ancestors`)
  return readFile(normalized, 'utf8')
}

function asRecord(value: unknown, label: string): Record<string, unknown> {
  if (typeof value !== 'object' || value === null || Array.isArray(value)) throw new Error(`${label} must be an object`)
  const prototype = Object.getPrototypeOf(value)
  if (prototype !== Object.prototype && prototype !== null) throw new Error(`${label} must be a plain object`)
  return value as Record<string, unknown>
}

function assertExactKeys(record: Record<string, unknown>, allowed: ReadonlySet<string>, label: string, allowMissing = false): void {
  for (const key of Object.keys(record)) {
    if (!allowed.has(key)) throw new Error(`${label} field ${JSON.stringify(key)} is not supported`)
  }
  if (allowMissing) return
  for (const key of allowed) {
    if (!(key in record)) throw new Error(`${label} is missing ${JSON.stringify(key)}`)
  }
}

function requiredNonEmptyString(value: unknown, label: string): string {
  if (typeof value !== 'string' || value.length === 0) throw new Error(`${label} must be a non-empty string`)
  return value
}

function optionalString(value: unknown, label: string): string | undefined {
  if (value === undefined) return undefined
  if (typeof value !== 'string') throw new Error(`${label} must be a string`)
  return value
}

function optionalNonEmptyString(value: unknown, label: string): string | undefined {
  if (value === undefined) return undefined
  return requiredNonEmptyString(value, label)
}

function assertPositiveInteger(value: number, label: string): void {
  if (!Number.isSafeInteger(value) || value <= 0) throw new Error(`${label} must be a positive integer`)
}

function assertUniqueNames(values: readonly string[], label: string, pattern: RegExp): void {
  if (values.length === 0) throw new Error(`${label} must not be empty`)
  const seen = new Set<string>()
  for (const value of values) {
    if (!pattern.test(value)) throw new Error(`${label} contains invalid name ${JSON.stringify(value)}`)
    if (seen.has(value)) throw new Error(`${label} contains duplicate name ${JSON.stringify(value)}`)
    seen.add(value)
  }
}
