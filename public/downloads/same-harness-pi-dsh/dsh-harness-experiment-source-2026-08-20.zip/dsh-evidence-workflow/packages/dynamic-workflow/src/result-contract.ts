import { readFile } from 'node:fs/promises'

import { Ajv2020, type AnySchema, type ErrorObject, type ValidateFunction } from 'ajv/dist/2020.js'
import type { WorkflowRunId } from '@deepseek-ai/dsh-workflow'

export interface MultiModelReviewFinding {
  readonly sourceLocations: readonly string[]
  readonly failureScenario: string
  readonly rankingRationale: string
  readonly fixSuggestion: string
}

export interface MultiModelReviewResult {
  readonly summary: string
  readonly agreements: readonly string[]
  readonly disagreements: readonly string[]
  readonly findings: readonly [
    MultiModelReviewFinding,
    MultiModelReviewFinding,
    MultiModelReviewFinding,
  ]
  readonly recommendation: string
}

export type ValidatedWorkflowResult = MultiModelReviewResult

interface ResultContract {
  readonly instruction: string
  readonly validate: ValidateFunction<ValidatedWorkflowResult>
}

const ajv = new Ajv2020({ allErrors: true, strict: true })
const contracts = new Map<string, Promise<ResultContract>>()

/** Load and compile the deployment-owned full JSON Schema for one allowlisted workflow. */
export function loadResultContract(workflow: string): Promise<ResultContract> {
  const existing = contracts.get(workflow)
  if (existing !== undefined) return existing
  const pending = buildResultContract(workflow)
  contracts.set(workflow, pending)
  void pending.catch(() => { contracts.delete(workflow) })
  return pending
}

/** Parse only a complete raw JSON document or one complete json fence, then apply the full schema. */
export function validateWorkflowResult(
  workflow: string,
  runId: WorkflowRunId | string,
  value: unknown,
  contract: ResultContract,
  maxResultChars: number,
): ValidatedWorkflowResult {
  if (typeof value !== 'string') {
    throw schemaError(workflow, runId, 'final synthesis must be a JSON string')
  }
  if (value.length > maxResultChars) {
    throw schemaError(workflow, runId, `final synthesis exceeds maxResultChars (${maxResultChars})`)
  }
  const source = unwrapExactJson(value)
  let decoded: unknown
  try {
    decoded = JSON.parse(source) as unknown
  } catch {
    throw schemaError(workflow, runId, 'final synthesis is not one complete JSON document')
  }
  if (!contract.validate(decoded)) {
    throw schemaError(workflow, runId, formatErrors(contract.validate.errors))
  }
  for (const finding of decoded.findings) {
    for (const location of finding.sourceLocations) {
      const range = /:([1-9][0-9]*)(?:-([1-9][0-9]*))?$/.exec(location)
      if (range === null) throw schemaError(workflow, runId, `invalid source location ${JSON.stringify(location)}`)
      const start = range[1]
      const end = range[2]
      if (start === undefined) throw schemaError(workflow, runId, `invalid source location ${JSON.stringify(location)}`)
      if (end !== undefined && BigInt(end) < BigInt(start)) {
        throw schemaError(workflow, runId, `source location range ends before it starts: ${JSON.stringify(location)}`)
      }
    }
  }
  return decoded
}

function unwrapExactJson(value: string): string {
  const trimmed = value.trim()
  const fenced = /^```json[\t ]*\r?\n([\s\S]*?)\r?\n```$/i.exec(trimmed)
  return fenced?.[1] ?? trimmed
}

async function buildResultContract(workflow: string): Promise<ResultContract> {
  if (workflow !== 'multi-model-review') {
    throw new Error(`no result contract is installed for workflow ${JSON.stringify(workflow)}`)
  }
  const source = await readFile(new URL('../schemas/multi-model-review.schema.json', import.meta.url), 'utf8')
  let schema: unknown
  try {
    schema = JSON.parse(source) as unknown
  } catch (error) {
    throw new Error('multi-model-review result schema is not valid JSON', { cause: error })
  }
  const validate = ajv.compile<ValidatedWorkflowResult>(schema as AnySchema)
  return {
    validate,
    instruction: [
      'DSH FINAL-SYNTHESIS OUTPUT CONTRACT (applies only to the final-synthesis Agent; earlier review/challenge Agents still return their requested plain text):',
      'Return exactly one raw JSON object, with no Markdown fence and no prose before or after it.',
      'Write all human-readable values in Chinese.',
      'The top-level keys must be exactly: summary, agreements, disagreements, findings, recommendation.',
      'findings must contain exactly three items in descending priority order.',
      'Each finding must contain exactly four keys: sourceLocations, failureScenario, rankingRationale, fixSuggestion.',
      'sourceLocations must be a non-empty array of file:line or file:start-end strings; the other three values must be non-blank strings.',
      'Shape: {"summary":"...","agreements":["..."],"disagreements":["..."],"findings":[{"sourceLocations":["path/file.ts:12-18"],"failureScenario":"...","rankingRationale":"...","fixSuggestion":"..."},{"sourceLocations":["...:1"],"failureScenario":"...","rankingRationale":"...","fixSuggestion":"..."},{"sourceLocations":["...:2"],"failureScenario":"...","rankingRationale":"...","fixSuggestion":"..."}],"recommendation":"..."}',
    ].join('\n'),
  }
}

function schemaError(workflow: string, runId: WorkflowRunId | string, detail: string): Error {
  return new Error(`WORKFLOW_RESULT_SCHEMA_INVALID workflow=${JSON.stringify(workflow)} runId=${JSON.stringify(runId)}: ${detail}`)
}

function formatErrors(errors: ErrorObject[] | null | undefined): string {
  return (errors ?? [])
    .map(error => `${error.instancePath || '/'} ${error.message ?? 'is invalid'} [${error.keyword}]`)
    .join('; ')
}
