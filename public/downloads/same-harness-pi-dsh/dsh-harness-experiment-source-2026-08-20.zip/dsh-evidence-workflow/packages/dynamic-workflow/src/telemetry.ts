import { performance } from 'node:perf_hooks'

import type { Context } from '@deepseek-ai/cordis'
import type { Session, SessionId } from '@deepseek-ai/dsh-session'
import type {
  WorkflowAgentOutcome,
  WorkflowRunId,
} from '@deepseek-ai/dsh-workflow'

export interface ModelRoute {
  readonly provider: string
  readonly model: string
}

export interface PhaseTiming {
  readonly phase: string
  readonly startedOffsetMs: number
  readonly durationMs: number
}

export interface AgentOutcomeReceipt {
  readonly seq: number
  readonly label: string
  readonly phase?: string
  readonly childId: string
  readonly outcome: WorkflowAgentOutcome | 'unknown'
  readonly durationMs: number
  readonly retryCount: number | null
  readonly observedRoutes: readonly ModelRoute[]
  readonly finalObservedRoute: ModelRoute | null
  readonly telemetryStatus: 'complete' | 'no-local-session' | 'no-request-route'
}

export interface WorkflowExecutionTelemetry {
  readonly timings: {
    readonly runDurationMs: number
    readonly phases: readonly PhaseTiming[]
  }
  readonly retryCount: number
  readonly retryTelemetryComplete: boolean
  readonly routeTelemetryComplete: boolean
  readonly agentOutcomes: readonly AgentOutcomeReceipt[]
  readonly outcomeTelemetryComplete: boolean
}

interface MutablePhase {
  readonly phase: string
  readonly startedAt: number
  endedAt?: number
}

interface MutableAgent {
  readonly seq: number
  readonly label: string
  readonly phase?: string
  readonly childId: SessionId
  readonly startedAt: number
  readonly session?: Session
  endedAt?: number
  outcome?: WorkflowAgentOutcome
}

interface MutableTrace {
  readonly startedAt: number
  readonly phases: MutablePhase[]
  readonly agents: Map<number, MutableAgent>
  claimed: boolean
  endedAt?: number
}

type SessionLookup = (id: SessionId) => Session | undefined

/** Observe the public workflow lifecycle and fold it into one run-scoped receipt. */
export class WorkflowTelemetryRecorder {
  private readonly traces = new Map<WorkflowRunId, MutableTrace>()

  constructor(
    ctx: Context,
    private readonly lookupSession?: SessionLookup,
    private readonly now: () => number = () => performance.now(),
  ) {
    ctx.on('workflow/start', (info) => {
      this.traces.set(info.id, {
        startedAt: this.now(),
        phases: [],
        agents: new Map(),
        claimed: false,
      })
    })
    ctx.on('workflow/phase', (info, phase) => {
      const trace = this.traces.get(info.id)
      if (trace === undefined) return
      const at = this.now()
      closePhase(trace, at)
      trace.phases.push({ phase, startedAt: at })
    })
    ctx.on('workflow/agent-start', (info, agent) => {
      const trace = this.traces.get(info.id)
      if (trace === undefined || trace.agents.has(agent.seq)) return
      let session: Session | undefined
      try {
        session = this.lookupSession?.(agent.childId)
      } catch {
        session = undefined
      }
      trace.agents.set(agent.seq, {
        seq: agent.seq,
        label: agent.label,
        ...(agent.phase === undefined ? {} : { phase: agent.phase }),
        childId: agent.childId,
        startedAt: this.now(),
        ...(session === undefined ? {} : { session }),
      })
    })
    ctx.on('workflow/agent-end', (info, agent) => {
      const trace = this.traces.get(info.id)
      if (trace === undefined) return
      const at = this.now()
      const existing = trace.agents.get(agent.seq)
      if (existing === undefined) {
        let session: Session | undefined
        try {
          session = this.lookupSession?.(agent.childId)
        } catch {
          session = undefined
        }
        trace.agents.set(agent.seq, {
          seq: agent.seq,
          label: agent.label,
          ...(agent.phase === undefined ? {} : { phase: agent.phase }),
          childId: agent.childId,
          startedAt: at,
          endedAt: at,
          outcome: agent.outcome,
          ...(session === undefined ? {} : { session }),
        })
        return
      }
      existing.endedAt = at
      existing.outcome = agent.outcome
    })
    ctx.on('workflow/end', (info) => {
      const trace = this.traces.get(info.id)
      if (trace === undefined) return
      const at = this.now()
      trace.endedAt = at
      closePhase(trace, at)
      if (!trace.claimed) this.traces.delete(info.id)
    })
  }

  /** Mark one published run as owned by this wrapper. */
  claim(runId: WorkflowRunId): void {
    const existing = this.traces.get(runId)
    if (existing !== undefined) {
      existing.claimed = true
      return
    }
    this.traces.set(runId, {
      startedAt: this.now(),
      phases: [],
      agents: new Map(),
      claimed: true,
    })
  }

  /** Finish, remove, and return one immutable telemetry snapshot. */
  snapshot(runId: WorkflowRunId, agentsStarted: number): WorkflowExecutionTelemetry {
    const trace = this.traces.get(runId)
    this.traces.delete(runId)
    if (trace === undefined) return emptyTelemetry(agentsStarted)
    const endedAt = trace.endedAt ?? this.now()
    closePhase(trace, endedAt)
    const agents = [...trace.agents.values()].sort((left, right) => left.seq - right.seq)
    const outcomeTelemetryComplete = agents.length === agentsStarted
      && agents.every(agent => agent.outcome !== undefined && agent.endedAt !== undefined)
    const agentOutcomes = agents
      .map(agent => snapshotAgent(agent, endedAt))
    const knownRetries = agentOutcomes.filter(agent => agent.retryCount !== null)
    return {
      timings: {
        runDurationMs: duration(trace.startedAt, endedAt),
        phases: trace.phases.map(phase => ({
          phase: phase.phase,
          startedOffsetMs: duration(trace.startedAt, phase.startedAt),
          durationMs: duration(phase.startedAt, phase.endedAt ?? endedAt),
        })),
      },
      retryCount: knownRetries.reduce((total, agent) => total + (agent.retryCount ?? 0), 0),
      retryTelemetryComplete: agentOutcomes.length === agentsStarted
        && knownRetries.length === agentOutcomes.length,
      routeTelemetryComplete: agentOutcomes.length === agentsStarted
        && agentOutcomes.every(agent => agent.finalObservedRoute !== null),
      agentOutcomes,
      outcomeTelemetryComplete,
    }
  }

  /** Drop one failed/abandoned run without retaining cross-call state. */
  abandon(runId: WorkflowRunId): void {
    this.traces.delete(runId)
  }
}

function closePhase(trace: MutableTrace, at: number): void {
  const current = trace.phases.at(-1)
  if (current !== undefined && current.endedAt === undefined) current.endedAt = at
}

function snapshotAgent(agent: MutableAgent, fallbackEnd: number): AgentOutcomeReceipt {
  const sessionTelemetry = inspectSession(agent.session)
  return {
    seq: agent.seq,
    label: agent.label,
    ...(agent.phase === undefined ? {} : { phase: agent.phase }),
    childId: agent.childId,
    outcome: agent.outcome ?? 'unknown',
    durationMs: duration(agent.startedAt, agent.endedAt ?? fallbackEnd),
    retryCount: sessionTelemetry.retryCount,
    observedRoutes: sessionTelemetry.routes,
    finalObservedRoute: sessionTelemetry.finalRoute,
    telemetryStatus: sessionTelemetry.status,
  }
}

function inspectSession(session: Session | undefined): {
  readonly retryCount: number | null
  readonly routes: readonly ModelRoute[]
  readonly finalRoute: ModelRoute | null
  readonly status: AgentOutcomeReceipt['telemetryStatus']
} {
  if (session === undefined) return { retryCount: null, routes: [], finalRoute: null, status: 'no-local-session' }
  const events = session.events.slice(session.firstLiveSeq)
  const contexts: ModelRoute[] = []
  const headers: ModelRoute[] = []
  let finalContextRoute: ModelRoute | undefined
  let finalHeaderRoute: ModelRoute | undefined
  let retryCount = 0
  for (const event of events) {
    const eventType: string = event.type
    if (eventType === 'llm/retry-started') retryCount += 1
    if (event.type === 'request/context') {
      const route = routeFromRecord(event.data)
      if (route !== undefined) {
        finalContextRoute = route
        pushUniqueRoute(contexts, route)
      }
    } else if (event.type === 'request/header') {
      const eventData = record(event.data)
      const header = record(eventData?.header)
      const route = routeFromRecord(record(header?.config))
      if (route !== undefined) {
        finalHeaderRoute = route
        pushUniqueRoute(headers, route)
      }
    }
  }
  const routes = contexts.length > 0 ? contexts : headers
  const finalRoute = finalContextRoute ?? finalHeaderRoute ?? null
  return {
    retryCount,
    routes,
    finalRoute,
    status: routes.length === 0 ? 'no-request-route' : 'complete',
  }
}

function routeFromRecord(value: unknown): ModelRoute | undefined {
  const source = record(value)
  if (typeof source?.provider !== 'string' || source.provider.length === 0) return undefined
  if (typeof source.model !== 'string' || source.model.length === 0) return undefined
  return { provider: source.provider, model: source.model }
}

function record(value: unknown): Record<string, unknown> | undefined {
  if (typeof value !== 'object' || value === null || Array.isArray(value)) return undefined
  return value as Record<string, unknown>
}

function pushUniqueRoute(routes: ModelRoute[], candidate: ModelRoute): void {
  if (routes.some(route => route.provider === candidate.provider && route.model === candidate.model)) return
  routes.push(candidate)
}

function duration(start: number, end: number): number {
  return Math.max(0, Math.round(end - start))
}

function emptyTelemetry(agentsStarted: number): WorkflowExecutionTelemetry {
  return {
    timings: { runDurationMs: 0, phases: [] },
    retryCount: 0,
    retryTelemetryComplete: agentsStarted === 0,
    routeTelemetryComplete: agentsStarted === 0,
    agentOutcomes: [],
    outcomeTelemetryComplete: agentsStarted === 0,
  }
}
