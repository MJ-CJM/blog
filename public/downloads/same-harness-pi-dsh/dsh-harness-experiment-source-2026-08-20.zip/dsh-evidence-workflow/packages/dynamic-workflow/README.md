# @local/dsh-dynamic-workflow

An rc.6 Cordis Bundle that exposes the fixed `profiled_dynamic_workflow` tool. It accepts only an allowlisted saved-workflow name and task, loads deployment-owned logical model profiles, strips the strict `export const meta = <JSON>;` header, and delegates the unchanged JavaScript body to the public `ctx.workflowEngine.start()` seam.

The package is a saved-script loader and policy wrapper, not a DAG engine. It neither disables nor replaces `@deepseek-ai/dsh-workflow-worker-thread`. DSH rc.6 profile entries may contain only `provider` and `model`; `thinking`, `tools`, `maxTokens`, credentials, and every unknown field fail loudly rather than being ignored. Missing profile fields inherit the parent route, and `multi-model-review` fails before execution unless the resolved catalog contains at least two distinct provider/model routes. It also fails after independent review if the successful reviews do not cover two distinct routes.

The returned execution receipt separates deployment intent from runtime evidence:

- `profiles` is the deployment-owned partial catalog.
- `resolvedRoutes` is the complete provider/model route intended for each logical profile after parent inheritance; `agentOutcomes[].observedRoutes` is the request evidence actually seen in each local child Session.
- `timings` contains the whole-run duration and observed `phase()` intervals.
- `retryCount` counts observed `llm/retry-started` events. When `retryTelemetryComplete` is false it is only an observed lower bound; a child `retryCount: null` means unknown, not zero.
- `agentOutcomes` contains each published child sequence, label, phase, outcome, duration, unique observed routes, final observed request route, and per-child retry count.
- `routeTelemetryComplete` means every published child has a final request route in its local Session. Independently, successful review children must prove at least two distinct `finalObservedRoute` values or the wrapper fails.
- `outcomeTelemetryComplete` means every published workflow child has a paired start/end observation; it is not a success-rate flag and is independent of local Session availability.

失败仍保持 fail-closed，不会伪造成功 `result`。只要官方 engine 已返回一个 run result，抛出的错误会附带有界的 `partialWorkflowReceipt`，保留 `runId`、`agentsStarted`、resolved routes、阶段耗时、重试与已观察到的 child outcomes；`result` 固定为 `null`。这份回执用于定位失败，不代表 Schema 验证通过。

The DSH-owned `schemas/multi-model-review.schema.json` is compiled with Ajv 2020. DSH passes a final-synthesis-only JSON instruction through the shared script; Pi omits it and retains the plain-text fallback. The final synthesis must be one complete JSON document (or one complete `json` fence) within `maxResultChars`, with exactly three ordered findings. Every finding has exactly four keys: `sourceLocations`, `failureScenario`, `rankingRationale`, and `fixSuggestion`. Missing/extra findings, missing/extra fields, blank or oversized values, and invalid `file:line` locations fail the entire tool call with `WORKFLOW_RESULT_SCHEMA_INVALID`; no partial result or silent repair is returned. This is authoritative post-run validation, not provider-native structured output—the shared Pi/DSH workflow script remains byte-identical. The size check runs at this wrapper boundary after the official engine has materialized its result; it is not an engine-level memory sandbox.

Workflow and profile files must be canonical regular files under the configured absolute roots. Tool callers cannot submit raw script text, paths, model IDs, or profile data.
