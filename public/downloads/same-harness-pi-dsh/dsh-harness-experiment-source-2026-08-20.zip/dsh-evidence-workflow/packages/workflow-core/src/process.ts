import { spawn } from 'node:child_process'
import { lstat, readFile, readdir, realpath, writeFile } from 'node:fs/promises'
import { basename, join, relative, resolve } from 'node:path'

import { hashTree } from './stable.js'
import type { PatchBuilder, VerificationReceipt, Verifier } from './types.js'

interface ProcessOutcome {
  readonly exitCode: number | null
  readonly signal: NodeJS.Signals | null
  readonly timedOut: boolean
  readonly aborted: boolean
  readonly stdout: string
  readonly stderr: string
  readonly durationMs: number
}

function minimalEnvironment(): NodeJS.ProcessEnv {
  return {
    PATH: '/usr/bin:/bin',
    LANG: 'C.UTF-8',
    LC_ALL: 'C.UTF-8',
    NODE_OPTIONS: '',
    NODE_PATH: '',
    GIT_CONFIG_NOSYSTEM: '1',
    GIT_CONFIG_GLOBAL: '/dev/null',
  }
}

function tailWithin(value: string, maxBytes: number): string {
  const bytes = Buffer.from(value)
  if (bytes.byteLength <= maxBytes) return value
  return `[truncated to final ${maxBytes} bytes]\n${bytes.subarray(bytes.byteLength - maxBytes).toString('utf8')}`
}

async function runProcess(
  command: readonly [string, ...string[]],
  cwd: string,
  signal: AbortSignal,
  timeoutMs: number,
  maxCapturedOutputBytes: number,
): Promise<ProcessOutcome> {
  signal.throwIfAborted()
  const startedAt = Date.now()
  const timeout = new AbortController()
  const timer = setTimeout(() => timeout.abort(new Error(`process timed out after ${timeoutMs}ms`)), timeoutMs)
  timer.unref()
  const combined = AbortSignal.any([signal, timeout.signal])

  return new Promise((resolvePromise, reject) => {
    let stdout = ''
    let stderr = ''
    const child = spawn(command[0], command.slice(1), {
      cwd,
      env: minimalEnvironment(),
      stdio: ['ignore', 'pipe', 'pipe'],
    })

    let settled = false
    let killTimer: NodeJS.Timeout | undefined
    const abort = () => {
      child.kill('SIGTERM')
      killTimer = setTimeout(() => child.kill('SIGKILL'), 1_000)
      killTimer.unref()
    }
    const cleanup = () => {
      clearTimeout(timer)
      if (killTimer !== undefined) clearTimeout(killTimer)
      combined.removeEventListener('abort', abort)
    }
    combined.addEventListener('abort', abort, { once: true })
    if (combined.aborted) abort()
    child.stdout.setEncoding('utf8').on('data', (chunk: string) => {
      stdout = tailWithin(`${stdout}${chunk}`, maxCapturedOutputBytes)
    })
    child.stderr.setEncoding('utf8').on('data', (chunk: string) => {
      stderr = tailWithin(`${stderr}${chunk}`, maxCapturedOutputBytes)
    })
    child.once('error', (error) => {
      if (settled) return
      settled = true
      cleanup()
      reject(error)
    })
    child.once('close', (exitCode, processSignal) => {
      if (settled) return
      settled = true
      cleanup()
      resolvePromise({
        exitCode,
        signal: processSignal,
        timedOut: timeout.signal.aborted,
        aborted: signal.aborted,
        stdout,
        stderr,
        durationMs: Date.now() - startedAt,
      })
    })
  })
}

export class CommandVerifier implements Verifier {
  constructor(
    private readonly command: readonly [string, ...string[]],
    private readonly oracleScript: string,
    private readonly fixtureRoot: string,
    private readonly runtimeRoot: string,
    private readonly timeoutMs: number,
    private readonly maxCapturedOutputBytes: number,
  ) {}

  async verify(workspace: string, baselineFixtureHash: string, signal: AbortSignal): Promise<VerificationReceipt> {
    if (Number.parseInt(process.versions.node.split('.')[0] ?? '0', 10) < 25) {
      throw new Error('verification requires Node >=25 so the permission model also denies network access')
    }
    if (!process.allowedNodeEnvironmentFlags.has('--allow-net')) {
      throw new Error('verification requires a Node permission model with the --allow-net scope')
    }
    const canonicalWorkspace = await realpath(workspace)
    const canonicalOracleScript = await realpath(this.oracleScript)
    const canonicalRuntimeRoot = await realpath(this.runtimeRoot)
    const projectCommand = restrictedProjectCommand(this.command, canonicalWorkspace)
    const oracleCommand: [string, ...string[]] = [
      process.execPath,
      '--permission',
      `--allow-fs-read=${canonicalWorkspace}`,
      `--allow-fs-read=${canonicalOracleScript}`,
      '--experimental-strip-types',
      canonicalOracleScript,
      canonicalWorkspace,
    ]
    const probePath = resolve(canonicalWorkspace, '..', 'type-probe.ts')
    await writeFile(probePath, typeProbeSource(canonicalWorkspace), { encoding: 'utf8', mode: 0o600 })
    const canonicalProbePath = await realpath(probePath)
    const typeCommand: [string, ...string[]] = [
      process.execPath,
      '--permission',
      `--allow-fs-read=${canonicalWorkspace}`,
      `--allow-fs-read=${canonicalProbePath}`,
      `--allow-fs-read=${join(canonicalRuntimeRoot, 'node_modules')}`,
      join(canonicalRuntimeRoot, 'node_modules', 'typescript', 'bin', 'tsc'),
      canonicalProbePath,
      '--noEmit',
      '--strict',
      '--skipLibCheck',
      '--allowImportingTsExtensions',
      '--module',
      'NodeNext',
      '--moduleResolution',
      'NodeNext',
      '--target',
      'ES2023',
    ]
    const project = await runProcess(projectCommand, canonicalWorkspace, signal, this.timeoutMs, this.maxCapturedOutputBytes)
    const oracle = await runProcess(oracleCommand, canonicalWorkspace, signal, this.timeoutMs, this.maxCapturedOutputBytes)
    const types = await runProcess(typeCommand, canonicalWorkspace, signal, this.timeoutMs, this.maxCapturedOutputBytes)
    const allowedFiles = ['README.md', 'src/TodoService.ts', 'test/TodoService.test.ts']
    const changedFiles = await changedFilePaths(this.fixtureRoot, canonicalWorkspace)
    const fixtureHash = await hashTree(this.fixtureRoot)
    const baselineHashUnchanged = fixtureHash === baselineFixtureHash
    const policyViolations = [
      ...changedFiles.filter(path => !allowedFiles.includes(path)).map(path => `unapproved file changed: ${path}`),
      ...allowedFiles.filter(path => !changedFiles.includes(path)).map(path => `required file was not changed: ${path}`),
      ...(baselineHashUnchanged ? [] : ['fixture template changed after baseline capture']),
    ]
    const commands = [
      commandReceipt(projectCommand, project),
      commandReceipt(oracleCommand, oracle),
      commandReceipt(typeCommand, types),
    ]
    return {
      passed: [project, oracle, types].every(outcome => outcome.exitCode === 0 && outcome.signal === null && !outcome.timedOut && !outcome.aborted)
        && policyViolations.length === 0,
      commands,
      changedFiles,
      allowedFiles,
      policyViolations,
      baselineHashUnchanged,
    }
  }
}

function restrictedProjectCommand(command: readonly [string, ...string[]], workspace: string): [string, ...string[]] {
  const expected = ['--experimental-strip-types', 'test/TodoService.test.ts']
  if (!['node', 'node.exe'].includes(basename(command[0]).toLowerCase())) {
    throw new Error('the fixed verifier only accepts a direct Node project-test command')
  }
  if (command.slice(1).length !== expected.length || command.slice(1).some((value, index) => value !== expected[index])) {
    throw new Error(`verificationCommand must be exactly node ${expected.join(' ')}`)
  }
  return [
    process.execPath,
    '--permission',
    `--allow-fs-read=${workspace}`,
    ...command.slice(1),
  ]
}

function typeProbeSource(workspace: string): string {
  const importPath = resolve(workspace, 'src', 'TodoService.ts')
  return [
    `import type { CreateTaskInput } from ${JSON.stringify(importPath)}`,
    `const valid: CreateTaskInput = { title: 'ok', requestId: 'request-a' }`,
    '// @ts-expect-error requestId is required by the portable contract',
    `const missing: CreateTaskInput = { title: 'missing' }`,
    'void valid',
    'void missing',
    '',
  ].join('\n')
}

function commandReceipt(command: readonly [string, ...string[]], outcome: ProcessOutcome) {
  return {
    command: command[0],
    args: command.slice(1),
    exitCode: outcome.exitCode ?? -1,
    stdout: outcome.stdout,
    stderr: outcome.stderr,
    durationMs: outcome.durationMs,
  }
}

async function changedFilePaths(fixtureRoot: string, workspace: string): Promise<string[]> {
  const fixtureFiles = await regularFiles(fixtureRoot)
  const workspaceFiles = await regularFiles(workspace)
  const all = [...new Set([...fixtureFiles, ...workspaceFiles])].sort()
  const changed: string[] = []
  for (const path of all) {
    const [before, after] = await Promise.all([
      readFile(resolve(fixtureRoot, path)).catch(() => undefined),
      readFile(resolve(workspace, path)).catch(() => undefined),
    ])
    if (before === undefined || after === undefined || !before.equals(after)) changed.push(path)
  }
  return changed
}

async function regularFiles(root: string): Promise<string[]> {
  const output: string[] = []
  async function walk(directory: string): Promise<void> {
    for (const entry of await readdir(directory, { withFileTypes: true })) {
      const absolute = resolve(directory, entry.name)
      if (entry.isDirectory()) await walk(absolute)
      else {
        const stat = await lstat(absolute)
        if (stat.isSymbolicLink()) throw new Error(`symbolic links are forbidden in verification: ${absolute}`)
        if (stat.isFile()) output.push(relative(root, absolute))
      }
    }
  }
  await walk(root)
  return output.sort()
}

export class GitNoIndexPatchBuilder implements PatchBuilder {
  constructor(
    private readonly timeoutMs: number,
    private readonly maxCapturedOutputBytes: number,
  ) {}

  async build(fixture: string, workspace: string, signal: AbortSignal): Promise<string> {
    const fixtureAbsolute = resolve(fixture)
    const workspaceAbsolute = resolve(workspace)
    const commonParent = resolve(fixtureAbsolute, '..', '..')
    const fixtureArgument = relative(commonParent, fixtureAbsolute)
    const workspaceArgument = relative(commonParent, workspaceAbsolute)
    const outcome = await runProcess(
      ['/usr/bin/git', 'diff', '--no-index', '--no-ext-diff', '--binary', '--', fixtureArgument, workspaceArgument],
      commonParent,
      signal,
      this.timeoutMs,
      this.maxCapturedOutputBytes,
    )
    if (outcome.timedOut || outcome.aborted || outcome.signal !== null || ![0, 1].includes(outcome.exitCode ?? -1)) {
      throw new Error(`could not build patch: exit=${String(outcome.exitCode)} signal=${String(outcome.signal)} ${outcome.stderr}`)
    }
    return outcome.stdout
      .replaceAll(`a/${fixtureArgument}`, 'a/fixture')
      .replaceAll(`b/${workspaceArgument}`, 'b/workspace')
  }
}
