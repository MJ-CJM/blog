import { Ajv2020, type AnySchema, type ErrorObject, type ValidateFunction } from 'ajv/dist/2020.js'

import { sha256, stableStringify } from './stable.js'

const ajv = new Ajv2020({ allErrors: true, strict: true })
const cache = new WeakMap<object, ValidateFunction>()
const cacheById = new Map<string, { readonly fingerprint: string; readonly validate: ValidateFunction }>()

/** Validate with the unmodified portable JSON Schema, including constraints DSH strips for transport. */
export function assertPortableSchema(schema: Record<string, unknown>, value: unknown, label: string): void {
  let validate = cache.get(schema)
  if (validate === undefined) {
    const id = typeof schema.$id === 'string' ? schema.$id : undefined
    const fingerprint = sha256(stableStringify(schema))
    const existing = id === undefined ? undefined : cacheById.get(id)
    if (existing !== undefined && existing.fingerprint !== fingerprint) {
      throw new Error(`portable schema id ${id} was reused with different content`)
    }
    const compiled = existing?.validate ?? ajv.compile(schema as AnySchema)
    if (id !== undefined && existing === undefined) cacheById.set(id, { fingerprint, validate: compiled })
    cache.set(schema, compiled)
    validate = compiled
  }
  if (!validate(value)) {
    throw new Error(`${label} does not match portable schema: ${formatErrors(validate.errors)}`)
  }
}

function formatErrors(errors: ErrorObject[] | null | undefined): string {
  return (errors ?? []).map(error => `${error.instancePath || '/'} ${error.message ?? 'is invalid'}`).join('; ')
}
