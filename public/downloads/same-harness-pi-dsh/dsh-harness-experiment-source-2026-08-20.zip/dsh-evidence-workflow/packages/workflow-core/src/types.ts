export type WorkflowStage =
  | 'created'
  | 'baseline_captured'
  | 'discovering'
  | 'planning'
  | 'awaiting_approval'
  | 'implementing'
  | 'reviewing_verifying'
  | 'completed'
  | 'blocked'
  | 'rejected'
  | 'cancelled'

export type AgentRole =
  | 'code-scout'
  | 'test-scout'
  | 'planner'
  | 'implementer'
  | 'reviewer'
  | 'repair'

export interface WorkflowState {
  readonly schemaVersion: 1
  readonly runId: string
  readonly phase: WorkflowStage
  readonly createdAt: string
  readonly updatedAt: string
  readonly contractHash: string
  readonly runtimeHash: string
  readonly baselineHash?: string
  readonly repairCount: number
  readonly maxRepair: 1
  readonly planHash?: string
  readonly approvalHash?: string
  readonly lastError?: string
  readonly terminalReason?: string
  readonly pendingOperation?: PendingOperation
}

export interface PendingOperation {
  readonly id: string
  readonly name: string
  readonly phase: WorkflowStage
  readonly startedAt: string
}

export interface WorkflowEvent {
  readonly seq: number
  readonly at: string
  readonly type: string
  readonly phase: WorkflowStage
  readonly data: Record<string, unknown>
}

export interface BaselineReceipt {
  readonly runId: string
  readonly capturedAt: string
  readonly fixtureHash: string
  readonly workspaceHash: string
  readonly contractHash: string
  readonly runtimeHash: string
  readonly task: string
  readonly expectedInitialVerification: 'failing'
}

export interface DiscoveryFinding {
  readonly path: string
  readonly reason: string
}

export interface DiscoveryReceipt {
  readonly summary: string
  readonly files: readonly DiscoveryFinding[]
  readonly risks: readonly string[]
}

export interface ChangePlan {
  readonly summary: string
  readonly files: readonly string[]
  readonly steps: readonly string[]
  readonly risks: readonly string[]
  readonly tests: readonly string[]
}

export interface StoredPlan extends ChangePlan {
  readonly planHash: string
}

export interface ApprovalReceipt {
  readonly runId: string
  readonly planHash: string
  readonly baselineHash: string
  readonly contractHash: string
  readonly runtimeHash: string
  readonly approvalHash: string
  readonly decision: 'approved' | 'rejected'
  readonly decidedAt: string
  readonly reason?: string
}

export interface ImplementationReceipt {
  readonly summary: string
  readonly filesChanged: readonly string[]
}

export interface ReviewFinding {
  readonly severity: 'blocker' | 'warning' | 'note'
  readonly message: string
  readonly path?: string
}

export interface ReviewReceipt {
  readonly verdict: 'pass' | 'fail'
  readonly summary: string
  readonly findings: readonly ReviewFinding[]
}

export interface CommandReceipt {
  readonly command: string
  readonly args: readonly string[]
  readonly exitCode: number
  readonly stdout: string
  readonly stderr: string
  readonly durationMs: number
}

export interface VerificationReceipt {
  readonly passed: boolean
  readonly commands: readonly CommandReceipt[]
  readonly changedFiles: readonly string[]
  readonly allowedFiles: readonly string[]
  readonly policyViolations: readonly string[]
  readonly baselineHashUnchanged: boolean
}

export interface AgentRunRequest {
  readonly role: AgentRole
  readonly label: string
  readonly prompt: string
  readonly persona: string
  readonly outputSchema: Record<string, unknown>
  readonly toolNames: readonly string[]
  readonly workspace: string
}

export interface AgentRunner {
  run(request: AgentRunRequest, signal: AbortSignal): Promise<unknown>
}

export interface Verifier {
  verify(workspace: string, baselineFixtureHash: string, signal: AbortSignal): Promise<VerificationReceipt>
}

export interface PatchBuilder {
  build(fixture: string, workspace: string, signal: AbortSignal): Promise<string>
}

export interface WorkflowPaths {
  readonly runRoot: string
  readonly fixtureRoot: string
  readonly contractRoot: string
}

export interface WorkflowConfig extends WorkflowPaths {
  readonly runtimeRoot: string
  readonly maxRepair: number
  readonly verificationCommand: readonly [string, ...string[]]
  readonly oracleScript: string
  readonly verificationTimeoutMs: number
  readonly maxCapturedOutputBytes: number
}

export interface WorkflowSummary {
  readonly runId: string
  readonly stage: WorkflowStage
  readonly planHash?: string
  readonly approvalHash?: string
  readonly repairs: number
  readonly artifacts: readonly string[]
  readonly message: string
}
