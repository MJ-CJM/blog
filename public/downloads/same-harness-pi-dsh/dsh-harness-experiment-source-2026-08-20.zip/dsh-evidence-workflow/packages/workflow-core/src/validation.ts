import type {
  ChangePlan,
  DiscoveryReceipt,
  ImplementationReceipt,
  ReviewReceipt,
} from './types.js'

function record(value: unknown, label: string): Record<string, unknown> {
  if (value === null || typeof value !== 'object' || Array.isArray(value)) throw new Error(`${label} must be an object`)
  return value as Record<string, unknown>
}

function exactKeys(input: Record<string, unknown>, allowed: readonly string[], label: string): void {
  const extras = Object.keys(input).filter(key => !allowed.includes(key))
  if (extras.length > 0) throw new Error(`${label} has unsupported fields: ${extras.join(', ')}`)
}

function stringValue(value: unknown, label: string): string {
  if (typeof value !== 'string' || value.trim() === '') throw new Error(`${label} must be a non-empty string`)
  return value
}

function stringArray(value: unknown, label: string): string[] {
  if (!Array.isArray(value)) throw new Error(`${label} must be an array`)
  return value.map((item, index) => stringValue(item, `${label}[${index}]`))
}


function uniqueStrings(value: unknown, label: string): string[] {
  const output = stringArray(value, label)
  if (new Set(output).size !== output.length) throw new Error(`${label} must contain unique values`)
  return output
}

export function validateDiscovery(value: unknown): DiscoveryReceipt {
  const input = record(value, 'discovery')
  exactKeys(input, ['summary', 'files', 'risks'], 'discovery')
  if (!Array.isArray(input.files)) throw new Error('discovery.files must be an array')
  return {
    summary: stringValue(input.summary, 'discovery.summary'),
    files: input.files.map((item, index) => {
      const finding = record(item, `discovery.files[${index}]`)
      exactKeys(finding, ['path', 'reason'], `discovery.files[${index}]`)
      return {
        path: stringValue(finding.path, `discovery.files[${index}].path`),
        reason: stringValue(finding.reason, `discovery.files[${index}].reason`),
      }
    }),
    risks: stringArray(input.risks, 'discovery.risks'),
  }
}

export function validatePlan(value: unknown): ChangePlan {
  const input = record(value, 'plan')
  exactKeys(input, ['summary', 'files', 'steps', 'risks', 'tests'], 'plan')
  const plan = {
    summary: stringValue(input.summary, 'plan.summary'),
    files: uniqueStrings(input.files, 'plan.files'),
    steps: stringArray(input.steps, 'plan.steps'),
    risks: stringArray(input.risks, 'plan.risks'),
    tests: stringArray(input.tests, 'plan.tests'),
  }
  if (plan.files.length === 0 || plan.steps.length === 0 || plan.tests.length === 0) {
    throw new Error('plan must name at least one file, step, and test')
  }
  const expected = ['README.md', 'src/TodoService.ts', 'test/TodoService.test.ts']
  if (plan.files.length !== expected.length || [...plan.files].sort().join('\n') !== [...expected].sort().join('\n')) {
    throw new Error('plan.files must be exactly the three contract-approved files')
  }
  return plan
}

export function validateImplementation(value: unknown): ImplementationReceipt {
  const input = record(value, 'implementation')
  exactKeys(input, ['summary', 'filesChanged'], 'implementation')
  const filesChanged = uniqueStrings(input.filesChanged, 'implementation.filesChanged')
  const allowed = new Set(['README.md', 'src/TodoService.ts', 'test/TodoService.test.ts'])
  if (filesChanged.some(path => !allowed.has(path))) throw new Error('implementation.filesChanged contains an unapproved file')
  return {
    summary: stringValue(input.summary, 'implementation.summary'),
    filesChanged,
  }
}

export function validateReview(value: unknown): ReviewReceipt {
  const input = record(value, 'review')
  exactKeys(input, ['verdict', 'summary', 'findings'], 'review')
  if (input.verdict !== 'pass' && input.verdict !== 'fail') throw new Error('review.verdict must be pass or fail')
  if (!Array.isArray(input.findings)) throw new Error('review.findings must be an array')
  return {
    verdict: input.verdict,
    summary: stringValue(input.summary, 'review.summary'),
    findings: input.findings.map((item, index) => {
      const finding = record(item, `review.findings[${index}]`)
      exactKeys(finding, ['severity', 'message', 'path'], `review.findings[${index}]`)
      if (!['blocker', 'warning', 'note'].includes(String(finding.severity))) {
        throw new Error(`review.findings[${index}].severity is invalid`)
      }
      return {
        severity: finding.severity as 'blocker' | 'warning' | 'note',
        message: stringValue(finding.message, `review.findings[${index}].message`),
        ...(finding.path === undefined ? {} : { path: stringValue(finding.path, `review.findings[${index}].path`) }),
      }
    }),
  }
}
