import { lstatSync, readFileSync, realpathSync } from 'node:fs'
import { join, relative, resolve, sep } from 'node:path'

import { sha256, stableStringify } from './stable.js'
import { assertRunId } from './store.js'

const ROOT_TOOL = 'evidence_gated_change'
const ROOT_READ_TOOLS = new Set([ROOT_TOOL, 'skill'])
const CHILD_READ_TOOLS = new Set(['read', 'glob', 'grep'])
const CHILD_MUTATION_TOOLS = new Set(['write', 'edit'])
const APPROVED_FILES = new Set(['README.md', 'src/TodoService.ts', 'test/TodoService.test.ts'])

interface SessionLike {
  readonly header: {
    readonly cwd?: string
    readonly origin?: 'subagent'
  }
}

export interface AgentLike {
  readonly session: SessionLike
}

export interface ToolExecutionLike {
  readonly name: string
  readonly arguments: unknown
  readonly agent?: AgentLike
}

export interface TrustedRunIdentity {
  readonly runId: string
  readonly workspace: string
  readonly origin: 'root' | 'subagent'
}

interface GuardEvidence {
  readonly phase: string
  readonly planHash: string
}

/** Resolve authority only from the durable Agent cwd, never from model-controlled tool content. */
export function trustedRunIdentity(runRoot: string, agent: AgentLike | undefined): TrustedRunIdentity | undefined {
  const cwd = agent?.session.header.cwd
  if (cwd === undefined) return undefined
  let canonicalRoot: string
  let canonicalCwd: string
  try {
    canonicalRoot = realpathSync(resolve(runRoot))
    canonicalCwd = realpathSync(resolve(cwd))
  } catch {
    return undefined
  }
  const relation = relative(canonicalRoot, canonicalCwd)
  const parts = relation.split(sep)
  if (parts.length !== 2 || parts[1] !== 'workspace') return undefined
  const runId = parts[0]
  if (runId === undefined) return undefined
  try {
    assertRunId(runId)
  } catch {
    return undefined
  }
  const expected = join(canonicalRoot, runId, 'workspace')
  if (canonicalCwd !== expected) return undefined
  return {
    runId,
    workspace: canonicalCwd,
    origin: agent?.session.header.origin === 'subagent' ? 'subagent' : 'root',
  }
}

/** Fail closed inside a prepared workflow workspace; calls elsewhere are left to the host. */
export function workflowToolDecision(runRoot: string, execution: ToolExecutionLike): string | undefined {
  const identity = trustedRunIdentity(runRoot, execution.agent)
  if (identity === undefined) return undefined

  if (identity.origin === 'root') {
    if (ROOT_READ_TOOLS.has(execution.name)) return undefined
    return `root Agent tools are locked to ${ROOT_TOOL} and the isolated skill loader inside evidence-gated run ${identity.runId}`
  }

  if (CHILD_READ_TOOLS.has(execution.name)) return undefined
  if (!CHILD_MUTATION_TOOLS.has(execution.name)) {
    return `subagent tool ${execution.name} is outside the evidence-gated child allowlist`
  }

  try {
    const evidence = readGuardEvidence(runRoot, identity.runId)
    if (evidence.phase !== 'implementing') {
      return `evidence-gated run ${identity.runId} is ${evidence.phase}, not implementing`
    }
    assertApprovedMutationPath(identity.workspace, execution)
    return undefined
  } catch (error) {
    return `evidence-gated run ${identity.runId} denied mutation: ${error instanceof Error ? error.message : String(error)}`
  }
}

/** Require the initiating session cwd to be exactly this run's isolated workspace. */
export function assertWorkflowSession(runRoot: string, runId: string, agent: AgentLike | undefined): TrustedRunIdentity {
  assertRunId(runId)
  const identity = trustedRunIdentity(runRoot, agent)
  if (identity === undefined || identity.origin !== 'root' || identity.runId !== runId) {
    throw new Error(`start a root DSH session with cwd exactly ${join(resolve(runRoot), runId, 'workspace')}`)
  }
  return identity
}

function assertApprovedMutationPath(workspace: string, execution: ToolExecutionLike): void {
  if (execution.arguments === null || typeof execution.arguments !== 'object' || Array.isArray(execution.arguments)) {
    throw new Error('mutation arguments must be an object')
  }
  const args = execution.arguments as Record<string, unknown>
  const pathValue = args.file_path
  if (typeof pathValue !== 'string' || pathValue.trim() === '') throw new Error('write/edit requires file_path')
  const target = resolve(workspace, pathValue)
  const relativePath = relative(workspace, target)
  if (!APPROVED_FILES.has(relativePath)) throw new Error(`path is not contract-approved: ${relativePath}`)
  if (lstatSync(target).isSymbolicLink()) throw new Error('mutation target must not be a symbolic link')
  if (realpathSync(target) !== target) throw new Error('mutation target traverses a symbolic link')
}

function readGuardEvidence(runRoot: string, runId: string): GuardEvidence {
  const canonicalRoot = realpathSync(resolve(runRoot))
  const directory = join(canonicalRoot, runId)
  if (lstatSync(directory).isSymbolicLink()) throw new Error('run directory must not be a symbolic link')
  const state = readObject(join(directory, 'state.json'))
  const storedPlan = readObject(join(directory, 'plan.json'))
  const baseline = readObject(join(directory, 'baseline.json'))
  const approval = readObject(join(directory, 'approval.json'))
  const { planHash: artifactPlanHash, ...plan } = storedPlan
  const computedPlanHash = sha256(stableStringify(plan))
  if (approval.decision !== 'approved') throw new Error('approval receipt is not approved')
  if (approval.runId !== runId) throw new Error('approval runId mismatch')
  if (typeof state.planHash !== 'string' || state.planHash === '') throw new Error('state has no planHash')
  if (artifactPlanHash !== computedPlanHash) throw new Error('plan artifact hash is stale')
  if (computedPlanHash !== state.planHash || approval.planHash !== state.planHash) {
    throw new Error('planHash binding mismatch')
  }
  const approvalInput = {
    planHash: computedPlanHash,
    baselineHash: baseline.workspaceHash,
    contractHash: baseline.contractHash,
    runtimeHash: baseline.runtimeHash,
  }
  if (Object.values(approvalInput).some(value => typeof value !== 'string' || value === '')) {
    throw new Error('baseline approval inputs are incomplete')
  }
  const computedApprovalHash = sha256(stableStringify(approvalInput))
  if (approval.baselineHash !== baseline.workspaceHash || approval.contractHash !== baseline.contractHash || approval.runtimeHash !== baseline.runtimeHash) {
    throw new Error('approval evidence fields do not bind baseline')
  }
  if (approval.approvalHash !== computedApprovalHash || state.approvalHash !== computedApprovalHash) {
    throw new Error('approvalHash binding mismatch')
  }
  return { phase: String(state.phase), planHash: state.planHash }
}

function readObject(path: string): Record<string, unknown> {
  const value: unknown = JSON.parse(readFileSync(path, 'utf8'))
  if (value === null || typeof value !== 'object' || Array.isArray(value)) throw new Error(`${path} is not an object`)
  return value as Record<string, unknown>
}
