import { existsSync } from 'node:fs'
import { readFile } from 'node:fs/promises'
import { join, resolve } from 'node:path'

import { GitNoIndexPatchBuilder, CommandVerifier } from './process.js'
import { assertPortableSchema } from './schema.js'
import { RunStore } from './store.js'
import { hashTree, portableContractHash, runtimeAdapterHash, sha256, stableStringify } from './stable.js'
import type {
  AgentRole,
  AgentRunRequest,
  AgentRunner,
  ApprovalReceipt,
  BaselineReceipt,
  ChangePlan,
  PatchBuilder,
  ReviewReceipt,
  StoredPlan,
  VerificationReceipt,
  Verifier,
  WorkflowConfig,
  WorkflowState,
  WorkflowSummary,
} from './types.js'
import { validateDiscovery, validateImplementation, validatePlan, validateReview } from './validation.js'

const TASK = 'Add required requestId idempotency to TodoService.createTask under the fixed acceptance contract.'
const READ_TOOLS = ['read', 'glob', 'grep'] as const
const WRITE_TOOLS = ['read', 'write', 'edit', 'glob', 'grep'] as const

export interface WorkflowDependencies {
  readonly verifier?: Verifier
  readonly patchBuilder?: PatchBuilder
}

interface Evaluation {
  readonly review: ReviewReceipt
  readonly verification: VerificationReceipt
}

/** File-backed, approval-gated workflow independent of any agent harness. */
export class EvidenceGatedWorkflow {
  readonly config: WorkflowConfig
  readonly store: RunStore
  private readonly verifier: Verifier
  private readonly patchBuilder: PatchBuilder
  private readonly schemas = new Map<string, Record<string, unknown>>()

  constructor(config: WorkflowConfig, dependencies: WorkflowDependencies = {}) {
    assertConfig(config)
    this.config = {
      ...config,
      runRoot: resolve(config.runRoot),
      fixtureRoot: resolve(config.fixtureRoot),
      contractRoot: resolve(config.contractRoot),
      oracleScript: resolve(config.oracleScript),
      runtimeRoot: resolve(config.runtimeRoot),
    }
    this.store = new RunStore(this.config.runRoot)
    this.verifier = dependencies.verifier ?? new CommandVerifier(
      this.config.verificationCommand,
      this.config.oracleScript,
      this.config.fixtureRoot,
      this.config.runtimeRoot,
      this.config.verificationTimeoutMs,
      this.config.maxCapturedOutputBytes,
    )
    this.patchBuilder = dependencies.patchBuilder ?? new GitNoIndexPatchBuilder(
      this.config.verificationTimeoutMs,
      this.config.maxCapturedOutputBytes,
    )
  }

  /** Create a fresh isolated workspace and immutable baseline before DSH starts inside it. */
  async prepare(runId: string, signal: AbortSignal): Promise<WorkflowSummary> {
    signal.throwIfAborted()
    const [contractHash, runtimeHash] = await Promise.all([
      portableContractHash(this.sharedRoot()),
      runtimeAdapterHash(this.config.runtimeRoot),
    ])
    await this.store.initialize(runId, this.config.fixtureRoot, contractHash, runtimeHash)
    try {
      const baseline = await this.runOperation(runId, 'baseline_capture', {}, signal, async () => {
        const value = await this.captureBaseline(runId, contractHash, runtimeHash)
        await this.store.writeJson(runId, 'baseline.json', value)
        return value
      })
      const state = await this.store.transition(
        runId,
        'baseline_captured',
        'baseline_captured',
        { fixtureHash: baseline.fixtureHash, contractHash },
        { baselineHash: baseline.workspaceHash },
      )
      await this.validatePortable('state', state)
      await this.writeReport(runId, state, 'Prepared an isolated byte-identical baseline; no Agent has run yet.')
      return this.summary(runId, state, 'Run prepared. Start DSH with cwd equal to this run workspace.')
    } catch (error) {
      const state = await this.settleFailure(runId, error, signal)
      await this.writeReport(runId, state, 'Preparation failed before any Agent work.')
      return this.summary(runId, state, state.lastError ?? 'preparation failed')
    }
  }

  /** Run parallel discovery and planning, then stop at the human approval boundary. */
  async plan(runId: string, runner: AgentRunner, signal: AbortSignal): Promise<WorkflowSummary> {
    signal.throwIfAborted()
    let state = await this.store.reconcile(runId)
    if (state.phase !== 'baseline_captured') throw new Error(`run ${runId} cannot plan from ${state.phase}`)
    try {
      const baseline = await this.store.readJson<BaselineReceipt>(runId, 'baseline.json')
      await this.assertImmutableBaseline(runId, state, baseline)
      state = await this.store.transition(runId, 'discovering', 'discovery_started')

      const workspace = this.store.workspace(runId)
      const [codeDiscovery, testDiscovery] = await this.runOperation(runId, 'parallel_discovery', {}, signal, async () => {
        const local = new AbortController()
        const combined = AbortSignal.any([signal, local.signal])
        const [codeRequest, testsRequest] = await Promise.all([
          this.agentRequest('code-scout', workspace, [
            `Task: ${TASK}`,
            `Workspace: ${workspace}`,
            'Inspect implementation and state ownership. Return schema-valid JSON only.',
          ].join('\n\n')),
          this.agentRequest('test-scout', workspace, [
            `Task: ${TASK}`,
            `Workspace: ${workspace}`,
            'Inspect tests and deterministic verification. Return schema-valid JSON only.',
          ].join('\n\n')),
        ])
        const codePromise = runner.run(codeRequest, combined).then(async value => {
          await this.validatePortable('discovery', value)
          return validateDiscovery(value)
        })
        const testsPromise = runner.run(testsRequest, combined).then(async value => {
          await this.validatePortable('discovery', value)
          return validateDiscovery(value)
        })
        try {
          const receipts = await Promise.all([codePromise, testsPromise])
          await Promise.all([
            this.store.writeJson(runId, 'discovery-code.json', receipts[0]),
            this.store.writeJson(runId, 'discovery-tests.json', receipts[1]),
          ])
          return receipts
        } catch (error) {
          local.abort(error)
          await Promise.allSettled([codePromise, testsPromise])
          throw error
        }
      })
      await this.store.appendFact(runId, 'discovery_finished', { roles: ['code-scout', 'test-scout'] })

      state = await this.store.transition(runId, 'planning', 'planning_started')
      const storedPlan = await this.runOperation(runId, 'planning_agent', {}, signal, async () => {
        const value = await runner.run(await this.agentRequest('planner', workspace, [
          `Task: ${TASK}`,
          `Workspace: ${workspace}`,
          `Code Scout receipt:\n${JSON.stringify(codeDiscovery, undefined, 2)}`,
          `Test Scout receipt:\n${JSON.stringify(testDiscovery, undefined, 2)}`,
          'Return the smallest safe plan as schema-valid JSON only.',
        ].join('\n\n')), signal)
        await this.validatePortable('plan', value)
        const plan = validatePlan(value)
        const planHash = canonicalPlanHash(plan)
        const artifact: StoredPlan = { ...plan, planHash }
        await this.store.writeJson(runId, 'plan.json', artifact)
        return artifact
      })
      const approvalHash = canonicalApprovalHash({
        planHash: storedPlan.planHash,
        baselineHash: baseline.workspaceHash,
        contractHash: baseline.contractHash,
        runtimeHash: baseline.runtimeHash,
      })
      state = await this.store.transition(
        runId,
        'awaiting_approval',
        'plan_ready',
        { planHash: storedPlan.planHash, approvalHash },
        { planHash: storedPlan.planHash, approvalHash },
      )
      await this.validatePortable('state', state)
      await this.writeReport(runId, state, 'Plan created. Waiting for an out-of-band approval bound to the displayed approvalHash.')
      return this.summary(runId, state, 'Plan ready; the model-facing tool has no approval action.')
    } catch (error) {
      state = await this.settleFailure(runId, error, signal)
      await this.writeReport(runId, state, 'Planning failed before approval.')
      return this.summary(runId, state, state.lastError ?? 'planning failed')
    }
  }

  /** Record explicit local-user approval for the precomputed four-hash approval token. */
  async approve(runId: string, requestedApprovalHash: string, approvedBy: string): Promise<ApprovalReceipt> {
    const state = await this.store.reconcile(runId)
    if (state.phase !== 'awaiting_approval') throw new Error(`run ${runId} is not awaiting approval`)
    if (state.planHash === undefined || state.approvalHash === undefined) throw new Error('run has no approval-bound plan')
    if (state.approvalHash !== requestedApprovalHash) throw new Error('approvalHash does not match current state')
    if (approvedBy.trim() === '') throw new Error('approvedBy must be non-empty')
    const plan = await this.readStoredPlan(runId)
    if (plan.planHash !== state.planHash) throw new Error('approval does not match canonical plan artifact')
    const baseline = await this.store.readJson<BaselineReceipt>(runId, 'baseline.json')
    await this.assertImmutableBaseline(runId, state, baseline)
    const runtimeHash = await runtimeAdapterHash(this.config.runtimeRoot)
    if (runtimeHash !== baseline.runtimeHash) throw new Error('platform runtime changed after baseline capture')
    const approvalHash = canonicalApprovalHash({
      planHash: plan.planHash,
      baselineHash: baseline.workspaceHash,
      contractHash: baseline.contractHash,
      runtimeHash,
    })
    if (approvalHash !== requestedApprovalHash) throw new Error('supplied approvalHash does not bind current evidence')
    const approval: ApprovalReceipt = {
      runId,
      planHash: plan.planHash,
      baselineHash: baseline.workspaceHash,
      contractHash: baseline.contractHash,
      runtimeHash,
      approvalHash,
      decision: 'approved',
      decidedAt: new Date().toISOString(),
      reason: `approved by ${approvedBy}`,
    }
    await this.validatePortable('approval', approval)
    const signal = new AbortController().signal
    await this.runOperation(runId, 'approval_write', { approvalHash, approvedBy }, signal, async () => {
      await this.store.writeJson(runId, 'approval.json', approval)
    })
    await this.store.appendFact(runId, 'approval_recorded', { planHash: plan.planHash, approvalHash, approvedBy }, { approvalHash })
    return approval
  }

  /** Execute an approved plan, review and verify concurrently, and allow one bounded repair. */
  async execute(runId: string, runner: AgentRunner, signal: AbortSignal): Promise<WorkflowSummary> {
    signal.throwIfAborted()
    let state = await this.store.reconcile(runId)
    if (state.phase !== 'awaiting_approval') throw new Error(`run ${runId} cannot execute from ${state.phase}`)
    try {
      const plan = await this.readStoredPlan(runId)
      const approval = await this.store.readJson<ApprovalReceipt>(runId, 'approval.json')
      const baseline = await this.store.readJson<BaselineReceipt>(runId, 'baseline.json')
      await this.validatePortable('approval', approval)
      this.assertApproval(state, plan, baseline, approval)
      await this.assertImmutableBaseline(runId, state, baseline)

      state = await this.store.transition(runId, 'implementing', 'implementation_started', { planHash: plan.planHash })
      const workspace = this.store.workspace(runId)
      const implementation = await this.runOperation(runId, 'implementation_agent', { planHash: plan.planHash }, signal, async () => {
        const value = await runner.run(await this.agentRequest('implementer', workspace, [
          `Task: ${TASK}`,
          `Workspace: ${workspace}`,
          `Approved plan (${plan.planHash}):\n${JSON.stringify(plan, undefined, 2)}`,
          'Edit only the isolated workspace. Return schema-valid JSON only.',
        ].join('\n\n')), signal)
        await this.validatePortable('implementation', value)
        const receipt = validateImplementation(value)
        await this.store.writeJson(runId, 'implementation.json', receipt)
        return receipt
      })
      await this.store.appendFact(runId, 'implementation_finished', { filesChanged: implementation.filesChanged })
      await this.writePatch(runId, signal)

      let evaluation = await this.evaluate(runId, runner, plan, baseline.fixtureHash, signal, 0)
      while (!passes(evaluation) && state.repairCount < this.config.maxRepair) {
        state = await this.store.readState(runId)
        const nextRepair = state.repairCount + 1
        state = await this.store.transition(
          runId,
          'implementing',
          'repair_started',
          { repair: nextRepair },
          { repairCount: nextRepair },
        )
        const repair = await this.runOperation(runId, 'repair_agent', { repair: nextRepair }, signal, async () => {
          const value = await runner.run(await this.agentRequest('repair', workspace, [
            `Task: ${TASK}`,
            `Workspace: ${workspace}`,
            `Approved plan:\n${JSON.stringify(plan, undefined, 2)}`,
            `Reviewer receipt:\n${JSON.stringify(evaluation.review, undefined, 2)}`,
            `Verifier receipt:\n${JSON.stringify(evaluation.verification, undefined, 2)}`,
            'This is the only repair attempt. Return schema-valid JSON only.',
          ].join('\n\n')), signal)
          await this.validatePortable('implementation', value)
          const receipt = validateImplementation(value)
          await this.store.writeJson(runId, `implementation-repair-${nextRepair}.json`, receipt)
          return receipt
        })
        await this.store.appendFact(runId, 'repair_finished', { repair: nextRepair, filesChanged: repair.filesChanged })
        await this.writePatch(runId, signal)
        evaluation = await this.evaluate(runId, runner, plan, baseline.fixtureHash, signal, nextRepair)
      }

      if (!passes(evaluation)) {
        throw new Error(`deterministic gate rejected: review=${evaluation.review.verdict} verification=${evaluation.verification.passed}`)
      }
      const verificationReceiptHash = sha256(stableStringify(evaluation.verification))
      state = await this.store.transition(runId, 'completed', 'workflow_completed', {
        reviewVerdict: evaluation.review.verdict,
        verificationReceiptHash,
      })
      await this.writeReport(runId, state, 'Reviewer passed and all three deterministic command receipts passed.')
      return this.summary(runId, state, 'Change completed with deterministic evidence.')
    } catch (error) {
      state = await this.settleFailure(runId, error, signal)
      await this.writeReport(runId, state, 'Execution did not satisfy the deterministic gate.')
      return this.summary(runId, state, state.lastError ?? 'execution blocked')
    }
  }

  async status(runId: string): Promise<WorkflowSummary> {
    const state = await this.store.reconcile(runId)
    return this.summary(runId, state, state.lastError ?? `workflow is ${state.phase}`)
  }

  private sharedRoot(): string {
    return resolve(this.config.contractRoot, '..')
  }

  private async captureBaseline(runId: string, contractHash: string, runtimeHash: string): Promise<BaselineReceipt> {
    const [fixtureHash, workspaceHash] = await Promise.all([
      hashTree(this.config.fixtureRoot),
      hashTree(this.store.workspace(runId)),
    ])
    if (fixtureHash !== workspaceHash) throw new Error('workspace copy does not match fixture baseline')
    return {
      runId,
      capturedAt: new Date().toISOString(),
      fixtureHash,
      workspaceHash,
      contractHash,
      runtimeHash,
      task: TASK,
      expectedInitialVerification: 'failing',
    }
  }

  private async assertImmutableBaseline(runId: string, state: WorkflowState, baseline: BaselineReceipt): Promise<void> {
    const [contractHash, fixtureHash, workspaceHash, runtimeHash] = await Promise.all([
      portableContractHash(this.sharedRoot()),
      hashTree(this.config.fixtureRoot),
      hashTree(this.store.workspace(runId)),
      runtimeAdapterHash(this.config.runtimeRoot),
    ])
    if (contractHash !== baseline.contractHash || contractHash !== state.contractHash) {
      throw new Error(`portable contract hash drift: planned=${baseline.contractHash} current=${contractHash}`)
    }
    if (fixtureHash !== baseline.fixtureHash) throw new Error('fixture template changed after baseline capture')
    if (workspaceHash !== baseline.workspaceHash) throw new Error('workspace changed before approved implementation')
    if (runtimeHash !== baseline.runtimeHash || runtimeHash !== state.runtimeHash) {
      throw new Error('platform runtime or verifier changed after baseline capture')
    }
    if (state.baselineHash !== baseline.workspaceHash) throw new Error('state baselineHash does not bind baseline.json')
  }

  private async agentRequest(role: AgentRole, workspace: string, body: string): Promise<AgentRunRequest> {
    const [persona, outputSchema] = await Promise.all([
      readFile(join(this.sharedRoot(), 'agents', `${role}.md`), 'utf8'),
      this.schemaFor(role),
    ])
    const writable = role === 'implementer' || role === 'repair'
    return {
      role,
      label: `egc-${role}`,
      prompt: body,
      persona,
      outputSchema,
      toolNames: writable ? WRITE_TOOLS : READ_TOOLS,
      workspace,
    }
  }

  private async schemaFor(role: AgentRole): Promise<Record<string, unknown>> {
    const schemaName = role === 'code-scout' || role === 'test-scout'
      ? 'discovery'
      : role === 'implementer' || role === 'repair'
        ? 'implementation'
        : role === 'reviewer'
          ? 'review'
          : 'plan'
    return this.portableSchema(schemaName)
  }

  private async portableSchema(schemaName: string): Promise<Record<string, unknown>> {
    const cached = this.schemas.get(schemaName)
    if (cached !== undefined) return cached
    const schema = JSON.parse(await readFile(join(this.config.contractRoot, 'schemas', `${schemaName}.schema.json`), 'utf8')) as Record<string, unknown>
    this.schemas.set(schemaName, schema)
    return schema
  }

  private async validatePortable(schemaName: string, value: unknown): Promise<void> {
    assertPortableSchema(await this.portableSchema(schemaName), value, schemaName)
  }

  private async readStoredPlan(runId: string): Promise<StoredPlan> {
    const stored = await this.store.readJson<Record<string, unknown>>(runId, 'plan.json')
    const { planHash, ...body } = stored
    if (typeof planHash !== 'string' || planHash === '') throw new Error('plan artifact has no planHash')
    await this.validatePortable('plan', body)
    const plan = validatePlan(body)
    const computed = canonicalPlanHash(plan)
    if (computed !== planHash) throw new Error('plan artifact content does not match planHash')
    return { ...plan, planHash }
  }

  private assertApproval(state: WorkflowState, plan: StoredPlan, baseline: BaselineReceipt, approval: ApprovalReceipt): void {
    if (approval.decision !== 'approved') throw new Error('approval receipt is not approved')
    if (approval.runId !== state.runId) throw new Error('approval runId mismatch')
    if (state.planHash === undefined || plan.planHash !== state.planHash || approval.planHash !== state.planHash) {
      throw new Error('approval does not bind the current canonical planHash')
    }
    const expectedHash = canonicalApprovalHash({
      planHash: plan.planHash,
      baselineHash: baseline.workspaceHash,
      contractHash: baseline.contractHash,
      runtimeHash: baseline.runtimeHash,
    })
    if (approval.baselineHash !== baseline.workspaceHash || approval.contractHash !== baseline.contractHash || approval.runtimeHash !== baseline.runtimeHash) {
      throw new Error('approval does not bind baseline, contract, and runtime hashes')
    }
    if (approval.approvalHash !== expectedHash || state.approvalHash !== expectedHash) {
      throw new Error('approvalHash binding mismatch')
    }
  }

  private async evaluate(
    runId: string,
    runner: AgentRunner,
    plan: StoredPlan,
    baselineFixtureHash: string,
    signal: AbortSignal,
    attempt: number,
  ): Promise<Evaluation> {
    await this.store.transition(runId, 'reviewing_verifying', 'review_verification_started', { attempt })
    const patch = await readFile(this.store.artifact(runId, 'patch.diff'), 'utf8')
    const workspace = this.store.workspace(runId)
    const evaluation = await this.runOperation(runId, 'review_and_verification', { attempt }, signal, async () => {
      const local = new AbortController()
      const combined = AbortSignal.any([signal, local.signal])
      const reviewRequest = await this.agentRequest('reviewer', workspace, [
        `Task: ${TASK}`,
        `Workspace: ${workspace}`,
        `Approved plan:\n${JSON.stringify(plan, undefined, 2)}`,
        `Patch:\n${patch}`,
        'Review read-only and return schema-valid JSON only.',
      ].join('\n\n'))
      const reviewPromise = runner.run(reviewRequest, combined).then(async value => {
        await this.validatePortable('review', value)
        return validateReview(value)
      })
      const verificationPromise = this.verifier.verify(workspace, baselineFixtureHash, combined).then(async value => {
        await this.validatePortable('verification', value)
        return value
      })
      try {
        const receipts = await Promise.all([reviewPromise, verificationPromise])
        const [review, verification] = receipts
        const suffix = attempt === 0 ? '' : `-attempt-${attempt}`
        await Promise.all([
          this.store.writeJson(runId, `review${suffix}.json`, review),
          this.store.writeJson(runId, `verification${suffix}.json`, verification),
          this.store.writeJson(runId, 'review.json', review),
          this.store.writeJson(runId, 'verification.json', verification),
        ])
        return { review, verification }
      } catch (error) {
        local.abort(error)
        await Promise.allSettled([reviewPromise, verificationPromise])
        throw error
      }
    })
    const verificationReceiptHash = sha256(stableStringify(evaluation.verification))
    await this.store.appendFact(runId, 'review_verification_finished', {
      attempt,
      reviewVerdict: evaluation.review.verdict,
      verificationPassed: evaluation.verification.passed,
      verificationReceiptHash,
    })
    return evaluation
  }

  private async writePatch(runId: string, signal: AbortSignal): Promise<void> {
    const patch = await this.runOperation(runId, 'patch_capture', {}, signal, async () => {
      const value = await this.patchBuilder.build(this.config.fixtureRoot, this.store.workspace(runId), signal)
      await this.store.writeText(runId, 'patch.diff', value === '' ? '# no changes\n' : value)
      return value
    })
    await this.store.appendFact(runId, 'patch_captured', { sha256: sha256(patch) })
  }

  private async runOperation<T>(
    runId: string,
    type: string,
    data: Record<string, unknown>,
    signal: AbortSignal,
    operation: () => Promise<T>,
  ): Promise<T> {
    signal.throwIfAborted()
    const intent = await this.store.beginOperation(runId, type, data)
    try {
      const value = await operation()
      await this.store.settleOperation(runId, intent.id, 'succeeded', data)
      return value
    } catch (error) {
      await this.store.settleOperation(runId, intent.id, signal.aborted ? 'cancelled' : 'failed', {
        ...data,
        error: error instanceof Error ? error.message : String(error),
      })
      throw error
    }
  }

  private async settleFailure(runId: string, error: unknown, signal: AbortSignal): Promise<WorkflowState> {
    return signal.aborted ? this.store.cancel(runId, signal.reason ?? error) : this.store.block(runId, error)
  }

  private async writeReport(runId: string, state: WorkflowState, conclusion: string): Promise<void> {
    const lines = [
      '# Evidence-Gated Change report',
      '',
      `- Run: \`${runId}\``,
      `- Phase: \`${state.phase}\``,
      `- Plan hash: \`${state.planHash ?? 'not-created'}\``,
      `- Approval hash: \`${state.approvalHash ?? 'not-created'}\``,
      `- Repair attempts: ${state.repairCount}/${state.maxRepair}`,
      `- Portable contract hash: \`${state.contractHash}\``,
      `- Fixture template: \`${this.config.fixtureRoot}\``,
      '',
      '## Conclusion',
      '',
      conclusion,
      '',
      'The deterministic gate trusts `verification.json` process receipts, not Agent prose.',
    ]
    if (state.lastError !== undefined) lines.push('', '## Terminal detail', '', state.lastError)
    const operation = await this.store.beginOperation(runId, 'report_write', { phase: state.phase })
    try {
      await this.store.writeText(runId, 'report.md', lines.join('\n'))
      await this.store.settleOperation(runId, operation.id, 'succeeded')
    } catch (error) {
      await this.store.settleOperation(runId, operation.id, 'failed', {
        error: error instanceof Error ? error.message : String(error),
      })
      throw error
    }
  }

  private summary(runId: string, state: WorkflowState, message: string): WorkflowSummary {
    return {
      runId,
      stage: state.phase,
      repairs: state.repairCount,
      ...(state.planHash === undefined ? {} : { planHash: state.planHash }),
      ...(state.approvalHash === undefined ? {} : { approvalHash: state.approvalHash }),
      artifacts: [
        'events.jsonl',
        'state.json',
        'baseline.json',
        'discovery-code.json',
        'discovery-tests.json',
        'plan.json',
        'approval.json',
        'patch.diff',
        'review.json',
        'verification.json',
        'report.md',
      ].filter(name => existsSync(this.store.artifact(runId, name))),
      message,
    }
  }
}

/** Portable approval hash: canonical plan JSON, excluding the stored planHash field. */
export function canonicalPlanHash(plan: ChangePlan): string {
  return sha256(stableStringify(plan))
}

export function canonicalApprovalHash(input: {
  readonly planHash: string
  readonly baselineHash: string
  readonly contractHash: string
  readonly runtimeHash: string
}): string {
  return sha256(stableStringify(input))
}

function passes(evaluation: Evaluation): boolean {
  return evaluation.review.verdict === 'pass' && evaluation.verification.passed
}

function assertConfig(config: WorkflowConfig): void {
  for (const [name, path] of Object.entries({
    runRoot: config.runRoot,
    fixtureRoot: config.fixtureRoot,
    contractRoot: config.contractRoot,
    oracleScript: config.oracleScript,
    runtimeRoot: config.runtimeRoot,
  })) {
    if (!path.startsWith('/')) throw new Error(`${name} must be absolute`)
  }
  if (config.maxRepair !== 1) throw new Error('the shared contract requires maxRepair to equal 1')
  if (!Array.isArray(config.verificationCommand) || config.verificationCommand.length === 0) {
    throw new Error('verificationCommand must be non-empty')
  }
  if (!Number.isInteger(config.verificationTimeoutMs) || config.verificationTimeoutMs < 1) {
    throw new Error('verificationTimeoutMs must be a positive integer')
  }
  if (!Number.isInteger(config.maxCapturedOutputBytes) || config.maxCapturedOutputBytes < 1024) {
    throw new Error('maxCapturedOutputBytes must be an integer of at least 1024')
  }
}
