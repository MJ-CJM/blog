import { randomUUID } from 'node:crypto'
import { appendFile, cp, mkdir, open, readFile, rename } from 'node:fs/promises'
import { isAbsolute, join, relative, resolve, sep } from 'node:path'

import type { PendingOperation, WorkflowEvent, WorkflowStage, WorkflowState } from './types.js'

const RUN_ID = /^[a-z0-9][a-z0-9_-]{0,63}$/

const ALLOWED_TRANSITIONS: Readonly<Record<WorkflowStage, readonly WorkflowStage[]>> = {
  created: ['baseline_captured', 'blocked', 'cancelled'],
  baseline_captured: ['discovering', 'blocked', 'cancelled'],
  discovering: ['planning', 'blocked', 'cancelled'],
  planning: ['awaiting_approval', 'blocked', 'cancelled'],
  awaiting_approval: ['implementing', 'rejected', 'blocked', 'cancelled'],
  implementing: ['reviewing_verifying', 'blocked', 'cancelled'],
  reviewing_verifying: ['implementing', 'completed', 'blocked', 'cancelled'],
  completed: [],
  blocked: [],
  rejected: [],
  cancelled: [],
}

export function assertRunId(runId: string): void {
  if (!RUN_ID.test(runId)) throw new Error('runId must match /^[a-z0-9][a-z0-9_-]{0,63}$/')
}

function ensureInside(root: string, candidate: string): string {
  const canonicalRoot = resolve(root)
  const canonicalCandidate = resolve(candidate)
  const relation = relative(canonicalRoot, canonicalCandidate)
  if (relation === '' || (!relation.startsWith(`..${sep}`) && relation !== '..' && !isAbsolute(relation))) return canonicalCandidate
  throw new Error(`path escapes run root: ${candidate}`)
}

export class RunStore {
  readonly runRoot: string

  constructor(runRoot: string) {
    if (!isAbsolute(runRoot)) throw new Error('runRoot must be absolute')
    this.runRoot = resolve(runRoot)
  }

  runDir(runId: string): string {
    assertRunId(runId)
    return ensureInside(this.runRoot, join(this.runRoot, runId))
  }

  workspace(runId: string): string {
    return ensureInside(this.runDir(runId), join(this.runDir(runId), 'workspace'))
  }

  artifact(runId: string, name: string): string {
    if (name.includes('/') || name.includes('\\') || name === '' || name === '.' || name === '..') {
      throw new Error(`invalid artifact name: ${name}`)
    }
    return ensureInside(this.runDir(runId), join(this.runDir(runId), name))
  }

  async initialize(runId: string, fixtureRoot: string, contractHash: string, runtimeHash: string): Promise<WorkflowState> {
    assertRunId(runId)
    await mkdir(this.runRoot, { recursive: true, mode: 0o700 })
    await mkdir(this.runDir(runId), { mode: 0o700 })
    const now = new Date().toISOString()
    const state: WorkflowState = {
      schemaVersion: 1,
      runId,
      phase: 'created',
      createdAt: now,
      updatedAt: now,
      contractHash,
      runtimeHash,
      repairCount: 0,
      maxRepair: 1,
    }
    await this.writeJson(runId, 'state.json', state)
    await this.appendEvent(runId, 'workflow_created', state.phase, { workspace: this.workspace(runId) })
    const operation = await this.beginOperation(runId, 'fixture_copy')
    try {
      await cp(fixtureRoot, this.workspace(runId), {
        recursive: true,
        errorOnExist: true,
        force: false,
        verbatimSymlinks: true,
      })
      await this.settleOperation(runId, operation.id, 'succeeded', { workspace: this.workspace(runId) })
    } catch (error) {
      await this.settleOperation(runId, operation.id, 'failed', { error: error instanceof Error ? error.message : String(error) })
      await this.block(runId, error)
      throw error
    }
    return this.readState(runId)
  }

  async readState(runId: string): Promise<WorkflowState> {
    return this.readJson<WorkflowState>(runId, 'state.json')
  }

  async transition(
    runId: string,
    nextPhase: WorkflowStage,
    type: string,
    data: Record<string, unknown> = {},
    fields: Partial<Pick<WorkflowState, 'repairCount' | 'baselineHash' | 'planHash' | 'approvalHash' | 'lastError' | 'terminalReason'>> = {},
  ): Promise<WorkflowState> {
    const current = await this.readState(runId)
    this.assertNoPending(current)
    if (!ALLOWED_TRANSITIONS[current.phase].includes(nextPhase)) {
      throw new Error(`invalid workflow transition ${current.phase} -> ${nextPhase}`)
    }
    const next: WorkflowState = {
      ...current,
      ...fields,
      phase: nextPhase,
      updatedAt: new Date().toISOString(),
    }
    // Journal first: reconcile detects an event/state phase mismatch if the state write crashes.
    await this.appendEvent(runId, type, nextPhase, data)
    await this.writeJson(runId, 'state.json', next)
    return next
  }

  async appendFact(
    runId: string,
    type: string,
    data: Record<string, unknown>,
    fields: Partial<Pick<WorkflowState, 'approvalHash'>> = {},
  ): Promise<WorkflowState> {
    const current = await this.readState(runId)
    this.assertNoPending(current)
    await this.appendEvent(runId, type, current.phase, data)
    if (Object.keys(fields).length === 0) return current
    const next: WorkflowState = { ...current, ...fields, updatedAt: new Date().toISOString() }
    await this.writeJson(runId, 'state.json', next)
    return next
  }

  async beginOperation(
    runId: string,
    name: string,
    data: Record<string, unknown> = {},
  ): Promise<PendingOperation> {
    if (name.trim() === '') throw new Error('operation name must be non-empty')
    const current = await this.readState(runId)
    this.assertNoPending(current)
    const operation: PendingOperation = {
      id: randomUUID(),
      name,
      phase: current.phase,
      startedAt: new Date().toISOString(),
    }
    await this.writeJson(runId, 'state.json', {
      ...current,
      pendingOperation: operation,
      updatedAt: operation.startedAt,
    } satisfies WorkflowState)
    await this.appendEvent(runId, 'operation_intent', current.phase, {
      operationId: operation.id,
      operationType: operation.name,
      ...data,
    })
    return operation
  }

  async settleOperation(
    runId: string,
    operationId: string,
    outcome: 'succeeded' | 'failed' | 'cancelled',
    data: Record<string, unknown> = {},
  ): Promise<WorkflowState> {
    const current = await this.readState(runId)
    const operation = current.pendingOperation
    if (operation === undefined || operation.id !== operationId) throw new Error(`operation ${operationId} is not pending`)
    await this.appendEvent(runId, 'operation_settled', current.phase, {
      operationId,
      operationType: operation.name,
      outcome,
      ...data,
    })
    const { pendingOperation: _pending, ...withoutPending } = current
    const next: WorkflowState = { ...withoutPending, updatedAt: new Date().toISOString() }
    await this.writeJson(runId, 'state.json', next)
    return next
  }

  /** Recover a settled-before-state-clear crash, otherwise converge unknown work fail-closed. */
  async reconcile(runId: string): Promise<WorkflowState> {
    const state = await this.readState(runId)
    const events = await this.events(runId)
    const lastPhase = events.at(-1)?.phase
    const pending = state.pendingOperation
    if (pending !== undefined) {
      const intent = events.some(event => event.type === 'operation_intent' && event.data.operationId === pending.id)
      const settled = events.some(event => event.type === 'operation_settled' && event.data.operationId === pending.id)
      if (settled) {
        const { pendingOperation: _pending, ...withoutPending } = state
        const recovered: WorkflowState = { ...withoutPending, updatedAt: new Date().toISOString() }
        await this.writeJson(runId, 'state.json', recovered)
        await this.appendEvent(runId, 'journal_reconciled', recovered.phase, {
          operationId: pending.id,
          outcome: 'settled-state-clear-recovered',
        })
        return recovered
      }
      if (!intent) {
        await this.appendEvent(runId, 'operation_intent', pending.phase, {
          operationId: pending.id,
          operationType: pending.name,
          recovered: true,
        })
      }
      await this.appendEvent(runId, 'operation_settled', pending.phase, {
        operationId: pending.id,
        operationType: pending.name,
        outcome: 'crash-unknown',
      })
      return this.forceBlocked(runId, state, `unsettled operation recovered fail-closed: ${pending.name} (${pending.id})`)
    }
    const approvalEvent = [...events].reverse().find(event => event.type === 'approval_recorded')
    const recordedApprovalHash = approvalEvent?.data.approvalHash
    if (typeof recordedApprovalHash === 'string' && state.approvalHash !== recordedApprovalHash) {
      return this.forceBlocked(runId, state, 'approval event/state hash mismatch recovered fail-closed')
    }
    if (lastPhase !== undefined && lastPhase !== state.phase) {
      return this.forceBlocked(runId, state, `event/state phase mismatch recovered fail-closed: event=${lastPhase} state=${state.phase}`)
    }
    return state
  }

  async block(runId: string, error: unknown): Promise<WorkflowState> {
    const current = await this.readState(runId)
    if (['blocked', 'completed', 'rejected', 'cancelled'].includes(current.phase)) return current
    const message = error instanceof Error ? error.message : String(error)
    return this.transition(runId, 'blocked', 'workflow_blocked', { error: message }, {
      lastError: message,
      terminalReason: message,
    })
  }

  async cancel(runId: string, reason: unknown): Promise<WorkflowState> {
    const current = await this.readState(runId)
    if (['blocked', 'completed', 'rejected', 'cancelled'].includes(current.phase)) return current
    const message = reason instanceof Error ? reason.message : String(reason)
    return this.transition(runId, 'cancelled', 'workflow_cancelled', { reason: message }, {
      lastError: message,
      terminalReason: message,
    })
  }

  async readJson<T>(runId: string, name: string): Promise<T> {
    return JSON.parse(await readFile(this.artifact(runId, name), 'utf8')) as T
  }

  async writeJson(runId: string, name: string, value: unknown): Promise<void> {
    await this.atomicWrite(this.artifact(runId, name), `${JSON.stringify(value, undefined, 2)}\n`)
  }

  async writeText(runId: string, name: string, value: string): Promise<void> {
    await this.atomicWrite(this.artifact(runId, name), value.endsWith('\n') ? value : `${value}\n`)
  }

  private assertNoPending(state: WorkflowState): void {
    if (state.pendingOperation !== undefined) throw new Error(`operation ${state.pendingOperation.id} is still pending`)
  }

  private async forceBlocked(runId: string, state: WorkflowState, detail: string): Promise<WorkflowState> {
    const { pendingOperation: _pending, ...withoutPending } = state
    const blocked: WorkflowState = {
      ...withoutPending,
      phase: 'blocked',
      updatedAt: new Date().toISOString(),
      lastError: detail,
      terminalReason: detail,
    }
    await this.appendEvent(runId, 'journal_reconciled', 'blocked', { detail })
    await this.writeJson(runId, 'state.json', blocked)
    return blocked
  }

  private async events(runId: string): Promise<WorkflowEvent[]> {
    const raw = await readFile(this.artifact(runId, 'events.jsonl'), 'utf8').catch(error => {
      if ((error as NodeJS.ErrnoException).code === 'ENOENT') return ''
      throw error
    })
    const events = raw.split('\n').filter(Boolean).map(line => JSON.parse(line) as WorkflowEvent)
    for (let index = 0; index < events.length; index += 1) {
      if (events[index]?.seq !== index) throw new Error(`events.jsonl is not contiguous at seq ${index}`)
    }
    return events
  }

  private async appendEvent(runId: string, type: string, phase: WorkflowStage, data: Record<string, unknown>): Promise<void> {
    const seq = (await this.events(runId)).length
    const event: WorkflowEvent = { seq, at: new Date().toISOString(), type, phase, data }
    await appendFile(this.artifact(runId, 'events.jsonl'), `${JSON.stringify(event)}\n`, { encoding: 'utf8', mode: 0o600 })
  }

  private async atomicWrite(path: string, content: string): Promise<void> {
    const temporary = `${path}.tmp-${randomUUID()}`
    const handle = await open(temporary, 'wx', 0o600)
    try {
      await handle.writeFile(content, 'utf8')
      await handle.sync()
    } finally {
      await handle.close()
    }
    await rename(temporary, path)
  }
}
