import { createHash } from 'node:crypto'
import { lstat, readFile, readlink, readdir } from 'node:fs/promises'
import { join, relative } from 'node:path'

interface PortableManifest {
  readonly algorithm: 'sha256'
  readonly aggregate: string
  readonly files: readonly { readonly path: string; readonly sha256: string }[]
}

/** Serialize JSON data with recursively sorted object keys. */
export function stableStringify(value: unknown): string {
  return JSON.stringify(sortJson(value))
}

function sortJson(value: unknown): unknown {
  if (Array.isArray(value)) return value.map(sortJson)
  if (value === null || typeof value !== 'object') return value
  const record = value as Record<string, unknown>
  return Object.fromEntries(Object.keys(record).sort().map(key => [key, sortJson(record[key])]))
}

/** Return a SHA-256 digest for a string or byte buffer. */
export function sha256(value: string | Buffer): string {
  return createHash('sha256').update(value).digest('hex')
}

/** Hash a directory without following symbolic links. */
export async function hashTree(root: string): Promise<string> {
  const entries: Array<{ path: string; kind: 'file' | 'link'; value: Buffer | string }> = []

  async function walk(directory: string): Promise<void> {
    const names = (await readdir(directory)).sort()
    for (const name of names) {
      if (name === 'node_modules' || name === '.git') continue
      const absolute = join(directory, name)
      const stat = await lstat(absolute)
      if (stat.isDirectory()) {
        await walk(absolute)
      } else if (stat.isFile()) {
        entries.push({ path: relative(root, absolute), kind: 'file', value: await readFile(absolute) })
      } else if (stat.isSymbolicLink()) {
        throw new Error(`symbolic links are forbidden in a hashed evidence tree: ${absolute} -> ${await readlink(absolute)}`)
      } else {
        throw new Error(`unsupported filesystem entry while hashing: ${absolute}`)
      }
    }
  }

  await walk(root)
  const digest = createHash('sha256')
  for (const entry of entries) {
    digest.update(entry.kind)
    digest.update('\0')
    digest.update(entry.path)
    digest.update('\0')
    digest.update(entry.value)
    digest.update('\0')
  }
  return digest.digest('hex')
}

/** Verify and return the aggregate hash shared with the Pi implementation. */
export async function portableContractHash(sharedRoot: string): Promise<string> {
  const manifestPath = join(sharedRoot, 'contract', 'manifest.json')
  const manifest = JSON.parse(await readFile(manifestPath, 'utf8')) as PortableManifest
  if (manifest.algorithm !== 'sha256' || !Array.isArray(manifest.files)) throw new Error('invalid portable contract manifest')
  const aggregate = createHash('sha256')
  for (const entry of manifest.files) {
    if (entry.path.startsWith('/') || entry.path.includes('..')) throw new Error(`invalid manifest path: ${entry.path}`)
    const actual = sha256(await readFile(join(sharedRoot, entry.path)))
    if (actual !== entry.sha256) throw new Error(`portable contract drift: ${entry.path}`)
    aggregate.update(`${entry.path}\0${entry.sha256}\0`)
  }
  const actualAggregate = aggregate.digest('hex')
  if (actualAggregate !== manifest.aggregate) throw new Error('portable contract aggregate does not match manifest')
  return actualAggregate
}

/** Hash the platform-owned code and verifier that interpret the portable contract. */
export async function runtimeAdapterHash(runtimeRoot: string): Promise<string> {
  const trees = [
    'packages/workflow-core',
    'packages/workflow-plugin',
    'packages/agent-loop-adapter',
    'lab-home/profiles',
  ] as const
  const files = ['scripts/verify-fixture.mjs', 'pnpm-lock.yaml'] as const
  const digest = createHash('sha256')
  for (const path of trees) {
    digest.update(path)
    digest.update('\0')
    digest.update(await hashTree(join(runtimeRoot, path)))
    digest.update('\0')
  }
  for (const path of files) {
    digest.update(path)
    digest.update('\0')
    digest.update(sha256(await readFile(join(runtimeRoot, path))))
    digest.update('\0')
  }
  return digest.digest('hex')
}
