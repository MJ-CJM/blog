import type { AgentOptions, AgentStatus } from '@deepseek-ai/dsh-agent'

export const FULL_CUSTOM_LOOP_IMPLEMENTATION = '@local/dsh-full-custom-loop'
export const FULL_CUSTOM_LOOP_ALGORITHM = 'budgeted-plan-act-reflect/v1'

export type FullLoopPhase = 'idle' | 'plan' | 'act' | 'reflect' | 'finalize' | 'maintenance'
export type SubagentMode = 'direct-budgeted' | 'full-bpar'

export interface FullCustomLoopConfig {
  agents: Array<AgentOptions & { id: string }>
  maxCycles: number
  maxModelCalls: number
  maxToolCalls: number
  subagentMaxModelCalls: number
  subagentMaxToolCalls: number
  maxTurnMs: number
  planMaxTokens: number
  maxRetriesPerPhase: number
  subagentMode: SubagentMode
  traceRoot: string
}

export interface FullLoopMetrics {
  readonly implementation: typeof FULL_CUSTOM_LOOP_IMPLEMENTATION
  readonly algorithm: typeof FULL_CUSTOM_LOOP_ALGORITHM
  readonly inheritsOfficialAgentLoop: false
  readonly usesOfficialReactLoopAgent: false
  readonly toolScheduling: 'strictly-serial'
  readonly experimentalSeams: readonly ['@deepseek-ai/dsh-agent:Inbox.claim']
  readonly sessionId: string
  readonly status: AgentStatus
  readonly phase: FullLoopPhase
  readonly turns: number
  readonly cycles: number
  readonly modelCalls: number
  readonly toolCalls: number
  readonly retries: number
  readonly currentTurnUsage: {
    readonly cycles: number
    readonly modelCalls: number
    readonly toolCalls: number
  }
  readonly limits: {
    readonly maxCycles: number
    readonly maxModelCalls: number
    readonly maxToolCalls: number
    readonly maxTurnMs: number
  }
  readonly subagentMode: SubagentMode
  readonly isSubagent: boolean
  readonly route: Pick<AgentOptions, 'provider' | 'model'>
}

export interface MutableFullLoopMetrics {
  phase: FullLoopPhase
  turns: number
  cycles: number
  modelCalls: number
  toolCalls: number
  retries: number
}

export interface MutableTurnUsage {
  cycles: number
  modelCalls: number
  toolCalls: number
}

export interface TraceEvent {
  readonly at: string
  readonly sessionId: string
  readonly event: string
  readonly turn?: number
  readonly step?: number
  readonly cycle?: number
  readonly phase?: FullLoopPhase
  readonly durationMs?: number
  readonly provider?: string
  readonly model?: string
  readonly tool?: string
  readonly outcome?: string
  readonly detail?: string
}
