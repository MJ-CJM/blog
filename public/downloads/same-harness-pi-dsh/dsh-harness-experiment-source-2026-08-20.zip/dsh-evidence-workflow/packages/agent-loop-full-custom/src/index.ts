import { isAbsolute, resolve } from 'node:path'

import Schema from '@deepseek-ai/schemastery'
import type {
  AgentFactory,
  AgentHandle,
  AgentOptions,
  AgentSetup,
  CreateAgentOptions,
  ResumeAgentOptions,
  SessionStartSource,
} from '@deepseek-ai/dsh-agent'
import { emitAgentEvent } from '@deepseek-ai/dsh-agent'
import { SessionPreparation, type Session, type SessionId } from '@deepseek-ai/dsh-session'
import { defineTool } from '@deepseek-ai/dsh-tools'
import { Context, Service } from '@deepseek-ai/cordis'

import { BudgetedPlanActReflectAgent } from './agent.js'
import {
  FULL_CUSTOM_LOOP_ALGORITHM,
  FULL_CUSTOM_LOOP_IMPLEMENTATION,
  type FullCustomLoopConfig,
  type SubagentMode,
} from './types.js'

export * from './agent.js'
export * from './types.js'

const DEFAULT_CONFIG: Omit<FullCustomLoopConfig, 'agents' | 'traceRoot'> = {
  maxCycles: 3,
  maxModelCalls: 8,
  maxToolCalls: 4,
  subagentMaxModelCalls: 12,
  subagentMaxToolCalls: 8,
  maxTurnMs: 900_000,
  planMaxTokens: 1_024,
  maxRetriesPerPhase: 1,
  subagentMode: 'direct-budgeted',
}

function deferred<T>(): {
  promise: Promise<T>
  resolve(value: T | PromiseLike<T>): void
  reject(reason?: unknown): void
} {
  let resolve!: (value: T | PromiseLike<T>) => void
  let reject!: (reason?: unknown) => void
  const promise = new Promise<T>((resolvePromise, rejectPromise) => {
    resolve = resolvePromise
    reject = rejectPromise
  })
  return { promise, resolve, reject }
}

export const Config: Schema<FullCustomLoopConfig> = Schema.object({
  agents: Schema.array(Schema.object({
    id: Schema.string().required(),
    provider: Schema.string(),
    model: Schema.string(),
    maxTokens: Schema.number(),
  })).default([]),
  maxCycles: Schema.number().step(1).min(1).default(DEFAULT_CONFIG.maxCycles),
  maxModelCalls: Schema.number().step(1).min(4).default(DEFAULT_CONFIG.maxModelCalls),
  maxToolCalls: Schema.number().step(1).min(1).default(DEFAULT_CONFIG.maxToolCalls),
  subagentMaxModelCalls: Schema.number().step(1).min(4).default(DEFAULT_CONFIG.subagentMaxModelCalls),
  subagentMaxToolCalls: Schema.number().step(1).min(1).default(DEFAULT_CONFIG.subagentMaxToolCalls),
  maxTurnMs: Schema.number().step(1).min(1_000).default(DEFAULT_CONFIG.maxTurnMs),
  planMaxTokens: Schema.number().step(1).min(64).default(DEFAULT_CONFIG.planMaxTokens),
  maxRetriesPerPhase: Schema.number().step(1).min(0).default(DEFAULT_CONFIG.maxRetriesPerPhase),
  subagentMode: Schema.union(['direct-budgeted', 'full-bpar']).default(DEFAULT_CONFIG.subagentMode),
  traceRoot: Schema.string().required(),
}) as Schema<FullCustomLoopConfig>

export function assertFullCustomConfig(config: FullCustomLoopConfig): FullCustomLoopConfig {
  if (config.agents.length !== 0) {
    throw new Error('full custom loop requires config.agents to be empty; use ctx.agents.create/resume')
  }
  for (const [name, value] of Object.entries({
    maxCycles: config.maxCycles,
    maxModelCalls: config.maxModelCalls,
    maxToolCalls: config.maxToolCalls,
    subagentMaxModelCalls: config.subagentMaxModelCalls,
    subagentMaxToolCalls: config.subagentMaxToolCalls,
    maxTurnMs: config.maxTurnMs,
    planMaxTokens: config.planMaxTokens,
    maxRetriesPerPhase: config.maxRetriesPerPhase,
  })) {
    if (!Number.isSafeInteger(value) || value < (name === 'maxRetriesPerPhase' ? 0 : 1)) {
      throw new TypeError(`${name} must be a non-negative or positive safe integer`)
    }
  }
  if (config.maxCycles < 1) throw new Error('maxCycles must be at least 1')
  if (config.maxModelCalls < 4) {
    throw new Error('maxModelCalls must reserve plan, act, reflect, and finalize calls')
  }
  if (config.maxToolCalls < 1) throw new Error('maxToolCalls must be at least 1')
  if (config.subagentMaxModelCalls < 4) {
    throw new Error('subagentMaxModelCalls must reserve plan, act, reflect, and finalize calls')
  }
  if (config.subagentMaxToolCalls < 1) throw new Error('subagentMaxToolCalls must be at least 1')
  if (config.maxTurnMs < 1_000) throw new Error('maxTurnMs must be at least 1000')
  if (config.planMaxTokens < 64) throw new Error('planMaxTokens must be at least 64')
  if (!isAbsolute(config.traceRoot)) throw new Error('traceRoot must be absolute')
  if (config.subagentMode !== 'direct-budgeted' && config.subagentMode !== 'full-bpar') {
    throw new Error(`unsupported subagentMode ${JSON.stringify(config.subagentMode satisfies never)}`)
  }
  return { ...config, traceRoot: resolve(config.traceRoot) }
}

function assertAgentOptions(options: AgentOptions): void {
  if (options.maxTokens !== undefined
    && (!Number.isSafeInteger(options.maxTokens) || options.maxTokens <= 0)) {
    throw new TypeError('agent maxTokens must be a positive safe integer')
  }
}

async function raceAbort<T>(operation: PromiseLike<T> | T, signal: AbortSignal, id: SessionId): Promise<T> {
  const failure = (): Error => signal.reason instanceof Error
    ? signal.reason
    : new Error(`full custom loop agent "${id}" creation aborted`, { cause: signal.reason })
  if (signal.aborted) throw failure()
  const aborted = deferred<never>()
  const listener = (): void => aborted.reject(failure())
  signal.addEventListener('abort', listener, { once: true })
  try {
    return await Promise.race([Promise.resolve(operation), aborted.promise])
  } finally {
    signal.removeEventListener('abort', listener)
  }
}

/** Start an abortable public-service call and release a value that arrives after cancellation. */
async function raceAbortCall<T>(
  operation: () => PromiseLike<T> | T,
  signal: AbortSignal,
  id: SessionId,
  releaseAbandoned?: (value: T) => void,
): Promise<T> {
  if (signal.aborted) {
    throw signal.reason instanceof Error
      ? signal.reason
      : new Error(`full custom loop agent "${id}" creation aborted`, { cause: signal.reason })
  }
  const pending = Promise.resolve().then(operation)
  try {
    return await raceAbort(pending, signal, id)
  } catch (error: unknown) {
    if (signal.aborted && releaseAbandoned !== undefined) {
      void pending.then(releaseAbandoned, () => undefined)
    }
    throw error
  }
}

/**
 * Third AgentFactory implementation for the lab. This service deliberately
 * never imports @deepseek-ai/dsh-agent-loop.
 */
export class FullCustomLoopService extends Service implements AgentFactory {
  static inject = ['agents', 'sessions', 'llm', 'tools', 'systemPrompt']
  static Config = Config

  readonly config: FullCustomLoopConfig
  /** Stable provider Context: Service methods are contextualized to their caller by Cordis. */
  private readonly runtimeCtx: Context
  private readonly shutdownSignal = new AbortController()
  private readonly active = new Set<() => Promise<void>>()
  private readonly pending = new Set<Promise<void>>()

  constructor(ctx: Context, config: FullCustomLoopConfig) {
    super(ctx, 'agentLoop')
    this.runtimeCtx = ctx
    this.config = assertFullCustomConfig(config)
    ctx.effect(() => ctx.agents.setFactory(this), 'fullCustomLoop.setFactory()')
    ctx.effect(() => () => this.shutdown(), 'fullCustomLoop.lifecycle()')
    ctx.systemPrompt.variable('provider', context => context.agent?.options.provider)
    ctx.systemPrompt.variable('model', context => context.agent?.options.model)
    ctx.systemPrompt.variable('cwd', context => context.agent?.session.header.cwd)
    ctx.systemPrompt.context({
      name: 'full-custom-loop',
      order: -20,
      text: context => context.agent instanceof BudgetedPlanActReflectAgent
        ? `Loop implementation: ${FULL_CUSTOM_LOOP_IMPLEMENTATION}\nAlgorithm: ${FULL_CUSTOM_LOOP_ALGORITHM}\nOfficial AgentLoop inheritance: false\nTool scheduling: strictly serial`
        : '',
    })
    ctx.tools.register(defineTool({
      name: 'full_loop_diagnostics',
      description: 'Prove that the current Agent is driven by the independent Full Custom Loop and report its live budgets and counters.',
      parameters: {},
      output: {
        schema: { type: 'object', additionalProperties: true },
        render: (_args, value) => [{ type: 'text', text: JSON.stringify(value, null, 2) }],
      },
      isConcurrencySafe: () => true,
      execute: async (_args, exec) => {
        if (!(exec.agent instanceof BudgetedPlanActReflectAgent)) {
          throw new Error('full_loop_diagnostics requires an Agent created by @local/dsh-full-custom-loop')
        }
        return {
          ...exec.agent.diagnostics(),
          experimentalSeams: ['@deepseek-ai/dsh-agent:Inbox.claim'],
          traceFile: exec.agent.trace.filePath,
        }
      },
    }))
  }

  /** The official legacy synchronous path is intentionally not emulated. */
  create(): never {
    throw new Error('full custom loop supports only ctx.agents.create/resume; legacy ctx.agentLoop.create is not implemented')
  }

  async createAgent(ownerCtx: Context, options: CreateAgentOptions): Promise<AgentHandle> {
    assertAgentOptions(options.agentOptions ?? {})
    const preparation = SessionPreparation.create(this.runtimeCtx.sessions.prepare(options.sessionId, {
      ...options.seed === undefined ? {} : { seed: options.seed },
      ...options.meta === undefined ? {} : { meta: options.meta },
    }))
    const published = this.setupAndPublish(
      ownerCtx,
      preparation,
      options.agentOptions ?? {},
      options.setup,
      options.signal,
      'startup',
    )
    this.trackPending(published)
    return published
  }

  async resume(ownerCtx: Context, options: ResumeAgentOptions): Promise<AgentHandle> {
    assertAgentOptions(options.agentOptions ?? {})
    const persistence = this.runtimeCtx.get('sessionPersistence') as undefined | {
      prepare(id: SessionId, signal?: AbortSignal): Promise<SessionPreparation>
    }
    if (persistence === undefined) {
      throw new Error('cannot resume full custom loop: session persistence is not configured')
    }
    const id = options.resumeSessionId
    const published = (async () => {
      const ownerAbort = new AbortController()
      const unfollowOwner = ownerCtx.effect(() => () => {
        ownerAbort.abort(new Error(`full custom loop agent "${id}" resume load aborted: owner disposed`))
      }, `fullCustomLoop.resume-load(${id})`)
      const fused = AbortSignal.any([
        this.shutdownSignal.signal,
        ownerAbort.signal,
        ...options.signal === undefined ? [] : [options.signal],
      ])
      let preparation: SessionPreparation | undefined
      try {
        try {
          preparation = await raceAbortCall(
            () => persistence.prepare(id, fused),
            fused,
            id,
            abandoned => { abandoned[Symbol.dispose]() },
          )
        } finally {
          await unfollowOwner()
        }
        ownerCtx.fiber.assertActive()
        this.shutdownSignal.signal.throwIfAborted()
        return await this.setupAndPublish(
          ownerCtx,
          preparation,
          options.agentOptions ?? {},
          options.setup,
          options.signal,
          'resume',
        )
      } finally {
        preparation?.[Symbol.dispose]()
      }
    })()
    this.trackPending(published)
    return published
  }

  private async setupAndPublish(
    ownerCtx: Context,
    preparation: SessionPreparation,
    options: AgentOptions,
    setup: AgentSetup | undefined,
    callerSignal: AbortSignal | undefined,
    source: SessionStartSource,
  ): Promise<AgentHandle> {
    using ownedPreparation = preparation
    ownerCtx.fiber.assertActive()
    const session = ownedPreparation.session
    const ownerAbort = new AbortController()
    const lifecycleAbort = new AbortController()
    const fused = AbortSignal.any([
      this.shutdownSignal.signal,
      ownerAbort.signal,
      lifecycleAbort.signal,
      ...callerSignal === undefined ? [] : [callerSignal],
    ])
    const agent = new BudgetedPlanActReflectAgent(this.runtimeCtx, session.id, options, session, this.config)
    let detachSession: (() => void) | undefined
    let detachAgent: (() => void) | undefined
    let disposing: Promise<void> | undefined
    let ownerTriggered = false
    let untrack = (): void => {}

    const dispose = (fromOwner = false): Promise<void> => (disposing ??= (async () => {
      const failures: unknown[] = []
      const cleanup = async (operation: () => PromiseLike<unknown> | unknown): Promise<void> => {
        try {
          await operation()
        } catch (error: unknown) {
          failures.push(error)
        }
      }

      lifecycleAbort.abort(new Error(`full custom loop agent "${session.id}" lifecycle disposed`))
      agent.markDisposed()
      await cleanup(() => agent.cancel({ kind: 'disposed' }))
      await cleanup(() => agent.whenIdle())
      await cleanup(() => agent.scope.dispose())
      await cleanup(() => detachAgent?.())
      await cleanup(() => detachSession?.())
      agent.trace.append({ event: 'agent-disposed' })
      untrack()
      if (!fromOwner && !ownerTriggered) await cleanup(() => unfollowOwner())

      if (failures.length === 1) throw failures[0]
      if (failures.length > 1) {
        throw new AggregateError(failures, `full custom loop agent "${session.id}" teardown failed`)
      }
    })())

    const unfollowOwner = ownerCtx.effect(() => () => {
      ownerTriggered = true
      ownerAbort.abort(new Error(`full custom loop agent "${session.id}" owner disposed`))
      if (disposing !== undefined) return
      return dispose(true)
    }, `fullCustomLoop.owner(${session.id})`)
    this.active.add(dispose)
    untrack = () => { this.active.delete(dispose) }

    try {
      const setupCommit = await raceAbort(setup?.(agent.ctx), fused, session.id)
      setupCommit?.commit()
      fused.throwIfAborted()
      detachSession = agent.ctx.sessions.enter(session)
      detachAgent = this.runtimeCtx.agents.enter(agent, ownerCtx.agent)
      agent.ctx.sessions.announce(session)
      fused.throwIfAborted()
      this.runtimeCtx.agents.announce(agent)
      fused.throwIfAborted()
      emitAgentEvent(this.runtimeCtx, agent, 'agent/session-start', { source })
      fused.throwIfAborted()
      agent.trace.append({ event: 'agent-published', outcome: source })
      return { agent, dispose }
    } catch (error: unknown) {
      try {
        await dispose()
      } catch (cleanupError: unknown) {
        throw new AggregateError(
          [error, cleanupError],
          `full custom loop agent "${session.id}" setup failed and teardown also failed`,
        )
      }
      throw error
    }
  }

  private async shutdown(): Promise<void> {
    this.shutdownSignal.abort(new Error('full custom loop service is unloading'))
    const failures: unknown[] = []
    do {
      const results = await Promise.allSettled([
        ...[...this.active].map(dispose => dispose()),
        ...this.pending,
      ])
      for (const result of results) {
        if (result.status === 'rejected') failures.push(result.reason)
      }
    } while (this.active.size > 0 || this.pending.size > 0)
    if (failures.length === 1) throw failures[0]
    if (failures.length > 1) throw new AggregateError(failures, 'full custom loop shutdown failed')
  }

  private trackPending(job: Promise<unknown>): void {
    const settled = job.then(() => undefined, () => undefined)
    this.pending.add(settled)
    void settled.finally(() => { this.pending.delete(settled) })
  }
}

export type { SubagentMode }
export default FullCustomLoopService
