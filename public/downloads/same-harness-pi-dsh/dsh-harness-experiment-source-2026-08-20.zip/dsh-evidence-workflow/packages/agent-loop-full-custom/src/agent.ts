import type {
  Agent,
  AgentCancelCause,
  AgentEventDispatch,
  AgentOptions,
  AgentStatus,
  CancelOptions,
  InboxTarget,
  PreStepDecision,
  RequestErrorAction,
} from '@deepseek-ai/dsh-agent'
import { Inbox, agentEvents, assembleContextFor } from '@deepseek-ai/dsh-agent'
import type {
  GenerateOptions,
  LlmCallConfig,
  Message,
  PreparedLlmCall,
  ToolCallBlock,
} from '@deepseek-ai/dsh-llm'
import {
  BlockAssembler,
  LlmError,
  createAssistantMessage,
  createToolResultMessage,
  createUserMessage,
  deepFreeze,
  errorChain,
  markAgentLoopRequest,
} from '@deepseek-ai/dsh-llm'
import { createScope, type Scope } from '@deepseek-ai/dsh-scope'
import {
  canonicalHeader,
  headerEquals,
  type RequestContext,
  type Session,
  type SessionId,
  type TurnEndReason,
  type UserMessage,
} from '@deepseek-ai/dsh-session'
import {
  joinContextSections,
  renderContextSections,
  renderPrompt,
  type PromptAssembly,
} from '@deepseek-ai/dsh-system-prompt'
import type { ToolExecutionResult } from '@deepseek-ai/dsh-tools'
import type { Context } from '@deepseek-ai/cordis'

import { FullLoopContextProjection } from './context-projection.js'
import { FullLoopTraceStore } from './trace.js'
import {
  FULL_CUSTOM_LOOP_ALGORITHM,
  FULL_CUSTOM_LOOP_IMPLEMENTATION,
  type FullCustomLoopConfig,
  type FullLoopMetrics,
  type FullLoopPhase,
  type MutableFullLoopMetrics,
  type MutableTurnUsage,
} from './types.js'

type DriverPhase =
  | { kind: 'idle'; lastTurn: number }
  | { kind: 'maintenance'; abort: AbortController; lastTurn: number; wakeRequested: boolean }
  | { kind: 'running'; abort: AbortController; turn: number; step: number; wakeRequested: boolean }

interface ModelStepResult {
  readonly message: ReturnType<typeof createAssistantMessage>
  readonly finish: 'completed' | 'max-tokens'
  readonly toolCalls: ToolCallBlock[]
}

interface ToolBatchResult {
  readonly concluded: boolean
}

type ReflectionDecision = 'continue' | 'replan' | 'finish'

class FullLoopBudgetError extends Error {
  readonly code = 'FULL_CUSTOM_LOOP_BUDGET'
}

class FullLoopStepRejected extends Error {}

const PLUGIN_SOURCE = '@local/dsh-full-custom-loop'

function deferred<T>(): {
  promise: Promise<T>
  resolve(value: T | PromiseLike<T>): void
  reject(reason?: unknown): void
} {
  let resolve!: (value: T | PromiseLike<T>) => void
  let reject!: (reason?: unknown) => void
  const promise = new Promise<T>((resolvePromise, rejectPromise) => {
    resolve = resolvePromise
    reject = rejectPromise
  })
  return { promise, resolve, reject }
}

function phaseInstruction(phase: Exclude<FullLoopPhase, 'idle' | 'maintenance'>): string {
  switch (phase) {
    case 'plan':
      return [
        'FULL CUSTOM LOOP — PLAN PHASE.',
        'Do not answer the user yet and do not call tools.',
        'Write a concise plan with the objective, success criteria, evidence to inspect, and the next action.',
      ].join('\n')
    case 'act':
      return [
        'FULL CUSTOM LOOP — ACT PHASE.',
        'Execute the current plan. Use tools when evidence or an action is required.',
        'This loop dispatches at most one requested tool per cycle and settles every extra request as skipped.',
      ].join('\n')
    case 'reflect':
      return [
        'FULL CUSTOM LOOP — REFLECT PHASE.',
        'Do not call tools. Return exactly one JSON object:',
        '{"decision":"continue|replan|finish","reason":"non-empty reason"}',
      ].join('\n')
    case 'finalize':
      return [
        'FULL CUSTOM LOOP — FINALIZE PHASE.',
        'Do not call tools. Give the user the final answer now, using the evidence already present in the conversation.',
      ].join('\n')
  }
}

function pluginMessage(text: string): UserMessage {
  return createUserMessage({
    content: [{ type: 'text', text }],
    source: { kind: 'plugin', plugin: PLUGIN_SOURCE },
  })
}

function parseArguments(raw: string): unknown {
  try {
    return raw ? JSON.parse(raw) : {}
  } catch {
    return raw
  }
}

function parseReflection(message: ModelStepResult['message']): ReflectionDecision | undefined {
  const text = message.content
    .filter((block): block is Extract<typeof block, { type: 'text' }> => block.type === 'text')
    .map(block => block.text)
    .join('\n')
    .trim()
  const candidate = text.startsWith('```')
    ? text.replace(/^```(?:json)?\s*/u, '').replace(/\s*```$/u, '')
    : text
  try {
    const parsed: unknown = JSON.parse(candidate)
    if (typeof parsed !== 'object' || parsed === null || Array.isArray(parsed)) return
    const decision = (parsed as { decision?: unknown }).decision
    const reason = (parsed as { reason?: unknown }).reason
    if ((decision === 'continue' || decision === 'replan' || decision === 'finish')
      && typeof reason === 'string' && reason.trim().length > 0) return decision
  } catch {
    return
  }
}

/**
 * Independent Agent implementation. It does not inherit or instantiate the
 * official AgentLoop/ReactLoopAgent and intentionally schedules tools serially.
 */
export class BudgetedPlanActReflectAgent implements Agent {
  readonly inbox: Inbox
  readonly scope: Scope
  readonly ctx: Context
  readonly trace: FullLoopTraceStore

  private phase: DriverPhase
  private activityDone: Promise<void> = Promise.resolve()
  private readonly dispatch: AgentEventDispatch
  private readonly runtimeContext: FullLoopContextProjection
  private requestHeaderLogged = false
  private disposed = false
  private readonly metrics: MutableFullLoopMetrics = {
    phase: 'idle',
    turns: 0,
    cycles: 0,
    modelCalls: 0,
    toolCalls: 0,
    retries: 0,
  }
  private readonly turnUsage: MutableTurnUsage = { cycles: 0, modelCalls: 0, toolCalls: 0 }

  constructor(
    private readonly loopCtx: Context,
    public readonly id: SessionId,
    public readonly options: AgentOptions,
    public readonly session: Session,
    private readonly config: FullCustomLoopConfig,
  ) {
    this.dispatch = agentEvents(loopCtx, this)
    this.inbox = new Inbox(session, {
      inserted: message => this.dispatch.emit('agent/inbox/inserted', { message }),
      discarded: message => this.dispatch.emit('agent/inbox/discarded', { message }),
      claimed: (message, turn) => this.dispatch.emit('agent/inbox/claimed', { message, turn }),
    })
    const lastTurn = session.events.findLast(event => event.type === 'turn/start')?.data.turn ?? 0
    this.phase = { kind: 'idle', lastTurn }
    this.scope = createScope(loopCtx, this)
    this.ctx = this.scope.ctx.extend({ agent: this })
    this.runtimeContext = new FullLoopContextProjection(this.ctx, session)
    this.trace = new FullLoopTraceStore(config.traceRoot, id)
    this.trace.append({ event: 'agent-constructed', outcome: this.isSubagent ? config.subagentMode : 'full-bpar' })
  }

  get status(): AgentStatus {
    return this.phase.kind === 'running' ? 'running' : 'idle'
  }

  get isSubagent(): boolean {
    return this.session.header.origin === 'subagent'
  }

  private get modelCallLimit(): number {
    return this.isSubagent ? this.config.subagentMaxModelCalls : this.config.maxModelCalls
  }

  private get toolCallLimit(): number {
    return this.isSubagent ? this.config.subagentMaxToolCalls : this.config.maxToolCalls
  }

  diagnostics(): FullLoopMetrics {
    return {
      implementation: FULL_CUSTOM_LOOP_IMPLEMENTATION,
      algorithm: FULL_CUSTOM_LOOP_ALGORITHM,
      inheritsOfficialAgentLoop: false,
      usesOfficialReactLoopAgent: false,
      toolScheduling: 'strictly-serial',
      experimentalSeams: ['@deepseek-ai/dsh-agent:Inbox.claim'],
      sessionId: this.id,
      status: this.status,
      phase: this.metrics.phase,
      turns: this.metrics.turns,
      cycles: this.metrics.cycles,
      modelCalls: this.metrics.modelCalls,
      toolCalls: this.metrics.toolCalls,
      retries: this.metrics.retries,
      currentTurnUsage: { ...this.turnUsage },
      limits: {
        maxCycles: this.config.maxCycles,
        maxModelCalls: this.modelCallLimit,
        maxToolCalls: this.toolCallLimit,
        maxTurnMs: this.config.maxTurnMs,
      },
      subagentMode: this.config.subagentMode,
      isSubagent: this.isSubagent,
      route: {
        ...this.options.provider === undefined ? {} : { provider: this.options.provider },
        ...this.options.model === undefined ? {} : { model: this.options.model },
      },
    }
  }

  send(message: UserMessage, target: InboxTarget, wakeup: boolean): void {
    if (this.disposed) throw new Error(`full custom loop agent "${this.id}" is disposed`)
    const wakingAfterAbort = wakeup && this.phase.kind !== 'idle' && this.phase.abort.signal.aborted
    const resolvedTarget = wakingAfterAbort ? 'next-turn' : target
    this.inbox.splice(resolvedTarget, Infinity, 0, [message])
    if (wakeup) this.wakeDriver(wakingAfterAbort)
  }

  followup(input: UserMessage): void {
    this.send(input, 'next-turn', true)
  }

  steer(input: UserMessage): void {
    this.send(input, 'next-step', true)
  }

  inject(input: UserMessage): void {
    this.send(input, 'next-step', false)
  }

  cancel(cause: AgentCancelCause, options: CancelOptions = {}): void {
    if (!options.keepInbox) {
      this.inbox.clear()
      if (this.phase.kind !== 'idle') this.phase.wakeRequested = false
    }
    if (this.phase.kind !== 'idle') this.phase.abort.abort(cause)
  }

  markDisposed(): void {
    this.disposed = true
  }

  runMaintenance<T>(job: (signal: AbortSignal) => Promise<T>): Promise<T> {
    if (this.phase.kind !== 'idle') throw new Error(`agent "${this.id}" already has active work`)
    const done = deferred<void>()
    const maintenance: DriverPhase = {
      kind: 'maintenance',
      abort: new AbortController(),
      lastTurn: this.phase.lastTurn,
      wakeRequested: false,
    }
    this.phase = maintenance
    this.metrics.phase = 'maintenance'
    this.activityDone = done.promise
    return (async () => {
      try {
        return await job(maintenance.abort.signal)
      } finally {
        this.phase = { kind: 'idle', lastTurn: maintenance.lastTurn }
        this.metrics.phase = 'idle'
        if (maintenance.wakeRequested && this.inbox.hasPending) this.wakeDriver()
        done.resolve()
      }
    })()
  }

  async whenIdle(): Promise<void> {
    let activity: Promise<void>
    do {
      await (activity = this.activityDone)
    } while (activity !== this.activityDone)
  }

  private setRunningStatus(next: DriverPhase): void {
    const previous = this.status
    this.phase = next
    if (this.status !== previous) this.dispatch.emit('agent/status', { status: this.status })
  }

  private wakeDriver(wakeAfterAbort = false): void {
    if (this.phase.kind !== 'idle') {
      const reason = this.phase.abort.signal.reason as AgentCancelCause | undefined
      if (reason?.kind !== 'disposed' && (this.phase.kind === 'maintenance' || wakeAfterAbort)) {
        this.phase.wakeRequested = true
      }
      return
    }
    const done = deferred<void>()
    this.activityDone = done.promise
    this.setRunningStatus({
      kind: 'running',
      abort: new AbortController(),
      turn: this.phase.lastTurn,
      step: 0,
      wakeRequested: false,
    })
    Promise.resolve(this.loopCtx.agents.withInitiator(this, () => this.drive()))
      .then(done.resolve, done.resolve)
  }

  private async drive(): Promise<void> {
    try {
      while (await this.runTurn()) {}
    } catch {
      // Every failure is recorded at the turn boundary and contained here.
    } finally {
      if (this.phase.kind === 'running') {
        const { turn, wakeRequested } = this.phase
        this.setRunningStatus({ kind: 'idle', lastTurn: turn })
        this.metrics.phase = 'idle'
        if (wakeRequested && this.inbox.hasPending) this.wakeDriver()
      }
    }
  }

  private throwReported(error: unknown): never {
    const turn = this.phase.kind === 'running' ? this.phase.turn : this.phase.lastTurn
    const step = this.phase.kind === 'running' ? this.phase.step : 0
    this.dispatch.emit('agent/error', { turn, step, error })
    throw error
  }

  private async runTurn(): Promise<boolean> {
    if (this.phase.kind !== 'running') throw new Error('full custom loop turn outside running phase')
    const running = this.phase
    const turn = running.turn + 1
    running.turn = turn
    running.step = 0
    this.turnUsage.cycles = 0
    this.turnUsage.modelCalls = 0
    this.turnUsage.toolCalls = 0
    this.metrics.turns++
    let ending: TurnEndReason | undefined
    const timeout = setTimeout(() => {
      running.abort.abort({ kind: 'hook', reason: `full custom loop exceeded maxTurnMs=${this.config.maxTurnMs}` } satisfies AgentCancelCause)
    }, this.config.maxTurnMs)
    this.session.append('turn/start', { turn })
    this.trace.append({ event: 'turn-start', turn })
    try {
      const initial = this.inbox.claim('next-turn', turn)
      if (initial.length === 0) {
        ending = { kind: 'completed' }
        return false
      }
      let input = initial
      while (true) {
        ending = this.isSubagent && this.config.subagentMode === 'direct-budgeted'
          ? await this.runDirectTurn(input)
          : await this.runBparTurn(input)
        if (this.inbox.nextStep.length === 0) {
          await this.dispatch.serial('agent/turn-stopping', { turn, signal: running.abort.signal })
          running.abort.signal.throwIfAborted()
        }
        if (this.inbox.nextStep.length === 0) break
        input = this.inbox.claim('next-step', turn)
      }
    } catch (error: unknown) {
      if (error instanceof FullLoopStepRejected) {
        ending = { kind: 'blocked' }
        return false
      } else if (running.abort.signal.aborted) {
        ending = {
          kind: 'aborted',
          reason: running.abort.signal.reason as AgentCancelCause,
        }
        throw error
      } else {
        ending = {
          kind: 'error',
          error: error instanceof LlmError
            ? error.failure
            : {
              message: errorChain(error),
              code: error instanceof FullLoopBudgetError ? error.code : 'UNKNOWN',
            },
        }
        this.throwReported(error)
      }
    } finally {
      clearTimeout(timeout)
      this.session.append('turn/end', {
        turn,
        reason: ending ?? { kind: 'error', error: { message: 'full custom loop ended without a reason', code: 'INVARIANT' } },
      })
      this.trace.append({ event: 'turn-end', turn, outcome: ending?.kind ?? 'invariant-error' })
    }
    if (!this.inbox.hasPending) return false
    running.abort = new AbortController()
    running.wakeRequested = false
    running.step = 0
    return true
  }

  private async runDirectTurn(initial: UserMessage[]): Promise<TurnEndReason> {
    let pending = initial
    while (true) {
      const step = await this.runModelStep('act', pending, true)
      if (step.finish === 'max-tokens') return { kind: 'max-tokens' }
      if (step.toolCalls.length === 0) return { kind: 'completed' }
      const tools = await this.executeActTools(step.toolCalls)
      if (tools.concluded) return { kind: 'completed' }
      pending = this.inbox.claim('next-step', this.currentTurn())
    }
  }

  private async runBparTurn(initial: UserMessage[]): Promise<TurnEndReason> {
    await this.runModelStep('plan', initial, false)
    let decision: ReflectionDecision = 'continue'
    while (decision !== 'finish') {
      if (this.turnUsage.cycles >= this.config.maxCycles) break
      this.turnUsage.cycles++
      this.metrics.cycles++
      this.inbox.append('next-step', pluginMessage(`Begin ACT cycle ${this.metrics.cycles} from the plan above.`))
      const act = await this.runModelStep('act', this.inbox.claim('next-step', this.currentTurn()), true)
      if (act.finish === 'max-tokens') break
      const tools = await this.executeActTools(act.toolCalls)
      if (tools.concluded) return { kind: 'completed' }

      this.inbox.append('next-step', pluginMessage('Reflect on the latest evidence and choose continue, replan, or finish.'))
      decision = await this.reflectWithRetry()
      if (decision === 'replan') {
        this.inbox.append('next-step', pluginMessage('Re-plan using the evidence and reflection already recorded.'))
        await this.runModelStep('plan', this.inbox.claim('next-step', this.currentTurn()), false)
        decision = 'continue'
      }
    }
    this.inbox.append('next-step', pluginMessage('Finalize the answer for the user.'))
    const final = await this.runModelStep('finalize', this.inbox.claim('next-step', this.currentTurn()), false)
    return final.finish === 'max-tokens' ? { kind: 'max-tokens' } : { kind: 'completed' }
  }

  private async reflectWithRetry(): Promise<ReflectionDecision> {
    for (let attempt = 0; attempt <= this.config.maxRetriesPerPhase; attempt++) {
      const reflected = await this.runModelStep('reflect', this.inbox.claim('next-step', this.currentTurn()), false)
      const decision = parseReflection(reflected.message)
      if (decision !== undefined) return decision
      if (attempt < this.config.maxRetriesPerPhase) {
        this.metrics.retries++
        this.inbox.append('next-step', pluginMessage('The reflection was invalid. Return only the required JSON object.'))
      }
    }
    throw new Error('full custom loop reflection did not match its JSON contract')
  }

  private currentTurn(): number {
    if (this.phase.kind !== 'running') throw new Error('full custom loop has no active turn')
    return this.phase.turn
  }

  private currentSignal(): AbortSignal {
    if (this.phase.kind === 'idle') throw new Error('full custom loop has no active signal')
    return this.phase.abort.signal
  }

  private assertModelBudget(phase: FullLoopPhase): void {
    if (this.turnUsage.modelCalls >= this.modelCallLimit) {
      throw new FullLoopBudgetError(`full custom loop exhausted maxModelCalls=${this.modelCallLimit} before ${phase}`)
    }
  }

  private async runModelStep(
    phase: Exclude<FullLoopPhase, 'idle' | 'maintenance'>,
    messages: UserMessage[],
    exposeTools: boolean,
  ): Promise<ModelStepResult> {
    this.assertModelBudget(phase)
    if (this.phase.kind !== 'running') throw new Error('full custom loop step outside running phase')
    const running = this.phase
    const signal = running.abort.signal
    signal.throwIfAborted()
    const step = running.step + 1
    const started = performance.now()
    this.metrics.phase = phase
    this.trace.append({ event: 'phase-start', turn: running.turn, step, phase })

    const assembly = await this.loopCtx.systemPrompt.assemble(assembleContextFor(this, signal))
    const sections = renderContextSections(assembly)
    const context = this.runtimeContext.project(joinContextSections(sections), sections)
    const proposed = context === undefined ? messages : [...messages, context]
    const decision = await this.dispatch.waterfall(
      'agent/pre-step',
      { messages: proposed, turn: running.turn, step, signal },
      (): Promise<PreStepDecision> => Promise.resolve({ kind: 'enter', messages: proposed }),
    )
    signal.throwIfAborted()
    if (decision.kind === 'reject') throw new FullLoopStepRejected(`full custom loop ${phase} step was rejected`)

    this.session.append('step/start', { turn: running.turn, step })
    running.step = step
    try {
      for (const message of decision.messages) {
        this.session.append('user/message', message, { surfaceOp: 'append' })
      }
      const result = await this.callModel(phase, assembly, exposeTools)
      if (!exposeTools && result.toolCalls.length > 0) {
        await this.settleDisallowedToolCalls(result.toolCalls, `tools are disabled during ${phase}`)
        throw new Error(`full custom loop model requested tools during ${phase}`)
      }
      return result
    } finally {
      this.session.append('step/end', { turn: running.turn, step })
      this.trace.append({
        event: 'phase-end',
        turn: running.turn,
        step,
        phase,
        durationMs: Math.round(performance.now() - started),
      })
    }
  }

  private async callModel(
    phase: Exclude<FullLoopPhase, 'idle' | 'maintenance'>,
    assembly: PromptAssembly,
    exposeTools: boolean,
  ): Promise<ModelStepResult> {
    if (this.phase.kind !== 'running') throw new Error('full custom loop request outside running phase')
    const { turn, step } = this.phase
    const signal = this.phase.abort.signal
    const baseSystem = renderPrompt(assembly)
    const system = `${baseSystem}${baseSystem ? '\n\n' : ''}${phaseInstruction(phase)}`
    const tools = exposeTools ? assembly.tools : []

    while (true) {
      this.assertModelBudget(phase)
      this.metrics.modelCalls++
      this.turnUsage.modelCalls++
      const { request, preparedCall } = await this.buildRequest(phase, tools, system, signal)
      const assembler = new BlockAssembler()
      const chunkSeqs: number[] = []
      const stream = preparedCall?.stream(request) ?? this.loopCtx.llm.stream(request)
      for await (const chunk of stream) {
        signal.throwIfAborted()
        chunkSeqs.push(this.session.append('assistant/chunk', { turn, step, chunk }).seq)
        assembler.push(chunk)
      }
      signal.throwIfAborted()
      const finish = assembler.finish
      if (finish.kind === 'error' || finish.kind === 'aborted') {
        const action = await this.dispatch.waterfall(
          'agent/request-error',
          {
            turn,
            step,
            provider: request.provider,
            failure: finish.failure,
            retryPolicy: preparedCall?.retryPolicy,
            signal,
          },
          () => Promise.resolve<RequestErrorAction>(undefined),
        )
        signal.throwIfAborted()
        if (action?.kind !== 'retry') throw new LlmError(finish.failure.message, finish.failure.code, finish.failure)
        this.metrics.retries++
        continue
      }
      const message = createAssistantMessage({
        content: assembler.blocks(),
        source: {
          provider: request.provider,
          model: request.model,
          ...assembler.replayState === undefined ? {} : { replayState: assembler.replayState },
        },
      })
      this.session.append('assistant/message', {
        turn,
        step,
        message,
        ...assembler.usage === undefined ? {} : { usage: assembler.usage },
      }, { surfaceOp: 'append', sourceEventSeqs: chunkSeqs })
      this.trace.append({
        event: 'model-call',
        turn,
        step,
        phase,
        provider: request.provider,
        model: request.model,
        outcome: finish.kind,
      })
      return {
        message,
        finish: finish.kind === 'max-tokens' ? 'max-tokens' : 'completed',
        toolCalls: message.content.filter((block): block is ToolCallBlock => block.type === 'tool-call'),
      }
    }
  }

  private async buildRequest(
    phase: Exclude<FullLoopPhase, 'idle' | 'maintenance'>,
    tools: GenerateOptions['tools'] & object,
    system: string,
    signal: AbortSignal,
  ): Promise<{ request: GenerateOptions; preparedCall?: PreparedLlmCall }> {
    if (this.phase.kind !== 'running') throw new Error('full custom loop request outside running phase')
    const persisted = this.session.requestHeader()?.config
    const provider = this.options.provider ?? persisted?.provider ?? ''
    const model = this.options.model ?? persisted?.model ?? ''
    const phaseMaxTokens = phase === 'plan' || phase === 'reflect'
      ? Math.min(this.options.maxTokens ?? this.config.planMaxTokens, this.config.planMaxTokens)
      : this.options.maxTokens
    const proposed = await this.dispatch.waterfall(
      'agent/request',
      { turn: this.phase.turn, step: this.phase.step, signal },
      () => Promise.resolve<LlmCallConfig>(deepFreeze({
        provider,
        model,
        ...phaseMaxTokens === undefined ? {} : { maxTokens: phaseMaxTokens },
      })),
    )
    signal.throwIfAborted()
    if (!proposed.provider || !proposed.model) {
      throw new Error(`full custom loop agent "${this.id}" has no provider/model`)
    }
    let config: LlmCallConfig
    let preparedCall: PreparedLlmCall | undefined
    try {
      preparedCall = await this.loopCtx.llm.prepareCall(proposed, signal)
      config = preparedCall.config
    } catch (error: unknown) {
      if (!(error instanceof LlmError) || error.code !== 'NO_ADAPTER') throw error
      config = proposed
    }
    const header = canonicalHeader({
      config,
      ...preparedCall === undefined ? {} : { adapterDefaults: preparedCall.adapterDefaults },
      ...(system ? { system } : {}),
      ...(tools.length > 0 ? { tools } : {}),
    })
    const baseline = this.session.requestHeader()
    if (!this.requestHeaderLogged) {
      this.session.append('request/header', { header, reason: baseline === undefined ? 'initial' : 'resume' })
      this.requestHeaderLogged = true
    } else if (baseline === undefined || !headerEquals(baseline, header)) {
      this.session.append('request/header', { header, reason: 'change' })
    }
    const requestContext: RequestContext = {
      provider: config.provider,
      model: config.model,
      ...preparedCall?.context?.contextWindow === undefined
        ? {}
        : { contextWindow: preparedCall.context.contextWindow },
    }
    const previous = this.session.requestContext()
    if (previous?.provider !== requestContext.provider
      || previous.model !== requestContext.model
      || previous.contextWindow !== requestContext.contextWindow) {
      this.session.append('request/context', requestContext)
    }
    const request = markAgentLoopRequest(deepFreeze({
      ...header.config,
      messages: this.session.deriveMessages() as Message[],
      ...header.system === undefined ? {} : { system: header.system },
      ...header.tools === undefined ? {} : { tools: header.tools },
      sessionId: this.session.id,
      signal,
    }))
    return { request, ...preparedCall === undefined ? {} : { preparedCall } }
  }

  private async executeActTools(toolCalls: ToolCallBlock[]): Promise<ToolBatchResult> {
    if (toolCalls.length === 0) return { concluded: false }
    if (this.turnUsage.toolCalls >= this.toolCallLimit) {
      await this.settleDisallowedToolCalls(toolCalls, `maxToolCalls=${this.toolCallLimit} exhausted`)
      throw new FullLoopBudgetError(`full custom loop exhausted maxToolCalls=${this.toolCallLimit}`)
    }
    const [first, ...rest] = toolCalls
    if (first === undefined) return { concluded: false }
    const result = await this.executeTool(first)
    if (rest.length > 0) await this.settleDisallowedToolCalls(rest, 'full custom loop executes one tool per ACT cycle')
    return { concluded: result.concludesTurn === true }
  }

  private async executeTool(block: ToolCallBlock): Promise<ToolExecutionResult> {
    if (this.phase.kind !== 'running') throw new Error('full custom loop tool outside running phase')
    const { turn, step } = this.phase
    const signal = this.phase.abort.signal
    const callEvent = this.session.append('tool/call', {
      turn,
      step,
      callId: block.id,
      name: block.name,
      arguments: block.arguments,
    })
    this.metrics.toolCalls++
    this.turnUsage.toolCalls++
    this.trace.append({ event: 'tool-start', turn, step, phase: 'act', tool: block.name })
    const result = await this.loopCtx.tools.execute({
      callId: block.id,
      name: block.name,
      arguments: parseArguments(block.arguments),
      agent: this,
      signal,
    })
    this.appendToolResult(block, result, callEvent.seq)
    for (const context of result.additionalContexts ?? []) this.inbox.append('next-step', context)
    this.trace.append({
      event: 'tool-end',
      turn,
      step,
      phase: 'act',
      tool: block.name,
      outcome: result.isError ? 'error' : 'completed',
    })
    return result
  }

  private async settleDisallowedToolCalls(calls: ToolCallBlock[], reason: string): Promise<void> {
    if (this.phase.kind !== 'running') throw new Error('full custom loop synthetic tool result outside running phase')
    for (const block of calls) {
      const callEvent = this.session.append('tool/call', {
        turn: this.phase.turn,
        step: this.phase.step,
        callId: block.id,
        name: block.name,
        arguments: block.arguments,
      })
      this.appendToolResult(block, {
        isError: true,
        error: {
          message: reason,
          info: { name: 'FullCustomLoopSkippedTool', code: 'FULL_CUSTOM_LOOP_SKIPPED' },
        },
        content: [{ type: 'text', text: `Error: ${reason}` }],
      }, callEvent.seq)
    }
  }

  private appendToolResult(block: ToolCallBlock, result: ToolExecutionResult, callSeq: number): void {
    if (this.phase.kind !== 'running') throw new Error('full custom loop tool result outside running phase')
    const message = createToolResultMessage({
      callId: block.id,
      content: result.content,
      isError: result.isError,
    })
    this.session.append('tool/result', {
      turn: this.phase.turn,
      step: this.phase.step,
      message,
      ...result.error?.info === undefined ? {} : { error: result.error.info },
      ...result.meta === undefined ? {} : { meta: result.meta },
    }, { surfaceOp: 'append', sourceEventSeqs: [callSeq] })
  }
}
