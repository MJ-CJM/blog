import { appendFileSync, mkdirSync } from 'node:fs'
import { join } from 'node:path'

import type { TraceEvent } from './types.js'

/** Best-effort, prompt-free observability. Session Log remains authoritative. */
export class FullLoopTraceStore {
  private readonly directory: string
  private readonly path: string

  constructor(root: string, private readonly sessionId: string) {
    this.directory = join(root, encodeURIComponent(sessionId))
    this.path = join(this.directory, 'loop-trace.jsonl')
  }

  append(event: Omit<TraceEvent, 'at' | 'sessionId'>): void {
    try {
      mkdirSync(this.directory, { recursive: true, mode: 0o700 })
      appendFileSync(this.path, `${JSON.stringify({
        at: new Date().toISOString(),
        sessionId: this.sessionId,
        ...event,
      })}\n`, { encoding: 'utf8', mode: 0o600 })
    } catch {
      // Trace is diagnostic only and cannot change an Agent outcome.
    }
  }

  get filePath(): string {
    return this.path
  }
}
