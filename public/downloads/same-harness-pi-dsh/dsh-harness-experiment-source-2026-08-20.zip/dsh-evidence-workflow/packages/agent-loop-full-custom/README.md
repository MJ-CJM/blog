# DSH Full Custom Loop 能力边界探针

这个包不是为了做一个“更聪明”的 Agent，而是为了回答一个更具体的问题：

> 不导入、不继承官方 `@deepseek-ai/dsh-agent-loop` / `ReactLoopAgent` 时，第三方插件能否独立接管 DSH 的 Agent 执行循环；接管后，哪些 Harness 能力仍可组合，哪些行为必须重写，哪些地方还不是稳定插件接缝？

包名为 `@local/dsh-full-custom-loop`，实验算法为 `budgeted-plan-act-reflect/v1`。Stock 与现有 Adapter 均保留；它只在独立的 `egc-loop-full-custom` / `egc-web-full-custom` Profile 中启用。

## 边界结论

| 层 | 本实验如何处理 | 性质 |
| --- | --- | --- |
| `AgentFactory` / `Agent` | 完全由本包实现 | 已替换 |
| Inbox 驱动、Turn/Step 状态机 | 完全由本包实现 | 已替换 |
| Plan → Act → Reflect → Finalize | 本包自己的最小可观察算法 | 已替换 |
| 工具调度 | 本包严格串行，每个 Act 周期最多执行一个模型请求的工具 | 已替换 |
| 创建、Owner 绑定、取消、卸载 | 本包实现并通过生命周期测试 | 已替换 |
| Agent Registry、Scope | 使用 DSH 公共服务 | 复用 Harness |
| Session / Session Log | 使用 DSH 公共服务与标准事件 | 复用 Harness |
| LLM route、adapter、retry 扩展点 | 使用 DSH 公共服务 | 复用 Harness |
| System Prompt | 使用 DSH 公共服务 | 复用 Harness |
| Tool Registry、Guard、Approval、执行管线 | 使用公开 `ctx.tools.execute()`；不使用内部 scheduler | 复用 Harness |
| Web、Agent Preset、Dynamic Workflow、Subagent | 使用 DSH 现有能力 | 复用 Harness |
| `Inbox.claim()` | 根包可导入，但 rc.6 类型声明标记为 `@internal` | 唯一灰色接缝 |

本包没有 `@deepseek-ai/dsh-agent-loop` 依赖，也不导入 `ReactLoopAgent`、`TOOL_RUNTIME_SCHEDULER` 或官方私有 RuntimeContext/ownership 实现。静态 AST 测试会阻止这些依赖以后被悄悄加回。

因此，“完整重写 Loop”不等于重写整个 DSH。若连 Session、LLM、Tool、Web 也全部自己实现，实验验证的就不再是 DSH 的 Loop 可替换性，而是另造一个 Agent 框架。

## 可观察行为

- 根 Agent：Plan → Act → Reflect → Finalize。
- Dynamic Workflow 子 Agent：默认使用本包的 `direct-budgeted` 路径，避免 7 个子 Agent 各自再放大为四阶段调用。根 Agent 保持 `maxModelCalls=8` / `maxToolCalls=4`，子 Agent 使用独立的 `subagentMaxModelCalls=12` / `subagentMaxToolCalls=8`；这允许代码审查完成多次只读取证，但不会放宽根 Agent 的预算。
- 工具严格串行；不会调用官方内部并发调度器。
- `full_loop_diagnostics` 返回当前实现、算法、预算、计数、模型 route 和 trace 文件。
- Prompt 外的诊断 trace 写到：

  ```text
  /path/to/dsh-evidence-workflow/lab-home/full-custom-loop/<sessionId>/loop-trace.jsonl
  ```

Session Log 仍是事实源，trace 只是 best-effort 观测数据，不参与恢复或业务决策。

预算按 Agent 身份隔离，而不是按工具名特判。`full_loop_diagnostics.limits` 返回当前 Agent 实际生效的预算：根会话应看到 `8/4`，Dynamic Workflow 子会话应看到 `12/8`。模型、Provider 或工作流仍可能失败；提高预算不等于保证成功。

## 已知诚实边界

- rc.6 还没有稳定公开的 Inbox claim 接口；本包在 `package.json` 中显式声明 `experimentalSeams`，并固定测试它是唯一内部接缝。
- Resume 复用 DSH JSONL persistence 加载历史；无模型测试会销毁第一套 Context、在全新 Context 中恢复完整 Session Log，并验证下一条消息从新 Turn 的 Plan 重新开始。它仅承诺 Turn 边界重规划，不声称从 Plan/Act/Reflect 的调用栈中点继续。
- Full Custom Web 仍复用 DSH Web 与 Agent Preset；页面外观相似不代表仍使用官方 Loop。应以 Profile dump、`full_loop_diagnostics`、Session 事件和 trace 共同验真。
- 这是 developer-preview 边界实验，不是安全沙箱或生产级通用 Loop。

## 编译与无模型验证

```sh
cd /path/to/dsh-evidence-workflow
node -v
npx --yes pnpm@11.19.0 install
npx --yes pnpm@11.19.0 run check
```

只跑本包的边界测试：

```sh
npx --yes pnpm@11.19.0 exec vitest run tests/full-custom-loop.test.ts
```

只重建本包：

```sh
npx --yes pnpm@11.19.0 --filter @local/dsh-full-custom-loop run build
```

## Web 运行

```sh
cd /path/to/dsh-evidence-workflow
npx --yes pnpm@11.19.0 run build
npx --yes pnpm@11.19.0 run web:full-custom
```

打开终端最终打印的 `dsh web:` 地址，新建会话并确认 Agent Preset 为 `EGC Full Custom Loop 实验`。插件随 Profile 自动加载，不存在第二个“启动插件”命令。

先让 Agent 调用诊断工具：

```text
调用 full_loop_diagnostics，只报告 implementation、algorithm、inheritsOfficialAgentLoop、usesOfficialReactLoopAgent、toolScheduling、experimentalSeams、limits、currentTurnUsage 和 traceFile。
```

关键预期：

```text
implementation = @local/dsh-full-custom-loop
algorithm = budgeted-plan-act-reflect/v1
inheritsOfficialAgentLoop = false
usesOfficialReactLoopAgent = false
toolScheduling = strictly-serial
experimentalSeams = [@deepseek-ai/dsh-agent:Inbox.claim]
```

随后可在相同任务下比较 `web:stock`、`web:adapter`、`web:full-custom`。最终回答是否相似不是主要证据；真正的差异证据是 Factory 组合、阶段/模型调用、工具调度、取消行为、Session 事件与 trace。
