import type { Context } from '@deepseek-ai/cordis'
import Schema from '@deepseek-ai/schemastery'
import type { Agent } from '@deepseek-ai/dsh-agent'
import type { ContentBlock } from '@deepseek-ai/dsh-llm'
import type { SubagentRuntime } from '@deepseek-ai/dsh-subagent'
import { assertObjectJsonSchema, defineTool } from '@deepseek-ai/dsh-tools'

import {
  EvidenceGatedWorkflow,
  assertWorkflowSession,
  type AgentRunRequest,
  type AgentRunner,
  type WorkflowConfig,
  workflowToolDecision,
} from '@local/dsh-egc-core'

export const name = 'evidence-gated-change-workflow'
export const inject = ['tools', 'subagents']

export interface Config {
  runRoot: string
  fixtureRoot: string
  contractRoot: string
  runtimeRoot: string
  oracleScript: string
  provider: string
  maxTokens: number
  maxRepair: number
  verificationCommand: [string, ...string[]]
  verificationTimeoutMs: number
  maxCapturedOutputBytes: number
}

export const Config: Schema<Config> = Schema.object({
  runRoot: Schema.string().required(),
  fixtureRoot: Schema.string().required(),
  contractRoot: Schema.string().required(),
  runtimeRoot: Schema.string().required(),
  oracleScript: Schema.string().required(),
  provider: Schema.string().default('spawn'),
  maxTokens: Schema.number().default(4096),
  maxRepair: Schema.number().default(1),
  verificationCommand: Schema.array(Schema.string()).default(['node', '--experimental-strip-types', 'test/TodoService.test.ts']),
  verificationTimeoutMs: Schema.number().default(30_000),
  maxCapturedOutputBytes: Schema.number().default(131_072),
}) as Schema<Config>

/** Adapt the public DSH subagent seam to the harness-independent workflow runner. */
export class DshSubagentRunner implements AgentRunner {
  constructor(
    private readonly ctx: Context,
    private readonly parent: Agent,
    private readonly provider: string,
    private readonly maxTokens: number,
  ) {}

  async run(request: AgentRunRequest, signal: AbortSignal): Promise<unknown> {
    const transportSchema = toDshTransportSchema(request.outputSchema)
    assertObjectJsonSchema(transportSchema)
    const subagents = (this.ctx as Context & { subagents: SubagentRuntime }).subagents
    const run = await subagents.start(this.provider, {
      label: request.label,
      prompt: [{ type: 'text', text: request.prompt }],
      parent: this.parent,
      signal,
      agentOptions: { maxTokens: this.maxTokens },
      outputSchema: transportSchema,
      toolFilter: { allow: request.toolNames },
      persona: request.persona,
    })
    try {
      const result = await run.result
      if (result.stopReason !== 'completed') {
        throw new Error(`${request.role} stopped with ${result.stopReason}`)
      }
      if (result.structured !== undefined) return result.structured
      return parseJsonOutput(result.output, request.role)
    } finally {
      await run.dispose()
    }
  }
}

/** Register the fixed, approval-gated workflow tool. */
export function apply(ctx: Context, config: Config): void {
  const workflowConfig: WorkflowConfig = {
    runRoot: config.runRoot,
    fixtureRoot: config.fixtureRoot,
    contractRoot: config.contractRoot,
    runtimeRoot: config.runtimeRoot,
    oracleScript: config.oracleScript,
    maxRepair: config.maxRepair,
    verificationCommand: config.verificationCommand,
    verificationTimeoutMs: config.verificationTimeoutMs,
    maxCapturedOutputBytes: config.maxCapturedOutputBytes,
  }
  const workflow = new EvidenceGatedWorkflow(workflowConfig)
  ctx.tools.guard(execution => workflowToolDecision(config.runRoot, execution))

  ctx.tools.register(defineTool({
    name: 'evidence_gated_change',
    description: 'Plan, execute, or inspect the fixed TodoService requestId workflow. Planning stops for external human approval; this tool cannot approve its own plan.',
    parameters: {
      action: {
        type: 'string',
        enum: ['plan', 'execute', 'status'],
        required: true,
        description: 'plan uses a run prepared by the external prepare-run command; execute requires approval.json; status is read-only.',
      },
      runId: {
        type: 'string',
        required: true,
        description: 'Stable lowercase run id matching /^[a-z0-9][a-z0-9_-]{0,63}$/.',
      },
    },
    output: {
      schema: {
        type: 'object',
        additionalProperties: false,
        properties: {
          runId: { type: 'string', required: true },
          stage: { type: 'string', required: true },
          repairs: { type: 'integer', required: true },
          planHash: { type: 'string' },
          approvalHash: { type: 'string' },
          artifacts: { type: 'array', items: { type: 'string' }, required: true },
          message: { type: 'string', required: true },
        },
      },
      render: (_args, value) => [{
        type: 'text',
        text: [
          `Evidence-gated run ${value.runId}: ${value.stage}`,
          value.planHash === undefined ? undefined : `Plan hash: ${value.planHash}`,
          value.approvalHash === undefined ? undefined : `Approval hash: ${value.approvalHash}`,
          value.message,
          `Artifacts: ${value.artifacts.join(', ')}`,
        ].filter((line): line is string => line !== undefined).join('\n'),
      }],
    },
    isConcurrencySafe: () => false,
    async execute(args, exec) {
      exec.signal.throwIfAborted()
      if (exec.agent === undefined) throw new Error('evidence_gated_change requires an initiating Agent')
      assertWorkflowSession(config.runRoot, args.runId, exec.agent)
      const runner = new DshSubagentRunner(ctx, exec.agent, config.provider, config.maxTokens)
      const summary = args.action === 'plan'
        ? await workflow.plan(args.runId, runner, exec.signal)
        : args.action === 'execute'
          ? await workflow.execute(args.runId, runner, exec.signal)
          : await workflow.status(args.runId)
      return {
        runId: summary.runId,
        stage: summary.stage,
        repairs: summary.repairs,
        artifacts: [...summary.artifacts],
        message: summary.message,
        ...(summary.planHash === undefined ? {} : { planHash: summary.planHash }),
        ...(summary.approvalHash === undefined ? {} : { approvalHash: summary.approvalHash }),
      }
    },
    presentCall: args => ({
      card: 'generic',
      title: `Evidence-gated change: ${args.action}`,
      kind: args.action === 'status' ? 'read' : 'other',
      rawInput: args.runId,
    }),
    presentResult: (_args, result) => ({
      card: 'generic',
      title: result.isError ? 'Evidence-gated change failed' : 'Evidence-gated change updated',
      content: result.content,
    }),
  }))
}

const TRANSPORT_KEYS = new Set([
  'type',
  'oneOf',
  'properties',
  'required',
  'additionalProperties',
  'items',
  'enum',
  'const',
  'description',
  'title',
  'default',
  'examples',
])

/** Project a full portable schema into rc.6's enforced transport subset. */
export function toDshTransportSchema(value: unknown): Record<string, unknown> {
  if (value === null || typeof value !== 'object' || Array.isArray(value)) throw new Error('schema must be an object')
  return sanitizeSchemaNode(value as Record<string, unknown>)
}

function sanitizeSchemaNode(node: Record<string, unknown>): Record<string, unknown> {
  const output: Record<string, unknown> = {}
  for (const [key, value] of Object.entries(node)) {
    if (!TRANSPORT_KEYS.has(key)) continue
    if (key === 'properties' && value !== null && typeof value === 'object' && !Array.isArray(value)) {
      output.properties = Object.fromEntries(Object.entries(value as Record<string, unknown>).map(([name, child]) => {
        if (child === null || typeof child !== 'object' || Array.isArray(child)) throw new Error(`schema property ${name} must be an object`)
        return [name, sanitizeSchemaNode(child as Record<string, unknown>)]
      }))
    } else if (key === 'items' && value !== null && typeof value === 'object' && !Array.isArray(value)) {
      output.items = sanitizeSchemaNode(value as Record<string, unknown>)
    } else if (key === 'oneOf' && Array.isArray(value)) {
      output.oneOf = value.map((child, index) => {
        if (child === null || typeof child !== 'object' || Array.isArray(child)) throw new Error(`schema oneOf[${index}] must be an object`)
        return sanitizeSchemaNode(child as Record<string, unknown>)
      })
    } else {
      output[key] = value
    }
  }
  return output
}

function parseJsonOutput(output: readonly ContentBlock[], role: string): unknown {
  const text = output
    .filter((block): block is Extract<ContentBlock, { type: 'text' }> => block.type === 'text')
    .map(block => block.text)
    .join('\n')
    .trim()
  const fenced = /^```(?:json)?\s*([\s\S]*?)\s*```$/i.exec(text)
  try {
    return JSON.parse(fenced?.[1] ?? text) as unknown
  } catch (error) {
    throw new Error(`${role} returned neither structured output nor valid JSON`, { cause: error })
  }
}
