# DSH Evidence-Gated Change workflow plugin

This Bundle registers the fixed `evidence_gated_change` tool and isolates the filesystem Skill provider to this lab's portable `skills/` directory. The model-facing root may load that one Skill and call the fixed tool; the global guard rejects its other tools inside `runs/<runId>/workspace`.

An external `prepare-run` command first creates the workspace and captures the baseline. `plan` then runs Code Scout and Test Scout concurrently through the public rc.6 `ctx.subagents.start()` API and stops at `awaiting_approval`. `execute` requires a schema-valid `approval.json`, runs Implementer, and fans out Reviewer plus the fixed verifier, with at most one Repair. `status` is read-only. All three actions require the initiating Agent cwd to be exactly the prepared run workspace so rc.6 child Agents inherit the intended sandbox root.

Approval is deliberately absent from the model-facing tool. After reviewing the plan and four bound hashes, run `pnpm approve -- <runId> <approvalHash>` from the lab root. The token is the canonical hash over the plan, baseline, portable contract, and runtime adapter; a `planHash` is not accepted.

The plugin's artifacts are an experiment-local durable journal, not custom DSH Session events. Tool calls/results still traverse DSH's normal logged tool pipeline. The global guard, exact-path child mutation policy, and Node 25 verifier restrictions are defense in depth, not an OS sandbox or proof of human identity.
