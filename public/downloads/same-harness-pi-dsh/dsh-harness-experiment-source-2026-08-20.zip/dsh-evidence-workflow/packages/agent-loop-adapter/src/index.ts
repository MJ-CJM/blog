import { appendFileSync } from 'node:fs'
import { join, resolve } from 'node:path'

import Schema from '@deepseek-ai/schemastery'
import AgentLoop, { type Config as BaseAgentLoopConfig } from '@deepseek-ai/dsh-agent-loop'
import type { ToolExecution, ToolExecutionResult, ToolGuard } from '@deepseek-ai/dsh-tools'

import { trustedRunIdentity, workflowToolDecision } from '@local/dsh-egc-core'

// These types deliberately derive from the exact AgentLoop runtime module.
// DSH scope identity is module-local in rc.6, so an external AgentFactory must
// use the same physical AgentLoop package as the host instead of a second pnpm
// copy whose private scope symbol cannot be read by Web Agent Presets.
type RuntimeContext = ConstructorParameters<typeof AgentLoop>[0]
type RuntimeCreateAgentOptions = Parameters<AgentLoop['createAgent']>[1]
type RuntimeResumeAgentOptions = Parameters<AgentLoop['resume']>[1]
type RuntimeAgentSetup = NonNullable<RuntimeCreateAgentOptions['setup']>
type RuntimeAgentHandlePromise = ReturnType<AgentLoop['createAgent']>

export interface Config extends BaseAgentLoopConfig {
  runRoot: string
  mutationTools: string[]
}

export const Config: Schema<Config> = Schema.object({
  maxParallelToolCalls: Schema.number().default(10),
  agents: Schema.array(Schema.object({
    id: Schema.string().required(),
    sessionId: Schema.string(),
    provider: Schema.string(),
    model: Schema.string(),
    maxTokens: Schema.number(),
    cwd: Schema.string(),
    resumeSessionId: Schema.string(),
  })).default([]),
  runRoot: Schema.string().required(),
  mutationTools: Schema.array(Schema.string()).default(['write', 'edit']),
}) as Schema<Config>

interface SupervisorConfig {
  readonly runRoot: string
}

const installedContexts = new WeakSet<RuntimeContext>()

/** Validate adapter-only invariants before the inherited constructor can create agents. */
export function assertAdapterConfig(config: Config): Config {
  if (config.agents.length !== 0) {
    throw new Error('workflow-aware AgentLoop requires config.agents to be empty; declarative creation bypasses createAgent/resume composition')
  }
  if (!config.runRoot.startsWith('/')) throw new Error('runRoot must be absolute')
  if ([...config.mutationTools].sort().join(',') !== 'edit,write') {
    throw new Error('the fixed adapter mutationTools must be exactly write and edit')
  }
  return config
}

/** Preserve the caller's unpublished setup commit while adding the supervisor afterward. */
export function composeSetup(prior: RuntimeAgentSetup | undefined, install: (agentCtx: RuntimeContext) => void): RuntimeAgentSetup {
  return async (agentCtx) => {
    const priorCommit = await prior?.(agentCtx)
    install(agentCtx)
    return priorCommit
  }
}

/** Whether the adapter installed its supervisor into this exact Agent context. */
export function isSupervisorInstalled(agentCtx: RuntimeContext): boolean {
  return installedContexts.has(agentCtx)
}

/** Build the synchronous fail-closed workflow guard used in every adapted Agent scope. */
export function createApprovalGuard(config: SupervisorConfig): ToolGuard {
  return execution => workflowToolDecision(config.runRoot, execution)
}

/** Public AgentLoop subclass that changes composition, not the private loop algorithm. */
export class WorkflowAwareAgentLoop extends AgentLoop {
  static inject = AgentLoop.inject
  static Config = Config as unknown as typeof AgentLoop.Config

  private readonly supervisorConfig: SupervisorConfig

  constructor(ctx: RuntimeContext, config: Config) {
    super(ctx, assertAdapterConfig(config))
    this.supervisorConfig = { runRoot: resolve(config.runRoot) }
  }

  /** rc.6 exposes this legacy direct path, but it publishes before our public factory wrappers can compose setup. */
  override create(..._args: Parameters<AgentLoop['create']>): ReturnType<AgentLoop['create']> {
    throw new Error('workflow-aware adapter requires ctx.agents.create/resume; direct ctx.agentLoop.create is unsupported')
  }

  override createAgent(ownerCtx: RuntimeContext, options: RuntimeCreateAgentOptions): RuntimeAgentHandlePromise {
    return super.createAgent(ownerCtx, {
      ...options,
      setup: composeSetup(options.setup, agentCtx => this.installSupervisor(agentCtx)),
    })
  }

  override resume(ownerCtx: RuntimeContext, options: RuntimeResumeAgentOptions): ReturnType<AgentLoop['resume']> {
    return super.resume(ownerCtx, {
      ...options,
      setup: composeSetup(options.setup, agentCtx => this.installSupervisor(agentCtx)),
    })
  }

  private installSupervisor(agentCtx: RuntimeContext): void {
    const scoped = agentCtx as unknown as {
      tools: { guard(guard: ToolGuard): unknown }
      on(
        event: 'tools/result',
        listener: (execution: Readonly<ToolExecution>, result: Readonly<ToolExecutionResult>) => void,
      ): unknown
    }
    scoped.tools.guard(createApprovalGuard(this.supervisorConfig))
    scoped.on('tools/result', (execution, result) => {
      this.recordToolReceipt(execution, result)
    })
    installedContexts.add(agentCtx)
  }

  private recordToolReceipt(execution: Readonly<ToolExecution>, result: Readonly<ToolExecutionResult>): void {
    const identity = trustedRunIdentity(this.supervisorConfig.runRoot, execution.agent)
    if (identity === undefined) return
    try {
      appendFileSync(join(this.supervisorConfig.runRoot, identity.runId, 'loop-receipts.jsonl'), `${JSON.stringify({
        at: new Date().toISOString(),
        runId: identity.runId,
        origin: identity.origin,
        agentId: execution.agent?.id,
        callId: execution.callId,
        name: execution.name,
        isError: result.isError,
      })}\n`, { encoding: 'utf8', mode: 0o600 })
    } catch {
      // Receipt observation is best-effort and never changes an already settled tool result.
    }
  }
}

export default WorkflowAwareAgentLoop
