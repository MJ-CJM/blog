# Evidence-Gated Change: DeepSeek Harness implementation

[中文运行与验收手册](./RUNBOOK.zh-CN.md)

[Full Custom Loop 能力边界说明](./packages/agent-loop-full-custom/README.md)

This isolated lab implements the same Skill/Agent-driven `TodoService` workflow as the Pi comparison. It does not modify `/path/to/deepseek-harness`, `/path/to/dsh-runtime`, existing user Profiles, community plugins, or the earlier Boundary Probe.

## Implemented surfaces

- `@local/dsh-egc-core` is a no-model, file-backed state machine: parallel Code/Test Scouts, a canonical plan, a four-hash approval token, bounded implementation, concurrent review/verification, and at most one Repair.
- `@local/dsh-egc-workflow` is an ordinary Cordis Bundle. Its fixed `evidence_gated_change` tool uses only the public rc.6 `ctx.subagents.start()` API. A global tool guard lets the root Agent load this lab's one isolated Skill and call the workflow tool, but denies its shell, write, generic subagent, workflow, jobs, and other tools inside a prepared run.
- `@local/dsh-egc-agent-loop` is a separate Profile experiment. It subclasses the public rc.6 `AgentLoop`, composes the same supervisor into `createAgent()` and `resume()`, rejects declarative agents before `super()`, and fails loudly on the public direct `create()` bypass. It reuses the official driver.
- `@local/dsh-full-custom-loop` is the third, independent boundary experiment. It implements `AgentFactory` and `Agent` directly, never imports or inherits the official AgentLoop/ReactLoopAgent, owns a minimal budgeted Plan–Act–Reflect driver, and dispatches tools strictly serially through the public Tool Runtime. It deliberately continues to reuse DSH Agent Registry, Scope, Session Log, LLM, System Prompt, Tool policy/approval, Web, Subagent, and Dynamic Workflow services. Its sole explicitly declared rc.6 gray seam is root-exported but `@internal` `Inbox.claim()`.
- `@local/dsh-dynamic-workflow` is a saved-workflow loader and profile-policy wrapper. Its `profiled_dynamic_workflow` tool accepts only an allowlisted workflow name plus task, resolves the logical `fast`, `deep`, and `review` profiles, and delegates the unchanged body to the one official rc.6 `ctx.workflowEngine`. It does not implement or replace a DAG engine. Its DSH-only facade returns resolved routes, phase/run timing, observed retry counts, and per-child outcomes, then validates the final Top-3 with a full Ajv JSON Schema.
- `egc-stock` keeps the official AgentLoop; `egc-loop-adapter` inserts the inheriting adapter; `egc-loop-full-custom` disables both earlier implementations and enables exactly one independent Factory. All three Profiles load the portable `evidence-gated-change` Skill through an isolated `dsh-skill-filesystem` root.
- `egc-web-stock`, `egc-web-adapter`, and `egc-web-full-custom` add isolated Web surfaces. Their Agent Presets mount only this lab's two Skills and two allowlisted tools; the workflow engine stays in the Agent plane rather than leaking into the Web Host plane. There is no separate plugin-start command after Web starts.
- `contract/`, `agents/`, `skills/evidence-gated-change/`, and `fixtures/todo-service/` are byte-identical to the Pi v2 experiment. Their portable aggregate SHA-256 is `4285706cc55f6c2065552c9a727a472181caa36c7d2e5ef1efb7cfb024421e87`.
- `dynamic-workflow/shared/` is byte-identical to the Pi saved-workflow tree. Its manifest aggregate is `db61f13dca3a75662261dd72f21d603c4c85d79bc1b85ddd8baaf6f2cb3f9776`; the workflow file SHA-256 is `03f7a6ae63a3f0b17060e03cf2fa7f972a564a77691a099d992b65b6695edada`. The script uses only the shared native hook subset: `agent`, `parallel`, `pipeline`, `phase`, `log`, and `args`.

## Keyless verification

Node 25 or newer is required. The verifier fails closed on older Node releases because only Node 25 exposes the permission scope needed to deny network access as well as filesystem writes, child processes, and workers.

```sh
cd /path/to/dsh-evidence-workflow
node -v
npx --yes pnpm@11.19.0 install
npx --yes pnpm@11.19.0 run check
```

`pnpm run check` builds all five packages, runs no-model tests, and asks the pinned rc.6 CLI to dump and assert all six Headless/Web × Stock/Adapter/Full-Custom Profile compositions. The tests also load both Skills through the real rc.6 filesystem provider, pass a sanitized transport schema to rc.6 while enforcing the full shared schema with AJV, exercise the three-command verifier, prove named filesystem/child-process/network denials, execute the saved script on the real rc.6 worker-thread WorkflowEngine with a fake public Subagent provider, and drive the independent Loop through real public DSH services with a local fake LLM. No external model request or credential is used.

The bundled `pnpm` launcher may print that its own runtime is Node 24 even when `node -v` and the spawned tests use Node 25. The acceptance check is the runtime seen by `node`/Vitest; verifier tests fail closed below 25.

## Web validation

The Web profiles are isolated under this lab's `lab-home`; they do not change the user's existing `/path/to/.dsh/profiles/web` profile. Build once, then start Stock Web:

```sh
cd /path/to/dsh-evidence-workflow
npx --yes pnpm@11.19.0 install
npx --yes pnpm@11.19.0 run build
npx --yes pnpm@11.19.0 run web:stock
```

Open the final `dsh web:` URL printed by the terminal, normally <http://127.0.0.1:3080>. A new conversation should use the user preset named `EGC Web 实验`. Its Skill list contains exactly `evidence-gated-change` and `profiled-dynamic-workflow`; the two local tools are mounted automatically when that conversation is created.

For the saved-workflow experiment, ask the Web Agent:

```text
加载 profiled-dynamic-workflow Skill，然后调用 profiled_dynamic_workflow，workflow 使用 multi-model-review，task 使用：“只审查 packages/dynamic-workflow/src/index.ts，严格输出三个最值得优先修复的架构风险，每项包含 file:line、失败场景、排序理由和修复建议，最终用中文。”最后完整报告 runId、agentsStarted、profiles、resolvedRoutes、timings、retryCount、retryTelemetryComplete、routeTelemetryComplete、agentOutcomes、outcomeTelemetryComplete 和 result。
```

A successful real-model run returns a normal tool card, an execution receipt, and a schema-validated JSON result. The happy path starts 7 children; a degraded but still multi-route path can start 6 when one Pro-profile independent review fails, while losing the only Flash review fails the run instead of misreporting a single-model result as multi-model. The `findings` array is exactly three items and every item has the four required evidence fields. The allowlisted wrapper intentionally does not expose the official raw-JavaScript `workflow` tool. It also does not yet emit the official `tool-workflow/*` recorder events, so the Web UI shows the normal tool state and final result rather than a dedicated workflow progress graph.

Stop Stock with `Ctrl+C`. To validate the AgentLoop replacement with the same Web experience, start a fresh process:

```sh
npx --yes pnpm@11.19.0 run web:adapter
```

If both must run at once, give Adapter a different port: `npx --yes pnpm@11.19.0 run web:adapter -- --port 3081`. Do not bind this developer-preview server to an untrusted network. A real workflow run needs the provider credential in the launching shell; build, tests, page startup, blank-session creation, Skill discovery, and plugin mounting do not.

To validate a genuinely independent driver rather than the inheriting Adapter, stop the previous process and start:

```sh
npx --yes pnpm@11.19.0 run web:full-custom
```

Create a new session using `EGC Full Custom Loop 实验`, then ask it to call `full_loop_diagnostics`. The receipt must report `@local/dsh-full-custom-loop`, `budgeted-plan-act-reflect/v1`, `inheritsOfficialAgentLoop=false`, `usesOfficialReactLoopAgent=false`, and `toolScheduling=strictly-serial`. The prompt/answer can still look similar to Stock because the Web, model, Session, Tools, Skills, and Dynamic Workflow are intentionally shared; Profile composition, diagnostics, standard Session events, and `lab-home/full-custom-loop/<sessionId>/loop-trace.jsonl` are the proof of replacement.

## Profiled saved-workflow run

This experiment is independent of an EGC run. Start it from the lab root, not from `runs/<runId>/workspace`: the EGC guard intentionally denies every non-EGC orchestration tool inside an approval-gated workspace.

The platform-only catalog is `dynamic-workflow/dsh/model-profiles.json`. It currently maps `fast` to `deepseek-official/deepseek-v4-flash` and both `deep` and `review` to `deepseek-official/deepseek-v4-pro`: three logical profiles over two distinct real routes. Each profile may inherit a missing field from the parent route, or may contain only `provider` and/or `model`. Do not put credentials in this file. This experiment requires two distinct requested routes before execution, two distinct successful requested routes before synthesis, and two distinct final request routes observed in the successful independent child Sessions before returning. Missing actual-route evidence or runtime route collapse fails loudly. DSH rc.6 does not expose per-node `thinking`, `tools`, or `maxTokens` through its native WorkflowEngine, so those fields and every unknown field fail loudly.

```sh
cd /path/to/dsh-evidence-workflow
pnpm run build

export DSH_HOME=/path/to/dsh-evidence-workflow/lab-home
export DSH_AGENTS_HOME=/path/to/dsh-evidence-workflow/.agents
/path/to/dsh-runtime/node_modules/.bin/dsh --profile egc-stock \
  'Load the profiled-dynamic-workflow Skill, then call profiled_dynamic_workflow with workflow multi-model-review and task "Review the public API boundary of this harness". Report runId, agentsStarted, profiles, resolvedRoutes, timings, retryCount, retryTelemetryComplete, routeTelemetryComplete, agentOutcomes, outcomeTelemetryComplete, and result.'
```

To verify that the wrapper composes with the AgentLoop adapter too, start a separate process with the same cwd and request but use `--profile egc-loop-adapter`. The full happy path starts seven children (three independent reviews, three pipeline challenges, and one synthesis). The shared script still returns model text for Pi/DSH parity; the DSH facade supplies a final-only JSON instruction, rejects oversized synthesis text before parsing, and validates the document with `packages/dynamic-workflow/schemas/multi-model-review.schema.json` before returning the typed result. A real run requires provider credentials configured separately by the user; this lab never reads or copies them.

## Live stock-Loop run

The external preparation step must run first. Every DSH plan/status/execute session must then start with its cwd exactly equal to that run's `workspace`; rc.6 Subagents inherit the parent cwd and do not accept an independent cwd option.

```sh
cd /path/to/dsh-evidence-workflow
pnpm run build
pnpm prepare-run -- demo-stock-001

export DSH_HOME=/path/to/dsh-evidence-workflow/lab-home
export DSH_AGENTS_HOME=/path/to/dsh-evidence-workflow/.agents
cd /path/to/dsh-evidence-workflow/runs/demo-stock-001/workspace
/path/to/dsh-runtime/node_modules/.bin/dsh --profile egc-stock \
  'Load the evidence-gated-change Skill, then call evidence_gated_change with action plan and runId demo-stock-001. Stop after the tool returns.'
```

Back at the lab root, review the immutable inputs and copy the displayed `approvalHash` from the tool result or `state.json`. The approval command requires that exact token, not `planHash`:

```sh
cd /path/to/dsh-evidence-workflow
# Review runs/demo-stock-001/plan.json, baseline.json, state.json, and report.md.
DSH_EGC_APPROVAL_HASH='paste the approvalHash from state.json here'
pnpm approve -- demo-stock-001 "$DSH_EGC_APPROVAL_HASH"

cd /path/to/dsh-evidence-workflow/runs/demo-stock-001/workspace
/path/to/dsh-runtime/node_modules/.bin/dsh --profile egc-stock \
  'Load the evidence-gated-change Skill, then call evidence_gated_change with action execute and runId demo-stock-001. Report the final stage.'
```

The approval hash is canonical SHA-256 over `{planHash, baselineHash, contractHash, runtimeHash}`. Any plan, baseline, shared-contract, runtime-adapter, or pre-approval workspace drift is rejected. The `approvedBy` label recorded in the approval reason and event is only local audit text; it is not cryptographic human identity.

## Live AgentLoop-adapter run

Use a fresh run id and the adapter Profile; do not reuse the completed stock run.

```sh
cd /path/to/dsh-evidence-workflow
pnpm prepare-run -- demo-adapter-001

export DSH_HOME=/path/to/dsh-evidence-workflow/lab-home
export DSH_AGENTS_HOME=/path/to/dsh-evidence-workflow/.agents
cd /path/to/dsh-evidence-workflow/runs/demo-adapter-001/workspace
/path/to/dsh-runtime/node_modules/.bin/dsh --profile egc-loop-adapter \
  'Load the evidence-gated-change Skill, then call evidence_gated_change with action plan and runId demo-adapter-001. Stop after the tool returns.'
```

Review `demo-adapter-001`, set `DSH_EGC_APPROVAL_HASH` to the exact value in its `state.json`, and run `pnpm approve -- demo-adapter-001 "$DSH_EGC_APPROVAL_HASH"`. Then start a new DSH process from the same workspace and request `action execute` with `--profile egc-loop-adapter`.

Real headless model runs require a separately configured provider credential. This lab does not copy, install, or modify credentials.

## Evidence and boundaries

A completed run contains `events.jsonl`, `state.json`, `baseline.json`, both discovery receipts, `plan.json`, `approval.json`, `implementation.json`, `patch.diff`, `review.json`, `verification.json`, and `report.md`. `verification.json` holds three real process receipts: the project test, a parent-owned external oracle, and a compile-time `requestId` probe. Only `README.md`, `src/TodoService.ts`, and `test/TodoService.test.ts` may differ from the immutable fixture.

After journal genesis, the core records an intent before each workflow-owned mutating operation and a settlement after its artifacts are durable. Reconciliation clears a settled-operation/state-clear crash and blocks unknown pending work or event/state disagreement. It deliberately does not implement semantic continuation for the small crash window after an operation is fully settled but before the next phase transition; that run can remain safely stuck and should be replaced with a fresh run. Adapter observation receipts are best-effort telemetry, not state-machine side effects. This is a tested fail-closed lab, not a general workflow-resume engine.

The stock Profile proves that EGC fits ordinary Tool, Subagent, Skill, and guard seams. The adapter Profile proves Profile-level AgentFactory replacement and setup composition while retaining the package-private ReAct step algorithm. The Full Custom Profile proves that a third party can implement AgentFactory, Agent, Turn/Step state, model stepping, serial tool dispatch, cancellation, and owner teardown without the official AgentLoop package; it also exposes that exact Inbox consumption is not yet a stable public rc.6 plugin seam. EGC itself does not use `workflowEngine` because rc.6 does not provide its approval journal/resume semantics; the separate saved-workflow experiment does use the official engine for native in-memory orchestration.

The DSH tool guard and Node permission checks are defense in depth against the named experiment escapes. Node's permission model and the official WorkflowEngine worker/vm are not operating-system sandboxes or security boundaries for hostile code, and this lab makes no such claim. Saved workflows are trusted, allowlisted local source files.
