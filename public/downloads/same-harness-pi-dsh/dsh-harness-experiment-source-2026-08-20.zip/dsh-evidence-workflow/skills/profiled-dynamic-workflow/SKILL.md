---
name: profiled-dynamic-workflow
description: Runs the allowlisted multi-model-review saved workflow through deployment-owned fast, deep, and review profiles. Use when the user explicitly asks for multiple model perspectives on one task.
---

# Profiled Dynamic Workflow

Call `profiled_dynamic_workflow` with:

- `workflow`: `multi-model-review`
- `task`: the user's exact review task

Do not generate or pass raw workflow source. Do not ask the user for provider IDs, model IDs, or credentials; the deployment-owned `model-profiles.json` resolves the logical `fast`, `deep`, and `review` profiles.

The saved script runs in the official DSH WorkflowEngine. Report the returned `runId`, `agentsStarted`, `profiles`, `resolvedRoutes`, `timings`, `retryCount`, `retryTelemetryComplete`, `routeTelemetryComplete`, `agentOutcomes`, `outcomeTelemetryComplete`, and final result. Treat `retryCount` as a lower bound when its completeness flag is false; `routeTelemetryComplete` describes route observability; `outcomeTelemetryComplete` means lifecycle coverage, not that every child succeeded. The DSH facade also verifies that successful independent reviews used at least two distinct `finalObservedRoute` values. It machine-validates that `result.findings` has exactly three items and that each item has exactly `sourceLocations`, `failureScenario`, `rankingRationale`, and `fixSuggestion`; do not summarize a route/schema failure as a successful review. If a profile contains an unsupported field such as `thinking`, `tools`, or `maxTokens`, stop and report the configuration error; never silently drop it.
